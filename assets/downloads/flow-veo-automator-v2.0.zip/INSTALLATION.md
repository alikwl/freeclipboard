# Installation Guide - Auto Prompt Paster Extension

## Quick Install (Recommended)

Your extension is ready to load! All necessary files are already in the correct structure.

### Step 1: Generate Icons (Optional but Recommended)

1. Open `icons/generate-icons.html` in your browser
2. Right-click each canvas image and select "Save image as..."
3. Save them in the `icons/` folder with these exact names:
   - `icon16.png`
   - `icon48.png`
   - `icon128.png`

**Note:** The extension will work without icons, but they make it look more professional.

### Step 2: Load Extension in Chrome

1. Open Chrome and navigate to: `chrome://extensions/`
2. Enable **Developer mode** (toggle switch in the top-right corner)
3. Click **"Load unpacked"** button
4. Select this entire folder (the one containing `manifest.json`)
5. The extension should now appear in your extensions list!

### Step 3: Pin the Extension (Optional)

1. Click the puzzle piece icon in Chrome's toolbar
2. Find "Auto Prompt Paster" in the list
3. Click the pin icon to keep it visible in your toolbar

## Using the Extension

### Basic Usage

1. Click the extension icon in your toolbar
2. Click "Choose Prompt File" and select a `.txt` file with your prompts
3. Navigate to the website where you want to paste (e.g., Flow website)
4. Click "Start" to begin auto-pasting

### Prompt File Format

Create a text file with prompts separated by blank lines:

```
First prompt goes here.
It can have multiple lines.

Second prompt here.
Also with multiple lines if needed.

Third prompt.
```

### Features

- **Immediate First Paste:** First prompt pastes as soon as you click Start
- **5-Minute Intervals:** Subsequent prompts paste automatically every 5 minutes
- **Status Display:** See current prompt number and countdown timer
- **Stop Anytime:** Click Stop to halt the session
- **Notifications:** Get notified when session starts, stops, or completes

## Testing

Sample test files are included in the `tests/` folder:
- `test-prompts-single.txt` - One prompt
- `test-prompts-multiple.txt` - Five prompts
- `test-prompts-empty.txt` - Empty file (for error testing)

For comprehensive testing instructions, see `tests/MANUAL_TEST_GUIDE.md`

## Troubleshooting

### Extension won't load
- Make sure you selected the folder containing `manifest.json`
- Check that all files are present (manifest.json, popup/, background/, content/)
- Try reloading the extension from chrome://extensions/

### "Could not find input field" error
- Make sure you're on a page with a text input or textarea
- The extension looks for common input patterns (textareas, contenteditable divs)
- Try refreshing the page and starting again

### Prompts not pasting
- Verify you're not on a restricted page (chrome://, edge://, etc.)
- Check that the page has loaded completely
- Make sure the input field is visible on the page

### Timer not accurate
- Chrome alarms have a minimum interval and may vary slightly
- For testing, you can modify the interval in `background/background.js`

## File Structure

```
extension/
├── manifest.json          # Extension configuration
├── popup/
│   ├── popup.html        # Extension popup UI
│   ├── popup.js          # Popup logic
│   └── popup.css         # Popup styling
├── background/
│   └── background.js     # Background service worker
├── content/
│   └── content.js        # Content script for page interaction
├── icons/
│   ├── icon16.png        # Small icon (generate from HTML)
│   ├── icon48.png        # Medium icon
│   ├── icon128.png       # Large icon
│   └── generate-icons.html  # Icon generator tool
└── tests/                # Test files and documentation
```

## Uninstalling

1. Go to `chrome://extensions/`
2. Find "Auto Prompt Paster"
3. Click "Remove"

## Support

For issues or questions, refer to:
- `tests/MANUAL_TEST_GUIDE.md` - Comprehensive testing guide
- `tests/TEST_SUMMARY.md` - Test results and coverage
- `README.md` - Project overview

---

**Ready to use!** Follow the steps above to load the extension into Chrome.
