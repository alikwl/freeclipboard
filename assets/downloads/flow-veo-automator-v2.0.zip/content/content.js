// Content script for Auto Prompt Paster
// Handles DOM interaction with the Flow website

/**
 * Finds the input field on the page using multiple selector strategies
 * @returns {HTMLElement|null} The input field element or null if not found
 */
function findInputField() {
  // Try multiple selector strategies for common input types
  const selectors = [
    'textarea[placeholder*="message"]',
    'textarea[placeholder*="Message"]',
    'textarea[role="textbox"]',
    'div[contenteditable="true"]',
    'textarea[contenteditable="true"]',
    'input[type="text"]',
    'textarea',
    '[contenteditable="true"]'
  ];

  for (const selector of selectors) {
    const element = document.querySelector(selector);
    if (element) {
      return element;
    }
  }

  return null;
}

/**
 * Pastes the prompt text into the input field
 * @param {string} text - The prompt text to paste
 * @returns {Object} Object with success status and optional error message
 */
function pastePrompt(text) {
  const inputField = findInputField();
  
  if (!inputField) {
    console.error('Input field not found on page');
    return {
      success: false,
      error: 'Could not find input field on page. Make sure you\'re on the Flow website.'
    };
  }

  try {
    // Validate text is not empty
    if (!text || text.trim().length === 0) {
      console.error('Empty prompt text');
      return {
        success: false,
        error: 'Cannot paste empty prompt.'
      };
    }

    // Clear existing text
    if (inputField.isContentEditable || inputField.contentEditable === 'true') {
      // Handle contenteditable divs
      inputField.textContent = '';
      inputField.innerText = text;
    } else {
      // Handle textarea and input elements
      inputField.value = '';
      inputField.value = text;
    }

    // Trigger input and change events to notify the page of the change
    inputField.dispatchEvent(new Event('input', { bubbles: true }));
    inputField.dispatchEvent(new Event('change', { bubbles: true }));
    
    // Some frameworks also listen for these events
    inputField.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true }));
    inputField.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));

    // Focus the input field
    inputField.focus();

    // Wait a brief moment for the text to be processed, then press Enter
    setTimeout(() => {
      // Simulate Enter key press to submit/start video generation
      const enterEvent = new KeyboardEvent('keydown', {
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13,
        bubbles: true,
        cancelable: true
      });
      inputField.dispatchEvent(enterEvent);
      
      // Also dispatch keyup for Enter
      const enterUpEvent = new KeyboardEvent('keyup', {
        key: 'Enter',
        code: 'Enter',
        keyCode: 13,
        which: 13,
        bubbles: true,
        cancelable: true
      });
      inputField.dispatchEvent(enterUpEvent);
      
      // Try triggering a submit event on any parent form
      const form = inputField.closest('form');
      if (form) {
        form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
      }
      
      console.log('Enter key pressed to start video generation');
    }, 100); // 100ms delay to ensure text is fully processed

    console.log('Prompt pasted successfully');
    return { success: true };
  } catch (error) {
    console.error('Error pasting prompt:', error);
    return {
      success: false,
      error: `Failed to paste prompt: ${error.message}`
    };
  }
}

/**
 * Detects recent videos on the page
 * @param {number} count - Number of recent videos to detect (default: 4)
 * @returns {Object} Object with success status, videos array, and optional error
 */
function detectRecentVideos(count = 4) {
  try {
    const videos = [];
    const timestamp = Date.now();

    // Strategy 1: Detect <video> elements
    const videoElements = document.querySelectorAll('video');
    videoElements.forEach((element, index) => {
      const src = element.src || element.currentSrc;
      if (src) {
        videos.push({
          url: src,
          filename: extractFilenameFromUrl(src),
          index: videos.length,
          timestamp: timestamp,
          element: element,
          type: src.startsWith('blob:') ? 'blob' : 'direct'
        });
      }
    });

    // Strategy 2: Detect download links (anchor tags with video extensions)
    const videoExtensions = ['.mp4', '.webm', '.mov', '.avi', '.mkv', '.m4v'];
    const links = document.querySelectorAll('a[href]');
    links.forEach((link) => {
      const href = link.href;
      if (href && videoExtensions.some(ext => href.toLowerCase().includes(ext))) {
        // Avoid duplicates
        if (!videos.some(v => v.url === href)) {
          videos.push({
            url: href,
            filename: extractFilenameFromUrl(href) || link.textContent.trim(),
            index: videos.length,
            timestamp: timestamp,
            element: link,
            type: 'download-link'
          });
        }
      }
    });

    // Strategy 3: Detect elements with data-video-url or similar custom attributes
    const customVideoElements = document.querySelectorAll('[data-video-url], [data-src*=".mp4"], [data-src*=".webm"]');
    customVideoElements.forEach((element) => {
      const url = element.getAttribute('data-video-url') || element.getAttribute('data-src');
      if (url && !videos.some(v => v.url === url)) {
        videos.push({
          url: url,
          filename: extractFilenameFromUrl(url),
          index: videos.length,
          timestamp: timestamp,
          element: element,
          type: url.startsWith('blob:') ? 'blob' : 'direct'
        });
      }
    });

    // Strategy 4: Look for source elements within video tags
    const sourceElements = document.querySelectorAll('video source[src]');
    sourceElements.forEach((source) => {
      const src = source.src;
      if (src && !videos.some(v => v.url === src)) {
        videos.push({
          url: src,
          filename: extractFilenameFromUrl(src),
          index: videos.length,
          timestamp: timestamp,
          element: source.parentElement,
          type: src.startsWith('blob:') ? 'blob' : 'direct'
        });
      }
    });

    // Sort videos by DOM order (most recent = last in document)
    // We'll use the element's position in the document to determine order
    videos.sort((a, b) => {
      const positionA = getElementPosition(a.element);
      const positionB = getElementPosition(b.element);
      return positionB - positionA; // Reverse order (most recent first)
    });

    // Update indices after sorting
    videos.forEach((video, idx) => {
      video.index = idx;
    });

    // Return only the requested count of most recent videos
    const recentVideos = videos.slice(0, count);

    console.log(`Detected ${recentVideos.length} recent videos out of ${videos.length} total`);

    return {
      success: true,
      videos: recentVideos,
      error: null
    };
  } catch (error) {
    console.error('Error detecting videos:', error);
    return {
      success: false,
      videos: [],
      error: `Failed to detect videos: ${error.message}`
    };
  }
}

/**
 * Extracts filename from a URL
 * @param {string} url - The URL to extract filename from
 * @returns {string|null} The filename or null if not found
 */
function extractFilenameFromUrl(url) {
  try {
    if (!url) return null;
    
    // Handle blob URLs - they don't have meaningful filenames
    if (url.startsWith('blob:')) {
      return null;
    }

    // Parse the URL and get the pathname
    const urlObj = new URL(url);
    const pathname = urlObj.pathname;
    
    // Extract the last segment of the path
    const segments = pathname.split('/');
    const lastSegment = segments[segments.length - 1];
    
    // Check if it looks like a filename (has an extension)
    if (lastSegment && lastSegment.includes('.')) {
      return lastSegment;
    }
    
    return null;
  } catch (error) {
    // If URL parsing fails, try simple string manipulation
    const parts = url.split('/');
    const lastPart = parts[parts.length - 1];
    if (lastPart && lastPart.includes('.')) {
      return lastPart.split('?')[0]; // Remove query parameters
    }
    return null;
  }
}

/**
 * Gets the position of an element in the document
 * Used for determining DOM order
 * @param {HTMLElement} element - The element to get position for
 * @returns {number} A number representing the element's position
 */
function getElementPosition(element) {
  if (!element) return 0;
  
  // Use a simple approach: count all preceding elements
  let position = 0;
  let current = element;
  
  while (current) {
    // Count previous siblings
    let sibling = current.previousSibling;
    while (sibling) {
      position++;
      sibling = sibling.previousSibling;
    }
    
    // Move up to parent
    current = current.parentElement;
  }
  
  return position;
}

// Listen for messages from the background service worker
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'PASTE_PROMPT') {
    try {
      // Validate message has text
      if (!message.text) {
        sendResponse({ 
          success: false, 
          error: 'No prompt text provided.' 
        });
        return true;
      }

      const result = pastePrompt(message.text);
      sendResponse(result);
    } catch (error) {
      console.error('Error handling PASTE_PROMPT message:', error);
      sendResponse({ 
        success: false, 
        error: 'An unexpected error occurred while pasting.' 
      });
    }
  } else if (message.type === 'DETECT_VIDEOS') {
    try {
      const count = message.count || 4;
      const result = detectRecentVideos(count);
      sendResponse(result);
    } catch (error) {
      console.error('Error handling DETECT_VIDEOS message:', error);
      sendResponse({
        success: false,
        videos: [],
        error: 'An unexpected error occurred while detecting videos.'
      });
    }
  } else if (message.type === 'DOWNLOAD_PROGRESS') {
    try {
      // Handle download progress notification
      console.log(`Download progress: ${message.current}/${message.total} - ${message.filename}`);
      
      // This is a notification message, no response needed
      // Content script can use this to update UI or log progress
      sendResponse({ success: true });
    } catch (error) {
      console.error('Error handling DOWNLOAD_PROGRESS message:', error);
      sendResponse({ success: false });
    }
  }
  
  // Return true to indicate we will send a response asynchronously
  return true;
});

console.log('Auto Prompt Paster content script loaded');
