// Content Script v3.6 for Flow Automator Pro (Fix Timer/Renaming)
// FIX: FIFO Queue for Prompt-Video Matching

console.log('✅ Flow Automator Pro v3.6 Content Script Loaded');

// --- State ---
// We use a queue because generations might finish out of order or take longer than the next prompt injection.
const state = {
  queue: [],           // Array of { promptText, promptIndex, timestamp }
  baseVideoIds: new Set(), // IDs of videos that existed *before* the current "new" check cycle
  baseVideoUrls: new Set(), // URLs of videos already processed (prevent duplicates)
  activeVideo: null    // { id, url, promptInfo, firstSeen } - The currently detected "new" video being processed
};

// --- Utilities ---
function log(msg, level = 'info') {
  console.log(`[${level}] ${msg}`);
  try {
    chrome.runtime.sendMessage({ type: 'SIG_LOG', message: msg, level }).catch(() => { });
  } catch (e) { }
}

function getTextarea() {
  return document.querySelector('textarea');
}

function extractVideoId(url) {
  try {
    const match = url.match(/\/video\/([a-f0-9-]+)/i);
    if (match) return match[1];
    return url.split('?')[0].slice(-40);
  } catch (e) {
    return url;
  }
}

function getAllVideosWithIds() {
  const videos = [];
  document.querySelectorAll('video').forEach(v => {
    let src = v.src || v.currentSrc;
    if (!src) {
      const sourceEl = v.querySelector('source');
      if (sourceEl) src = sourceEl.src;
    }
    if (src && src.startsWith('http')) {
      const id = extractVideoId(src);
      const isReady = v.readyState >= 3; // HAVE_FUTURE_DATA or better
      const duration = v.duration || 0;
      videos.push({
        id,
        url: src,
        ready: isReady,
        duration,
        element: v
      });
    }
  });
  return videos;
}

function isPageLoading() {
  const selectors = ['[role="progressbar"]', '.loading', '[aria-busy="true"]', '.spinner'];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el && el.offsetParent !== null) return true;
  }
  // Removed global text check to prevent false positives from prompt text
  return false;
}

function detectFailedGeneration() {
  const pageText = document.body?.innerText || '';
  return pageText.includes('Failed Generation');
}

// --- Actions ---

function confirmDownload(promptIndex, videoId, videoUrl) {
  // Remove the specific prompt index from queue
  const initialLen = state.queue.length;
  state.queue = state.queue.filter(i => i.index !== promptIndex);

  // Mark video as processed (base)
  if (videoId) {
    state.baseVideoIds.add(videoId);
  }
  if (videoUrl) {
    state.baseVideoUrls.add(videoUrl);
  }

  // Reset active video if it matches
  if (state.activeVideo && state.activeVideo.id === videoId) {
    state.activeVideo = null;
  }

  log(`🗑️ Confirmed download for Prompt ${promptIndex + 1}. Queue: ${initialLen} -> ${state.queue.length}`);
  return { success: true };
}

async function injectText(text) {
  const textarea = getTextarea();
  if (!textarea) {
    return { success: false, error: 'Textarea not found' };
  }

  log(`Injecting ${text.length} chars...`);
  textarea.focus();

  const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
  if (setter) setter.call(textarea, text);
  textarea.value = text;

  textarea.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: text }));
  textarea.dispatchEvent(new Event('change', { bubbles: true }));

  log('✅ Injected');
  return { success: true };
}

async function pressEnterAndQueue(promptText, promptIndex) {
  const textarea = getTextarea();
  if (!textarea) {
    return { success: false, error: 'Textarea not found' };
  }

  // 1. UPDATE BASE: Mark all currently visible videos as "old"
  // This ensures we don't accidentally match an existing video as the new one.
  const currentVideos = getAllVideosWithIds();
  currentVideos.forEach(v => state.baseVideoIds.add(v.id));

  // 2. Queue the request
  state.queue.push({
    text: promptText,
    index: promptIndex,
    timestamp: Date.now()
  });

  log(`➡️ Queued Prompt ${promptIndex + 1}. Queue size: ${state.queue.length}`);



  textarea.focus();

  textarea.dispatchEvent(new KeyboardEvent('keydown', {
    bubbles: true, cancelable: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13
  }));
  textarea.dispatchEvent(new KeyboardEvent('keyup', {
    bubbles: true, key: 'Enter', code: 'Enter', keyCode: 13
  }));

  log('✅ Enter pressed');
  return { success: true };
}

function checkVideoReady() {
  const loading = isPageLoading();
  const failed = detectFailedGeneration();
  const currentVideos = getAllVideosWithIds();
  const now = Date.now();

  log(`🔍 Check: ${currentVideos.length} total videos, ${state.baseVideoIds.size} in base set, queue: ${state.queue.length}`);

  // 1. Identify candidates (videos not in base set by ID or URL)
  const candidates = currentVideos.filter(v => !state.baseVideoIds.has(v.id) && !state.baseVideoUrls.has(v.url));

  if (candidates.length > 0) {
    log(`📹 Found ${candidates.length} new candidate(s): ${candidates.map(v => `${v.id.substring(0, 8)}... (ready:${v.ready}, dur:${v.duration.toFixed(1)}s)`).join(', ')}`);
  }

  let resultVideo = null;
  let promptInfo = null;
  let videoIsReady = false;

  // 2. Logic to match candidate to prompt

  // A. If we already found a match previously, keep checking if it's still valid/ready
  if (state.activeVideo) {
    // Check if active video is still in candidates (it should be)
    const found = candidates.find(v => v.id === state.activeVideo.id);
    if (found) {
      resultVideo = found;
      promptInfo = state.activeVideo.promptInfo;

      // Check if video is ready
      // RELAXED LOGIC: Accept if EITHER:
      // 1. Video has proper HTML5 readyState and duration, OR
      // 2. Video has been present for 3+ seconds (assume it's ready even if metadata not set)
      const timePresent = now - state.activeVideo.firstSeen;
      const hasProperMetadata = found.ready && found.duration > 0;
      const hasBeenStableLongEnough = timePresent >= 3000; // 3 seconds

      videoIsReady = hasProperMetadata || hasBeenStableLongEnough;

      if (videoIsReady) {
        log(`✅ Video ready: ${resultVideo.id.substring(0, 8)}... for prompt ${promptInfo.index + 1} (present for ${(timePresent / 1000).toFixed(1)}s)`);
      } else {
        log(`⏳ Video not ready yet: ${resultVideo.id.substring(0, 8)}... (present for ${(timePresent / 1000).toFixed(1)}s, waiting...)`);
      }
    } else {
      // Logic hole: Active video disappeared? Reset Active.
      log(`⚠️ Active video ${state.activeVideo.id} disappeared.`);
      state.activeVideo = null;
    }
  }

  // B. If no active match, try to find a NEW match
  if (!state.activeVideo && candidates.length > 0) {
    // Take first candidate - we'll track how long it's been present
    const newVideo = candidates[0];
    let nextPrompt = null;

    if (state.queue.length > 0) {
      // MATCH from Queue
      nextPrompt = state.queue.shift(); // FIFO - Take ownership immediately
      log(`🔗 Matched Prompt ${nextPrompt.index + 1} ("${nextPrompt.text.substring(0, 30)}...") to Video ${newVideo.id.substring(0, 8)}...`);
    } else {
      // Fallback: No queue item, but we have a new video.
      log(`⚠️ New Video ${newVideo.id.substring(0, 8)}... found but Queue is empty`);
      nextPrompt = {
        text: 'Unknown Prompt',
        index: -1,
        timestamp: Date.now()
      };
    }

    state.activeVideo = {
      id: newVideo.id,
      url: newVideo.url,
      promptInfo: nextPrompt,
      firstSeen: now
    };

    resultVideo = newVideo;
    promptInfo = nextPrompt;

    // Check readiness for new video
    const hasProperMetadata = newVideo.ready && newVideo.duration > 0;

    if (hasProperMetadata) {
      // Immediately ready!
      videoIsReady = true;
      log(`✅ Video ready immediately: ${resultVideo.id.substring(0, 8)}... for prompt ${promptInfo.index + 1}`);
    } else {
      // Will check again in next cycle
      videoIsReady = false;
      log(`⏳ New video detected, waiting for readiness: ${resultVideo.id.substring(0, 8)}...`);
    }
  }

  return {
    success: true,
    videoReady: videoIsReady,
    videoId: resultVideo?.id || null,
    videoUrl: resultVideo?.url || null,
    promptText: promptInfo?.text || '',
    promptIndex: promptInfo ? promptInfo.index : -1,
    loading,
    generationFailed: failed,
    queueSize: state.queue.length
  };
}

function healthCheck() {
  return {
    timestamp: new Date().toISOString(),
    textarea: !!getTextarea(),
    videoCount: getAllVideosWithIds().length,
    queueSize: state.queue.length,
    loading: isPageLoading(),
    hasFailed: detectFailedGeneration()
  };
}

// --- Message Handler ---
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  log(`Command: ${msg.type}`);

  (async () => {
    try {
      switch (msg.type) {
        case 'CMD_INJECT':
          sendResponse(await injectText(msg.text));
          break;

        case 'CMD_PRESS_ENTER':
          sendResponse(await pressEnterAndQueue(msg.promptText || '', msg.promptIndex || 0));
          break;

        case 'CMD_CHECK_VIDEO_READY':
          sendResponse(checkVideoReady());
          break;

        case 'CMD_CONFIRM_DOWNLOAD':
          sendResponse(confirmDownload(msg.promptIndex, msg.videoId, msg.videoUrl));
          break;

        case 'HEALTH_CHECK':
          sendResponse(healthCheck());
          break;

        case 'PING':
          sendResponse({ success: true, version: '3.6' });
          break;

        default:
          sendResponse({ success: false, error: 'Unknown' });
      }
    } catch (e) {
      log(`Error: ${e.message}`, 'error');
      sendResponse({ success: false, error: e.message });
    }
  })();

  return true;
});

log('Content script v3.6 ready - FIFO Queue Enabled');
