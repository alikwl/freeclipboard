# Implementation Plan

- [x] 1. Set up browser extension project structure and manifest





  - Create directory structure with popup, background, and content script folders
  - Write manifest.json with Manifest V3 configuration, permissions (storage, alarms, activeTab), and component declarations
  - _Requirements: 5.5_

- [x] 2. Implement popup UI interface





  - Create popup.html with file input, start/stop button, and status display elements
  - Write popup.css for clean, user-friendly styling
  - _Requirements: 5.1, 5.3_

- [x] 3. Implement popup logic and file handling





  - Write popup.js to handle file selection and parse prompts from text file
  - Implement prompt parsing logic that splits file content by blank line gaps (one or more consecutive newlines) to separate prompts
  - Preserve multi-line content within each prompt and trim whitespace from each prompt
  - Add file validation to check for empty files and display appropriate error messages
  - Implement message sending to background service worker for LOAD_PROMPTS, START_SESSION, STOP_SESSION, and GET_STATUS
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 5.4_

- [x] 4. Implement background service worker state management





  - Create background.js with state object for prompts, currentIndex, isRunning, and nextPasteTime
  - Write functions to save and load state from chrome.storage.local
  - Implement loadPrompts() function to store prompts array in extension storage
  - _Requirements: 2.1, 2.2_

- [x] 5. Implement session control in background service worker





  - Write startSession() function that pastes first prompt immediately and creates chrome.alarm for 5-minute intervals
  - Write stopSession() function that clears alarms and resets running state
  - Implement alarm listener that triggers pasteNextPrompt() every 5 minutes
  - Add logic to detect when all prompts are completed and automatically stop session with notification
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 3.4_

- [x] 6. Implement prompt pasting coordination





  - Write pasteNextPrompt() function in background.js that sends PASTE_PROMPT message to content script
  - Add error handling for cases where content script is not available or tab is not on Flow website
  - Implement index increment logic and boundary checking
  - Add notification display for paste errors and session completion
  - _Requirements: 4.3, 4.5, 3.4, 5.4_

- [x] 7. Implement status tracking and updates





  - Write getStatus() function that returns current state including isRunning, currentIndex, totalPrompts, and nextPasteTime
  - Implement message listener in background.js to handle GET_STATUS requests from popup
  - Add logic to calculate time until next paste based on alarm schedule
  - _Requirements: 3.1, 3.2, 3.3, 3.5_

- [x] 8. Implement content script for DOM interaction





  - Create content.js with findInputField() function using multiple selector strategies for common input types
  - Write pastePrompt() function that clears existing text, inserts new prompt, and triggers input/change events
  - Implement message listener to handle PASTE_PROMPT commands from background
  - Add error detection and response for cases where input field is not found
  - _Requirements: 4.1, 4.2, 4.3, 4.4_

- [x] 9. Implement popup status display and real-time updates





  - Write updateUI() function in popup.js to display current prompt number, total prompts, and time until next paste
  - Add polling mechanism to request status updates from background every second when popup is open
  - Implement button state toggling between Start and Stop based on session state
  - Display session state indicator (idle/running/completed)
  - _Requirements: 3.1, 3.2, 3.3, 3.5, 5.3_

- [x] 10. Add comprehensive error handling and user notifications





  - Implement error display in popup UI for file loading errors
  - Add chrome.notifications for session events (start, stop, completion, errors)
  - Handle edge cases: starting without prompts loaded, wrong website, input field not found
  - Display appropriate error messages for each error scenario
  - _Requirements: 1.4, 4.3, 5.4_
-

- [x] 11. Test extension functionality





  - Manually test file loading with various file types (empty, single prompt, multiple prompts)
  - Verify 5-minute interval timing accuracy using chrome.alarms
  - Test start/stop functionality at different stages of prompt queue
  - Verify prompt pasting on Flow website with different input field configurations
  - Test all error scenarios and verify appropriate error messages display
  - _Requirements: All requirements_
