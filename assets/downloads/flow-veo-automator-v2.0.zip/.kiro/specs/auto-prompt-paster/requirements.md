# Requirements Document

## Introduction

This document defines the requirements for an Auto Prompt Paster extension that reads prompts from a text file and automatically pastes them one by one at 5-minute intervals into a website named "flow". The extension provides a simple, user-friendly interface for automating repetitive prompt submissions.

## Glossary

- **Extension**: The Auto Prompt Paster browser extension that automates prompt pasting
- **Prompt File**: A text file containing multiple prompts, with each prompt separated by a delimiter
- **Active Session**: The period during which the Extension is actively pasting prompts
- **Prompt Queue**: The ordered list of prompts loaded from the Prompt File
- **Flow Website**: The target website where prompts will be pasted
- **Target Input**: The text input field on the Flow Website where prompts are pasted

## Requirements

### Requirement 1

**User Story:** As a user, I want to load prompts from a text file, so that I can prepare multiple prompts for automated pasting

#### Acceptance Criteria

1. THE Extension SHALL provide a command to select a Prompt File from the file system
2. WHEN the user selects a Prompt File, THE Extension SHALL parse the file content into individual prompts using newline delimiters
3. THE Extension SHALL display the total count of loaded prompts to the user
4. IF the Prompt File is empty or unreadable, THEN THE Extension SHALL display an error message to the user
5. THE Extension SHALL support text files with UTF-8 encoding

### Requirement 2

**User Story:** As a user, I want to start and stop the automatic pasting, so that I can control when prompts are submitted

#### Acceptance Criteria

1. THE Extension SHALL provide a command to start an Active Session
2. THE Extension SHALL provide a command to stop an Active Session
3. WHEN an Active Session starts, THE Extension SHALL paste the first prompt from the Prompt Queue immediately
4. WHILE an Active Session is running, THE Extension SHALL paste the next prompt every 5 minutes
5. WHEN an Active Session stops, THE Extension SHALL halt all scheduled prompt pasting operations

### Requirement 3

**User Story:** As a user, I want to see the current status of the pasting process, so that I know which prompt is next and how many remain

#### Acceptance Criteria

1. THE Extension SHALL display the current position in the Prompt Queue during an Active Session
2. THE Extension SHALL display the number of remaining prompts in the Prompt Queue
3. THE Extension SHALL display the time until the next prompt paste operation
4. WHEN all prompts have been pasted, THE Extension SHALL notify the user and stop the Active Session
5. THE Extension SHALL show a status indicator when an Active Session is running

### Requirement 4

**User Story:** As a user, I want the extension to paste prompts into the Flow Website input field, so that I can automate my workflow

#### Acceptance Criteria

1. WHEN a paste operation occurs, THE Extension SHALL insert the prompt text into the Target Input field on the Flow Website
2. THE Extension SHALL preserve the original formatting of each prompt
3. IF the Flow Website is not open in the active tab, THEN THE Extension SHALL display a warning message to the user
4. THE Extension SHALL clear any existing text in the Target Input before pasting a new prompt
5. THE Extension SHALL move to the next prompt in the Prompt Queue after each paste operation

### Requirement 5

**User Story:** As a user, I want simple controls accessible from the browser extension popup, so that I can easily use the extension without complex configuration

#### Acceptance Criteria

1. THE Extension SHALL provide a popup interface with buttons for all main actions
2. THE Extension SHALL use clear, descriptive labels for all controls
3. THE Extension SHALL display the current status in the popup interface
4. THE Extension SHALL display notifications for important events such as session start, session end, and errors
5. THE Extension SHALL require no configuration file setup before first use
