# Design Document: Auto Prompt Paster Browser Extension

## Overview

The Auto Prompt Paster is a browser extension that automates the process of pasting prompts from a text file into the Flow website at 5-minute intervals. The extension consists of a popup UI for user interaction, a background service worker for timing and state management, and a content script for interacting with the Flow website's DOM.

## Architecture

The extension follows the standard browser extension architecture with three main components:

```
┌─────────────────┐
│   Popup UI      │ ← User interaction
│  (popup.html)   │
└────────┬────────┘
         │
         ↓
┌─────────────────┐
│  Background     │ ← State & timing
│  Service Worker │
└────────┬────────┘
         │
         ↓
┌─────────────────┐
│ Content Script  │ ← DOM manipulation
│ (content.js)    │
└─────────────────┘
```

### Component Communication

- Popup ↔ Background: Chrome runtime messaging API
- Background ↔ Content Script: Chrome tabs messaging API
- Background uses Chrome alarms API for 5-minute intervals

## Components and Interfaces

### 1. Popup UI (popup.html + popup.js)

**Purpose**: Provides user interface for controlling the extension

**UI Elements**:
- File input button to select prompt file
- Display area showing loaded prompt count
- Start/Stop button (toggles based on state)
- Status display showing:
  - Current prompt number
  - Total prompts
  - Time until next paste
  - Session state (idle/running/completed)

**Interface with Background**:
```javascript
// Messages sent to background
{
  type: 'LOAD_PROMPTS',
  prompts: string[]
}

{
  type: 'START_SESSION'
}

{
  type: 'STOP_SESSION'
}

{
  type: 'GET_STATUS'
}

// Messages received from background
{
  type: 'STATUS_UPDATE',
  data: {
    isRunning: boolean,
    currentIndex: number,
    totalPrompts: number,
    nextPasteTime: number | null
  }
}
```

### 2. Background Service Worker (background.js)

**Purpose**: Manages application state, timing, and coordinates between popup and content script

**State Management**:
```javascript
{
  prompts: string[],
  currentIndex: number,
  isRunning: boolean,
  nextPasteTime: number | null,
  alarmName: 'promptPasterAlarm'
}
```

**Key Functions**:
- `loadPrompts(prompts)`: Store prompts in extension storage
- `startSession()`: Initialize session, paste first prompt, set alarm
- `stopSession()`: Clear alarm, reset state
- `pasteNextPrompt()`: Send message to content script, increment index
- `handleAlarm()`: Triggered every 5 minutes, calls pasteNextPrompt()
- `getStatus()`: Return current state for popup

**Chrome APIs Used**:
- `chrome.storage.local`: Persist prompts and state
- `chrome.alarms`: Schedule 5-minute intervals
- `chrome.runtime.onMessage`: Handle popup messages
- `chrome.tabs.sendMessage`: Send paste commands to content script

### 3. Content Script (content.js)

**Purpose**: Interact with Flow website DOM to paste prompts

**Key Functions**:
- `findInputField()`: Locate the target input field on Flow website
- `pastePrompt(text)`: Clear input, insert text, trigger input events

**DOM Interaction Strategy**:
```javascript
// Find input field (common selectors for chat interfaces)
const selectors = [
  'textarea[placeholder*="message"]',
  'textarea[role="textbox"]',
  'div[contenteditable="true"]',
  'input[type="text"]'
];

// Paste with proper event triggering
inputField.value = promptText;
inputField.dispatchEvent(new Event('input', { bubbles: true }));
inputField.dispatchEvent(new Event('change', { bubbles: true }));
```

**Message Handling**:
```javascript
// Message received from background
{
  type: 'PASTE_PROMPT',
  text: string
}

// Response sent back
{
  success: boolean,
  error?: string
}
```

## Data Models

### Prompt File Format

Prompts are separated by one or more blank lines. Each prompt can span multiple lines, and prompts are delimited by empty line gaps.

```
First prompt text here
This is still part of the first prompt

Second prompt text here
This continues the second prompt

Third prompt text here
```

**Parsing Logic**:
- Split file content by sequences of blank lines (one or more consecutive newlines)
- Each resulting block of text is treated as a single prompt
- Preserve line breaks within each prompt
- Trim whitespace from start and end of each prompt

### Extension Storage Schema

```javascript
{
  prompts: string[],           // Array of prompt texts
  currentIndex: number,        // Current position in queue (0-based)
  isRunning: boolean,          // Session state
  totalPrompts: number         // Total count for quick access
}
```

## Error Handling

### File Loading Errors
- Empty file: Display "No prompts found in file"
- Invalid encoding: Display "Unable to read file. Please use UTF-8 encoded text file"
- File read failure: Display "Failed to load file. Please try again"

### Paste Operation Errors
- No active tab: Display "Please open the Flow website"
- Input field not found: Display "Could not find input field on page. Make sure you're on the Flow website"
- Paste failure: Log error, continue to next prompt after 5 minutes

### Session Errors
- Start without prompts: Display "Please load a prompt file first"
- All prompts completed: Display "All prompts have been pasted!" and stop session

## Testing Strategy

### Unit Testing Focus
- Background service worker state management
- Prompt parsing logic
- Message handling between components

### Manual Testing Checklist
- Load various prompt files (empty, single prompt, multiple prompts)
- Start/stop session at different stages
- Verify 5-minute timing accuracy
- Test on Flow website with different input field types
- Verify prompt formatting preservation
- Test error scenarios (no file, wrong website, etc.)

### Browser Compatibility
- Primary target: Chrome/Chromium-based browsers
- Use Manifest V3 for modern extension standards
- Test on Chrome, Edge, Brave

## Implementation Notes

### Manifest V3 Requirements
- Use service worker instead of background page
- Declare all permissions explicitly
- Use chrome.alarms for timing (more reliable than setTimeout in service workers)

### User Experience Considerations
- Immediate feedback for all actions
- Clear status indicators
- Non-intrusive notifications
- Ability to stop at any time
- Persist state across browser restarts (optional enhancement)

### Security Considerations
- Request minimal permissions (storage, alarms, activeTab)
- No external network requests
- File reading happens in popup context (user-initiated)
- Content script only injects into active tab when needed
