// Simple Node.js script to create placeholder icon files
// This creates base64-encoded PNG files

const fs = require('fs');
const path = require('path');

// Minimal 1x1 transparent PNG (base64)
const transparentPNG = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
  'base64'
);

// Create icon files
const sizes = [16, 48, 128];
const iconsDir = __dirname;

sizes.forEach(size => {
  const filename = path.join(iconsDir, `icon${size}.png`);
  fs.writeFileSync(filename, transparentPNG);
  console.log(`Created ${filename}`);
});

console.log('\nPlaceholder icons created successfully!');
console.log('The extension will now load. You can replace these with custom icons later.');
