# Update Notes

## Latest Update: Auto-Submit Feature

### What Changed
The extension now **automatically presses Enter** after pasting each prompt to start the video generation on Flow.

### How It Works
1. Prompt is pasted into the input field
2. Extension waits 100ms for the text to be processed
3. Enter key is automatically pressed
4. Video generation starts immediately

### Technical Details
- Simulates both `keydown` and `keyup` events for Enter key
- Also triggers form submit if the input is inside a form
- 100ms delay ensures the pasted text is fully processed before submission

### To Apply This Update

**If extension is already loaded:**
1. Go to `chrome://extensions/`
2. Find "Auto Prompt Paster"
3. Click the **reload icon** (circular arrow)
4. Done! The update is now active

**If not loaded yet:**
- Just load the extension normally - it already includes this feature

### Testing the Update

1. Load a prompt file
2. Go to Flow website
3. Click "Start"
4. Watch as the prompt pastes AND automatically submits!
5. Video generation should start immediately

### Behavior

- **First prompt:** Pastes immediately + auto-submits
- **Subsequent prompts:** Paste every 5 minutes + auto-submit each time
- **Result:** Fully automated video generation workflow!

---

**Version:** 1.0.1  
**Date:** Updated with auto-submit feature  
**Status:** ✅ Ready to use
