/**
 * Tests for popup.js functionality
 * Run these tests to verify prompt parsing and file handling logic
 */

// Mock DOM elements
function setupMockDOM() {
  global.document = {
    getElementById: (id) => ({
      addEventListener: () => {},
      textContent: '',
      className: '',
      disabled: false,
      value: '',
      style: { display: 'none' }
    }),
    addEventListener: () => {}
  };
}

// Test prompt parsing function
function parsePrompts(content) {
  const prompts = content
    .split(/\n\s*\n+/)
    .map(prompt => prompt.trim())
    .filter(prompt => prompt.length > 0);
  
  return prompts;
}

// Test cases
function runTests() {
  console.log('Running Popup Tests...\n');
  
  let passed = 0;
  let failed = 0;
  
  // Test 1: Parse single prompt
  try {
    const result = parsePrompts('This is a single prompt');
    if (result.length === 1 && result[0] === 'This is a single prompt') {
      console.log('✓ Test 1 PASSED: Single prompt parsing');
      passed++;
    } else {
      console.log('✗ Test 1 FAILED: Expected 1 prompt, got', result.length);
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 1 FAILED:', e.message);
    failed++;
  }
  
  // Test 2: Parse multiple prompts separated by blank lines
  try {
    const content = 'First prompt\n\nSecond prompt\n\nThird prompt';
    const result = parsePrompts(content);
    if (result.length === 3 && 
        result[0] === 'First prompt' && 
        result[1] === 'Second prompt' && 
        result[2] === 'Third prompt') {
      console.log('✓ Test 2 PASSED: Multiple prompts parsing');
      passed++;
    } else {
      console.log('✗ Test 2 FAILED: Expected 3 prompts, got', result.length);
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 2 FAILED:', e.message);
    failed++;
  }
  
  // Test 3: Parse multi-line prompts
  try {
    const content = 'First line\nSecond line\nThird line\n\nAnother prompt\nWith multiple lines';
    const result = parsePrompts(content);
    if (result.length === 2 && 
        result[0] === 'First line\nSecond line\nThird line' && 
        result[1] === 'Another prompt\nWith multiple lines') {
      console.log('✓ Test 3 PASSED: Multi-line prompt parsing');
      passed++;
    } else {
      console.log('✗ Test 3 FAILED: Expected 2 multi-line prompts');
      console.log('Got:', result);
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 3 FAILED:', e.message);
    failed++;
  }
  
  // Test 4: Handle empty file
  try {
    const result = parsePrompts('');
    if (result.length === 0) {
      console.log('✓ Test 4 PASSED: Empty file handling');
      passed++;
    } else {
      console.log('✗ Test 4 FAILED: Expected 0 prompts for empty file, got', result.length);
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 4 FAILED:', e.message);
    failed++;
  }
  
  // Test 5: Handle file with only whitespace
  try {
    const result = parsePrompts('   \n\n   \n   ');
    if (result.length === 0) {
      console.log('✓ Test 5 PASSED: Whitespace-only file handling');
      passed++;
    } else {
      console.log('✗ Test 5 FAILED: Expected 0 prompts for whitespace file, got', result.length);
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 5 FAILED:', e.message);
    failed++;
  }
  
  // Test 6: Trim whitespace from prompts
  try {
    const content = '  First prompt  \n\n  Second prompt  ';
    const result = parsePrompts(content);
    if (result.length === 2 && 
        result[0] === 'First prompt' && 
        result[1] === 'Second prompt') {
      console.log('✓ Test 6 PASSED: Whitespace trimming');
      passed++;
    } else {
      console.log('✗ Test 6 FAILED: Whitespace not properly trimmed');
      console.log('Got:', result);
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 6 FAILED:', e.message);
    failed++;
  }
  
  // Test 7: Handle multiple consecutive blank lines
  try {
    const content = 'First prompt\n\n\n\nSecond prompt';
    const result = parsePrompts(content);
    if (result.length === 2 && 
        result[0] === 'First prompt' && 
        result[1] === 'Second prompt') {
      console.log('✓ Test 7 PASSED: Multiple blank lines handling');
      passed++;
    } else {
      console.log('✗ Test 7 FAILED: Expected 2 prompts with multiple blank lines');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 7 FAILED:', e.message);
    failed++;
  }
  
  console.log(`\n--- Test Results ---`);
  console.log(`Passed: ${passed}`);
  console.log(`Failed: ${failed}`);
  console.log(`Total: ${passed + failed}`);
  
  return failed === 0;
}

// Run tests
const success = runTests();
process.exit(success ? 0 : 1);
