/**
 * Integration tests for video download workflow in automation cycle
 * Tests the complete flow: paste → wait → detect → download → next prompt
 */

// Mock chrome APIs for testing
const mockChrome = {
  storage: {
    local: {
      data: {},
      async set(items) {
        Object.assign(this.data, items);
      },
      async get(keys) {
        const result = {};
        keys.forEach(key => {
          if (this.data[key] !== undefined) {
            result[key] = this.data[key];
          }
        });
        return result;
      }
    }
  },
  tabs: {
    async query() {
      return [{ id: 1, url: 'https://example.com' }];
    },
    async sendMessage(tabId, message) {
      // Mock responses based on message type
      if (message.type === 'PASTE_PROMPT') {
        return { success: true };
      }
      if (message.type === 'DETECT_VIDEOS') {
        return {
          success: true,
          videos: [
            { url: 'video1.mp4', filename: 'video1.mp4', index: 0, timestamp: Date.now(), type: 'direct' },
            { url: 'video2.mp4', filename: 'video2.mp4', index: 1, timestamp: Date.now(), type: 'direct' }
          ],
          error: null
        };
      }
      return { success: false };
    }
  },
  downloads: {
    downloadId: 1,
    async download(options) {
      return this.downloadId++;
    }
  },
  notifications: {
    async create() {
      return 'notification-id';
    }
  },
  alarms: {
    async create() {},
    async clear() {},
    async get() {
      return null;
    }
  }
};

// Test helper to simulate state
function createTestState() {
  return {
    prompts: ['prompt1', 'prompt2', 'prompt3'],
    currentIndex: 0,
    isRunning: true,
    nextPasteTime: null,
    currentPhase: 'idle',
    downloadProgress: {
      current: 0,
      total: 0,
      filename: null
    },
    downloadStats: {
      totalDownloaded: 0,
      totalFailed: 0
    },
    config: {
      postGenerationDelay: 100, // Use shorter delay for testing
      downloadDelay: 50,
      generationTimeout: 600000,
      retryAttempts: 3
    }
  };
}

function runTests() {
  console.log('Running Automation Workflow Integration Tests...\n');
  
  let passed = 0;
  let failed = 0;
  
  // Test 1: Verify workflow phases transition correctly
  try {
    const state = createTestState();
    const phases = ['idle', 'pasting', 'generating', 'downloading', 'waiting'];
    
    // Verify all phases are valid
    phases.forEach(phase => {
      state.currentPhase = phase;
      if (!['idle', 'pasting', 'generating', 'downloading', 'waiting'].includes(state.currentPhase)) {
        throw new Error(`Invalid phase: ${phase}`);
      }
    });
    
    console.log('✓ Test 1 PASSED: Workflow phases are valid');
    passed++;
  } catch (e) {
    console.log('✗ Test 1 FAILED:', e.message);
    failed++;
  }
  
  // Test 2: Verify state includes download tracking fields
  try {
    const state = createTestState();
    
    if (state.downloadProgress &&
        typeof state.downloadProgress.current === 'number' &&
        typeof state.downloadProgress.total === 'number' &&
        state.downloadStats &&
        typeof state.downloadStats.totalDownloaded === 'number' &&
        typeof state.downloadStats.totalFailed === 'number') {
      console.log('✓ Test 2 PASSED: State includes download tracking fields');
      passed++;
    } else {
      console.log('✗ Test 2 FAILED: Missing download tracking fields in state');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 2 FAILED:', e.message);
    failed++;
  }
  
  // Test 3: Verify config includes timing settings
  try {
    const state = createTestState();
    
    if (state.config.postGenerationDelay &&
        state.config.downloadDelay &&
        state.config.generationTimeout &&
        state.config.retryAttempts) {
      console.log('✓ Test 3 PASSED: Config includes timing settings');
      passed++;
    } else {
      console.log('✗ Test 3 FAILED: Missing timing settings in config');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 3 FAILED:', e.message);
    failed++;
  }
  
  // Test 4: Verify download progress updates correctly
  try {
    const state = createTestState();
    
    // Simulate download progress
    state.downloadProgress.total = 4;
    state.downloadProgress.current = 0;
    
    for (let i = 1; i <= 4; i++) {
      state.downloadProgress.current = i;
      state.downloadProgress.filename = `video_${i}.mp4`;
      
      if (state.downloadProgress.current !== i) {
        throw new Error(`Progress not updated correctly: expected ${i}, got ${state.downloadProgress.current}`);
      }
    }
    
    console.log('✓ Test 4 PASSED: Download progress updates correctly');
    passed++;
  } catch (e) {
    console.log('✗ Test 4 FAILED:', e.message);
    failed++;
  }
  
  // Test 5: Verify download stats accumulate correctly
  try {
    const state = createTestState();
    
    // Simulate multiple download cycles
    state.downloadStats.totalDownloaded = 0;
    state.downloadStats.totalFailed = 0;
    
    // First cycle: 3 success, 1 failure
    state.downloadStats.totalDownloaded += 3;
    state.downloadStats.totalFailed += 1;
    
    // Second cycle: 4 success, 0 failure
    state.downloadStats.totalDownloaded += 4;
    
    if (state.downloadStats.totalDownloaded === 7 &&
        state.downloadStats.totalFailed === 1) {
      console.log('✓ Test 5 PASSED: Download stats accumulate correctly');
      passed++;
    } else {
      console.log('✗ Test 5 FAILED: Download stats not accumulating correctly');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 5 FAILED:', e.message);
    failed++;
  }
  
  // Test 6: Verify prompt index increments after paste
  try {
    const state = createTestState();
    const initialIndex = state.currentIndex;
    
    // Simulate successful paste
    state.currentIndex++;
    
    if (state.currentIndex === initialIndex + 1) {
      console.log('✓ Test 6 PASSED: Prompt index increments after paste');
      passed++;
    } else {
      console.log('✗ Test 6 FAILED: Prompt index not incrementing correctly');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 6 FAILED:', e.message);
    failed++;
  }
  
  // Test 7: Verify completion detection
  try {
    const state = createTestState();
    state.currentIndex = state.prompts.length;
    
    const isComplete = state.currentIndex >= state.prompts.length;
    
    if (isComplete) {
      console.log('✓ Test 7 PASSED: Completion detected correctly');
      passed++;
    } else {
      console.log('✗ Test 7 FAILED: Completion not detected');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 7 FAILED:', e.message);
    failed++;
  }
  
  // Test 8: Verify phase transitions in correct order
  try {
    const state = createTestState();
    const expectedSequence = ['idle', 'pasting', 'generating', 'downloading', 'waiting'];
    let isValid = true;
    
    // Simulate workflow
    for (const phase of expectedSequence) {
      state.currentPhase = phase;
      if (state.currentPhase !== phase) {
        isValid = false;
        break;
      }
    }
    
    if (isValid) {
      console.log('✓ Test 8 PASSED: Phase transitions follow correct order');
      passed++;
    } else {
      console.log('✗ Test 8 FAILED: Phase transitions out of order');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 8 FAILED:', e.message);
    failed++;
  }
  
  console.log(`\n--- Test Results ---`);
  console.log(`Passed: ${passed}`);
  console.log(`Failed: ${failed}`);
  console.log(`Total: ${passed + failed}`);
  
  return failed === 0;
}

// Run tests
const success = runTests();
process.exit(success ? 0 : 1);
