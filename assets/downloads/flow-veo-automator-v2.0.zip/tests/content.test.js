/**
 * Tests for content.js functionality
 * Run these tests to verify input field finding and pasting logic
 */

// Mock DOM for testing
class MockElement {
  constructor(tagName, attributes = {}) {
    this.tagName = tagName;
    this.attributes = attributes;
    this.textContent = '';
    this.innerText = '';
    this.value = '';
    this.isContentEditable = attributes.contenteditable === 'true';
    this.contentEditable = attributes.contenteditable || 'false';
    this.events = {};
  }
  
  dispatchEvent(event) {
    // Mock event dispatching
    return true;
  }
  
  focus() {
    // Mock focus
  }
}

// Test findInputField logic
function testFindInputField() {
  console.log('Running Content Script Tests...\n');
  
  let passed = 0;
  let failed = 0;
  
  // Test 1: Find textarea with message placeholder
  try {
    const mockDoc = {
      querySelector: (selector) => {
        if (selector === 'textarea[placeholder*="message"]') {
          return new MockElement('textarea', { placeholder: 'Type a message' });
        }
        return null;
      }
    };
    
    const result = mockDoc.querySelector('textarea[placeholder*="message"]');
    if (result && result.tagName === 'textarea') {
      console.log('✓ Test 1 PASSED: Find textarea with message placeholder');
      passed++;
    } else {
      console.log('✗ Test 1 FAILED: Could not find textarea');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 1 FAILED:', e.message);
    failed++;
  }
  
  // Test 2: Find contenteditable div
  try {
    const mockDoc = {
      querySelector: (selector) => {
        if (selector === 'div[contenteditable="true"]') {
          return new MockElement('div', { contenteditable: 'true' });
        }
        return null;
      }
    };
    
    const result = mockDoc.querySelector('div[contenteditable="true"]');
    if (result && result.isContentEditable) {
      console.log('✓ Test 2 PASSED: Find contenteditable div');
      passed++;
    } else {
      console.log('✗ Test 2 FAILED: Could not find contenteditable div');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 2 FAILED:', e.message);
    failed++;
  }
  
  // Test 3: Paste into textarea
  try {
    const textarea = new MockElement('textarea');
    textarea.value = 'old text';
    
    // Simulate paste
    textarea.value = '';
    textarea.value = 'new prompt text';
    
    if (textarea.value === 'new prompt text') {
      console.log('✓ Test 3 PASSED: Paste into textarea');
      passed++;
    } else {
      console.log('✗ Test 3 FAILED: Text not pasted correctly');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 3 FAILED:', e.message);
    failed++;
  }
  
  // Test 4: Paste into contenteditable
  try {
    const div = new MockElement('div', { contenteditable: 'true' });
    div.textContent = 'old text';
    
    // Simulate paste
    div.textContent = '';
    div.innerText = 'new prompt text';
    
    if (div.innerText === 'new prompt text') {
      console.log('✓ Test 4 PASSED: Paste into contenteditable');
      passed++;
    } else {
      console.log('✗ Test 4 FAILED: Text not pasted correctly');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 4 FAILED:', e.message);
    failed++;
  }
  
  // Test 5: Handle empty prompt text
  try {
    const textarea = new MockElement('textarea');
    const emptyText = '';
    
    if (!emptyText || emptyText.trim().length === 0) {
      console.log('✓ Test 5 PASSED: Empty prompt detection');
      passed++;
    } else {
      console.log('✗ Test 5 FAILED: Empty prompt not detected');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 5 FAILED:', e.message);
    failed++;
  }
  
  // Test 6: Clear existing text before paste
  try {
    const textarea = new MockElement('textarea');
    textarea.value = 'existing text that should be cleared';
    
    // Simulate clear and paste
    textarea.value = '';
    textarea.value = 'new text';
    
    if (textarea.value === 'new text') {
      console.log('✓ Test 6 PASSED: Clear existing text');
      passed++;
    } else {
      console.log('✗ Test 6 FAILED: Existing text not cleared');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 6 FAILED:', e.message);
    failed++;
  }
  
  console.log(`\n--- Test Results ---`);
  console.log(`Passed: ${passed}`);
  console.log(`Failed: ${failed}`);
  console.log(`Total: ${passed + failed}`);
  
  return failed === 0;
}

// Run tests
const success = testFindInputField();
process.exit(success ? 0 : 1);
