/**
 * Tests for popup UI download status display
 * Verifies that the UI correctly displays download progress and statistics
 */

// Mock DOM setup
function createMockElement(id) {
  return {
    id: id,
    textContent: '',
    className: '',
    style: { display: 'block' },
    classList: {
      _classes: [],
      add: function(className) {
        if (!this._classes.includes(className)) {
          this._classes.push(className);
        }
      },
      remove: function(className) {
        this._classes = this._classes.filter(c => c !== className);
      },
      contains: function(className) {
        return this._classes.includes(className);
      }
    }
  };
}

function setupMockDOM() {
  const elements = {
    'sessionStatus': createMockElement('sessionStatus'),
    'phaseInfo': createMockElement('phaseInfo'),
    'promptInfo': createMockElement('promptInfo'),
    'timerInfo': createMockElement('timerInfo'),
    'downloadProgress': createMockElement('downloadProgress'),
    'downloadStats': createMockElement('downloadStats'),
    'startStopBtn': createMockElement('startStopBtn')
  };
  
  // Add download section
  const downloadSection = createMockElement('download-section');
  downloadSection.className = 'download-section';
  
  global.document = {
    getElementById: (id) => elements[id] || createMockElement(id),
    querySelector: (selector) => {
      if (selector === '.download-section') {
        return downloadSection;
      }
      return createMockElement('unknown');
    }
  };
  
  return { elements, downloadSection };
}

// Helper function to get display text for current phase
function getPhaseDisplayText(phase) {
  const phaseMap = {
    'idle': 'Idle',
    'pasting': 'Pasting prompt',
    'generating': 'Waiting for generation',
    'downloading': 'Downloading videos',
    'waiting': 'Waiting for next prompt'
  };
  
  return phaseMap[phase] || phase;
}

// Simplified updateUI function for testing
function updateUI(status) {
  if (!status) {
    return;
  }
  
  const phaseInfo = document.getElementById('phaseInfo');
  const downloadProgress = document.getElementById('downloadProgress');
  const downloadStats = document.getElementById('downloadStats');
  const downloadSection = document.querySelector('.download-section');
  
  // Update current phase display
  if (status.isRunning && status.currentPhase) {
    const phaseText = getPhaseDisplayText(status.currentPhase);
    phaseInfo.textContent = `Phase: ${phaseText}`;
    phaseInfo.style.display = 'block';
  } else {
    phaseInfo.textContent = '';
    phaseInfo.style.display = 'none';
  }
  
  // Update download progress display
  if (status.downloadProgress && status.downloadProgress.total > 0) {
    downloadSection.classList.add('active');
    
    const current = status.downloadProgress.current;
    const total = status.downloadProgress.total;
    const filename = status.downloadProgress.filename;
    
    if (filename) {
      downloadProgress.textContent = `Downloading: ${filename} (${current} of ${total})`;
    } else {
      downloadProgress.textContent = `Download progress: ${current} of ${total} videos`;
    }
  } else if (status.currentPhase === 'downloading') {
    downloadSection.classList.add('active');
    downloadProgress.textContent = 'Preparing downloads...';
  } else {
    downloadSection.classList.remove('active');
    downloadProgress.textContent = '';
  }
  
  // Update download statistics display
  if (status.downloadStats && (status.downloadStats.totalDownloaded > 0 || status.downloadStats.totalFailed > 0)) {
    downloadSection.classList.add('active');
    
    const downloaded = status.downloadStats.totalDownloaded;
    const failed = status.downloadStats.totalFailed;
    
    let statsText = `Total: ${downloaded} downloaded`;
    if (failed > 0) {
      statsText += `, ${failed} failed`;
    }
    
    downloadStats.textContent = statsText;
  } else {
    downloadStats.textContent = '';
  }
}

// Test cases
function runTests() {
  console.log('Running Popup UI Download Status Tests...\n');
  
  let passed = 0;
  let failed = 0;
  
  // Test 1: Display current phase when running
  try {
    const { elements, downloadSection } = setupMockDOM();
    
    const status = {
      isRunning: true,
      currentPhase: 'downloading',
      downloadProgress: { current: 0, total: 0, filename: null },
      downloadStats: { totalDownloaded: 0, totalFailed: 0 }
    };
    
    updateUI(status);
    
    const phaseInfo = document.getElementById('phaseInfo');
    if (phaseInfo.textContent === 'Phase: Downloading videos' && phaseInfo.style.display === 'block') {
      console.log('✓ Test 1 PASSED: Current phase display');
      passed++;
    } else {
      console.log('✗ Test 1 FAILED: Phase not displayed correctly');
      console.log('  Expected: "Phase: Downloading videos", Got:', phaseInfo.textContent);
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 1 FAILED:', e.message);
    failed++;
  }
  
  // Test 2: Display download progress with filename
  try {
    const { elements, downloadSection } = setupMockDOM();
    
    const status = {
      isRunning: true,
      currentPhase: 'downloading',
      downloadProgress: { current: 2, total: 4, filename: 'video_001.mp4' },
      downloadStats: { totalDownloaded: 1, totalFailed: 0 }
    };
    
    updateUI(status);
    
    const downloadProgress = document.getElementById('downloadProgress');
    if (downloadProgress.textContent === 'Downloading: video_001.mp4 (2 of 4)' && 
        downloadSection.classList.contains('active')) {
      console.log('✓ Test 2 PASSED: Download progress with filename');
      passed++;
    } else {
      console.log('✗ Test 2 FAILED: Download progress not displayed correctly');
      console.log('  Got:', downloadProgress.textContent);
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 2 FAILED:', e.message);
    failed++;
  }
  
  // Test 3: Display download progress without filename
  try {
    const { elements, downloadSection } = setupMockDOM();
    
    const status = {
      isRunning: true,
      currentPhase: 'downloading',
      downloadProgress: { current: 3, total: 4, filename: null },
      downloadStats: { totalDownloaded: 2, totalFailed: 0 }
    };
    
    updateUI(status);
    
    const downloadProgress = document.getElementById('downloadProgress');
    if (downloadProgress.textContent === 'Download progress: 3 of 4 videos') {
      console.log('✓ Test 3 PASSED: Download progress without filename');
      passed++;
    } else {
      console.log('✗ Test 3 FAILED: Download progress not displayed correctly');
      console.log('  Got:', downloadProgress.textContent);
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 3 FAILED:', e.message);
    failed++;
  }
  
  // Test 4: Display download statistics with no failures
  try {
    const { elements, downloadSection } = setupMockDOM();
    
    const status = {
      isRunning: true,
      currentPhase: 'waiting',
      downloadProgress: { current: 0, total: 0, filename: null },
      downloadStats: { totalDownloaded: 4, totalFailed: 0 }
    };
    
    updateUI(status);
    
    const downloadStats = document.getElementById('downloadStats');
    if (downloadStats.textContent === 'Total: 4 downloaded') {
      console.log('✓ Test 4 PASSED: Download statistics with no failures');
      passed++;
    } else {
      console.log('✗ Test 4 FAILED: Download stats not displayed correctly');
      console.log('  Got:', downloadStats.textContent);
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 4 FAILED:', e.message);
    failed++;
  }
  
  // Test 5: Display download statistics with failures
  try {
    const { elements, downloadSection } = setupMockDOM();
    
    const status = {
      isRunning: true,
      currentPhase: 'waiting',
      downloadProgress: { current: 0, total: 0, filename: null },
      downloadStats: { totalDownloaded: 3, totalFailed: 1 }
    };
    
    updateUI(status);
    
    const downloadStats = document.getElementById('downloadStats');
    if (downloadStats.textContent === 'Total: 3 downloaded, 1 failed') {
      console.log('✓ Test 5 PASSED: Download statistics with failures');
      passed++;
    } else {
      console.log('✗ Test 5 FAILED: Download stats not displayed correctly');
      console.log('  Got:', downloadStats.textContent);
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 5 FAILED:', e.message);
    failed++;
  }
  
  // Test 6: Hide download section when not downloading
  try {
    const { elements, downloadSection } = setupMockDOM();
    
    const status = {
      isRunning: true,
      currentPhase: 'pasting',
      downloadProgress: { current: 0, total: 0, filename: null },
      downloadStats: { totalDownloaded: 0, totalFailed: 0 }
    };
    
    updateUI(status);
    
    if (!downloadSection.classList.contains('active')) {
      console.log('✓ Test 6 PASSED: Download section hidden when not downloading');
      passed++;
    } else {
      console.log('✗ Test 6 FAILED: Download section should be hidden');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 6 FAILED:', e.message);
    failed++;
  }
  
  // Test 7: Show "Preparing downloads..." when in downloading phase with no progress
  try {
    const { elements, downloadSection } = setupMockDOM();
    
    const status = {
      isRunning: true,
      currentPhase: 'downloading',
      downloadProgress: { current: 0, total: 0, filename: null },
      downloadStats: { totalDownloaded: 0, totalFailed: 0 }
    };
    
    updateUI(status);
    
    const downloadProgress = document.getElementById('downloadProgress');
    if (downloadProgress.textContent === 'Preparing downloads...' && 
        downloadSection.classList.contains('active')) {
      console.log('✓ Test 7 PASSED: Preparing downloads message');
      passed++;
    } else {
      console.log('✗ Test 7 FAILED: Preparing message not displayed correctly');
      console.log('  Got:', downloadProgress.textContent);
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 7 FAILED:', e.message);
    failed++;
  }
  
  // Test 8: Phase display for all phases
  try {
    const phases = [
      { phase: 'idle', expected: 'Phase: Idle' },
      { phase: 'pasting', expected: 'Phase: Pasting prompt' },
      { phase: 'generating', expected: 'Phase: Waiting for generation' },
      { phase: 'downloading', expected: 'Phase: Downloading videos' },
      { phase: 'waiting', expected: 'Phase: Waiting for next prompt' }
    ];
    
    let allPassed = true;
    for (const { phase, expected } of phases) {
      const { elements } = setupMockDOM();
      
      const status = {
        isRunning: true,
        currentPhase: phase,
        downloadProgress: { current: 0, total: 0, filename: null },
        downloadStats: { totalDownloaded: 0, totalFailed: 0 }
      };
      
      updateUI(status);
      
      const phaseInfo = document.getElementById('phaseInfo');
      if (phaseInfo.textContent !== expected) {
        console.log(`  Phase "${phase}" failed: Expected "${expected}", Got "${phaseInfo.textContent}"`);
        allPassed = false;
      }
    }
    
    if (allPassed) {
      console.log('✓ Test 8 PASSED: All phase displays correct');
      passed++;
    } else {
      console.log('✗ Test 8 FAILED: Some phase displays incorrect');
      failed++;
    }
  } catch (e) {
    console.log('✗ Test 8 FAILED:', e.message);
    failed++;
  }
  
  console.log(`\n--- Test Results ---`);
  console.log(`Passed: ${passed}`);
  console.log(`Failed: ${failed}`);
  console.log(`Total: ${passed + failed}`);
  
  return failed === 0;
}

// Run tests
const success = runTests();
process.exit(success ? 0 : 1);
