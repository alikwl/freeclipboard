# Manual Testing Guide for Auto Prompt Paster Extension

This guide provides step-by-step instructions for manually testing all functionality of the Auto Prompt Paster extension.

## Prerequisites

1. Load the extension in Chrome:
   - Open Chrome and navigate to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top right)
   - Click "Load unpacked"
   - Select the extension directory
   - Verify the extension appears in the extensions list

2. Test files are located in the `tests/` directory:
   - `test-prompts-single.txt` - Single prompt
   - `test-prompts-multiple.txt` - Five prompts
   - `test-prompts-empty.txt` - Empty file

## Test Suite

### Test 1: File Loading - Single Prompt
**Requirement: 1.1, 1.2, 1.3**

1. Click the extension icon to open popup
2. Click "Choose Prompt File" button
3. Select `tests/test-prompts-single.txt`
4. **Expected Result:**
   - File status shows "Loaded 1 prompt"
   - Start button becomes enabled
   - No error messages displayed

### Test 2: File Loading - Multiple Prompts
**Requirement: 1.1, 1.2, 1.3**

1. Click the extension icon to open popup
2. Click "Choose Prompt File" button
3. Select `tests/test-prompts-multiple.txt`
4. **Expected Result:**
   - File status shows "Loaded 5 prompts"
   - Start button becomes enabled
   - No error messages displayed

### Test 3: File Loading - Empty File
**Requirement: 1.4**

1. Click the extension icon to open popup
2. Click "Choose Prompt File" button
3. Select `tests/test-prompts-empty.txt`
4. **Expected Result:**
   - Error message: "No prompts found in file. Please ensure the file contains text."
   - Start button remains disabled
   - File input is cleared

### Test 4: Start Session Without Loading File
**Requirement: 2.1**

1. Click the extension icon to open popup (fresh state)
2. Try to click Start button
3. **Expected Result:**
   - Start button is disabled
   - Cannot start session without loading prompts

### Test 5: Start Session - First Prompt Immediate Paste
**Requirement: 2.1, 2.3, 4.1**

1. Open a website with a text input (e.g., any chat interface or text editor)
2. Load `tests/test-prompts-multiple.txt`
3. Click "Start" button
4. **Expected Result:**
   - First prompt pastes immediately into the input field
   - Session status changes to "Running"
   - Button changes to "Stop"
   - Prompt info shows "Prompt 1 of 5"
   - Timer shows countdown from 5:00
   - Notification: "Session Started"

### Test 6: 5-Minute Interval Timing
**Requirement: 2.4**

**Note:** This test requires waiting 5 minutes. For faster testing, you can temporarily modify the alarm interval in `background.js`.

1. Start a session with multiple prompts
2. Wait for 5 minutes
3. **Expected Result:**
   - Second prompt pastes automatically after exactly 5 minutes
   - Prompt info updates to "Prompt 2 of 5"
   - Timer resets to 5:00 countdown
   - Process repeats every 5 minutes

**Quick Test Method:**
- Modify `background.js` line with `periodInMinutes: 5` to `periodInMinutes: 0.1` (6 seconds)
- Reload extension
- Test with shorter intervals
- Remember to revert changes after testing

### Test 7: Stop Session Mid-Process
**Requirement: 2.2, 2.5**

1. Start a session with multiple prompts
2. Wait for at least one prompt to paste
3. Click "Stop" button
4. **Expected Result:**
   - Session stops immediately
   - Button changes back to "Start"
   - Session status changes to "Idle"
   - Timer disappears
   - Notification: "Session Stopped at prompt X of Y"
   - No more automatic pasting occurs

### Test 8: Resume After Stop
**Requirement: 2.1**

1. Stop a session mid-process (as in Test 7)
2. Click "Start" button again
3. **Expected Result:**
   - Session restarts from the beginning (prompt 1)
   - First prompt pastes immediately
   - Session continues normally

### Test 9: Session Completion
**Requirement: 2.5, 3.4**

1. Start a session with `test-prompts-single.txt` (1 prompt)
2. Wait for the prompt to paste
3. **Expected Result:**
   - After first prompt pastes, session automatically stops
   - Session status changes to "Completed"
   - Notification: "All Prompts Completed - Successfully pasted all 1 prompts!"
   - No more pasting occurs

### Test 10: Status Display During Session
**Requirement: 3.1, 3.2, 3.3, 3.5**

1. Start a session with multiple prompts
2. Keep popup open and observe status updates
3. **Expected Result:**
   - Current prompt number updates after each paste
   - Total prompts displayed correctly
   - Timer counts down in real-time (updates every second)
   - Session status indicator shows "Running"

### Test 11: Wrong Website Error
**Requirement: 4.3**

1. Navigate to a restricted page (e.g., `chrome://extensions/`)
2. Load prompts and click "Start"
3. **Expected Result:**
   - Error notification: "Cannot paste on this page. Please navigate to the Flow website."
   - Session does not start
   - Button remains as "Start"

### Test 12: Input Field Not Found
**Requirement: 4.3**

1. Navigate to a page with no text input fields (e.g., a static HTML page)
2. Load prompts and click "Start"
3. **Expected Result:**
   - Error notification: "Could not find input field on page. Make sure you're on the Flow website."
   - Session does not start

### Test 13: Prompt Formatting Preservation
**Requirement: 4.2**

1. Create a test file with multi-line prompts:
```
Line 1
Line 2
Line 3

Another prompt
With lines
```
2. Load the file and start session
3. **Expected Result:**
   - Pasted text preserves line breaks
   - Each prompt maintains its original formatting

### Test 14: Clear Existing Text
**Requirement: 4.4**

1. Navigate to a page with a text input
2. Type some text manually into the input field
3. Load prompts and start session
4. **Expected Result:**
   - Existing text is cleared before new prompt is pasted
   - Only the new prompt text appears in the field

### Test 15: Popup Status Updates While Closed
**Requirement: 3.1, 3.2, 3.3**

1. Start a session with multiple prompts
2. Close the popup
3. Wait for next prompt to paste (5 minutes or use quick test method)
4. Open popup again
5. **Expected Result:**
   - Status reflects current state accurately
   - Prompt counter shows correct position
   - Timer shows accurate countdown

### Test 16: Multiple File Loads
**Requirement: 1.1, 1.2**

1. Load `test-prompts-single.txt`
2. Without starting, load `test-prompts-multiple.txt`
3. **Expected Result:**
   - New file replaces old prompts
   - Status shows "Loaded 5 prompts"
   - Previous prompts are discarded

### Test 17: Different Input Field Types
**Requirement: 4.1**

Test on pages with different input types:
- Standard `<textarea>` elements
- `<input type="text">` elements
- `<div contenteditable="true">` elements
- Chat interfaces (Discord, Slack, etc.)

**Expected Result:**
- Extension successfully finds and pastes into all common input types

### Test 18: Browser Restart Persistence (Optional)
**Note:** This tests state persistence across browser restarts

1. Load prompts
2. Start a session
3. Close browser completely
4. Reopen browser and extension
5. **Expected Result:**
   - State may or may not persist (depends on implementation)
   - Extension should not crash or show errors

### Test 19: Notification Display
**Requirement: 5.4**

Verify notifications appear for:
- Session start
- Session stop
- Session completion
- Errors (wrong website, no input field, etc.)

**Expected Result:**
- All notifications display with appropriate titles and messages
- Notifications are non-intrusive
- Messages are clear and actionable

### Test 20: UI Responsiveness
**Requirement: 5.1, 5.2, 5.3**

1. Test all UI interactions:
   - File selection button
   - Start/Stop button
   - Status displays
2. **Expected Result:**
   - All buttons respond immediately to clicks
   - Labels are clear and descriptive
   - Status updates in real-time
   - No UI lag or freezing

## Automated Tests

Run the automated unit tests for core logic:

```bash
node tests/popup.test.js
node tests/content.test.js
```

**Expected Result:**
- All tests pass
- No errors in console

## Test Results Checklist

Use this checklist to track test completion:

- [ ] Test 1: File Loading - Single Prompt
- [ ] Test 2: File Loading - Multiple Prompts
- [ ] Test 3: File Loading - Empty File
- [ ] Test 4: Start Session Without Loading File
- [ ] Test 5: Start Session - First Prompt Immediate Paste
- [ ] Test 6: 5-Minute Interval Timing
- [ ] Test 7: Stop Session Mid-Process
- [ ] Test 8: Resume After Stop
- [ ] Test 9: Session Completion
- [ ] Test 10: Status Display During Session
- [ ] Test 11: Wrong Website Error
- [ ] Test 12: Input Field Not Found
- [ ] Test 13: Prompt Formatting Preservation
- [ ] Test 14: Clear Existing Text
- [ ] Test 15: Popup Status Updates While Closed
- [ ] Test 16: Multiple File Loads
- [ ] Test 17: Different Input Field Types
- [ ] Test 18: Browser Restart Persistence
- [ ] Test 19: Notification Display
- [ ] Test 20: UI Responsiveness
- [ ] Automated Tests: popup.test.js
- [ ] Automated Tests: content.test.js

## Known Issues / Notes

Document any issues found during testing:

1. Issue: _______________
   - Steps to reproduce: _______________
   - Expected: _______________
   - Actual: _______________

2. Issue: _______________
   - Steps to reproduce: _______________
   - Expected: _______________
   - Actual: _______________

## Testing Complete

Once all tests pass, the extension is ready for use!
