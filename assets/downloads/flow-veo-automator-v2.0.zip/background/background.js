// Background service worker for Flow Automator Pro v3.5 (Licensed)
// Based on v3.4 "Perfect" Logic + License Verification

console.log('🚀 Flow Automator Pro v3.5 Background Loaded');

// --- Config ---
const ALARM_MAIN_TIMER = 'main_timer';
const ALARM_CHECK_VIDEO = 'check_video';
const ALARM_RETRY_AFTER_FAILURE = 'retry_after_failure';
const MAX_RETRIES = 3;

const DEFAULT_CONFIG = {
  promptIntervalSeconds: 120,
  autoDownload: true,
  retryEnabled: false
};

// --- State ---
let state = {
  status: 'IDLE',
  phase: 'READY',
  prompts: [],
  currentIndex: 0,
  logs: [],
  config: { ...DEFAULT_CONFIG },
  timerEndTime: null,
  currentPromptText: '',
  downloadedForCurrentPrompt: false,
  retryCount: 0,
  isHandlingFailure: false,
  failureDetectedAt: null,
  failedPrompts: [],
  license: { key: null, valid: false } // Added License State
};

// --- Init ---
chrome.runtime.onStartup.addListener(init);
chrome.runtime.onInstalled.addListener(init);

async function init() {
  await loadState();
}

// --- Storage ---
async function saveState() {
  if (state.logs.length > 150) state.logs = state.logs.slice(-150);
  await chrome.storage.local.set({ appState: state });
}

async function loadState() {
  const data = await chrome.storage.local.get('appState');
  if (data.appState) state = { ...state, ...data.appState };
}

// --- Logging ---
async function log(msg, type = 'info') {
  const entry = { timestamp: new Date().toISOString(), message: msg, type };
  state.logs.push(entry);
  console.log(`[${type}] ${msg}`);
  await saveState();
  chrome.runtime.sendMessage({ type: 'LOG_UPDATE', entry }).catch(() => { });
}

// --- License Utilities (NEW) ---
async function getMachineId() {
  const data = await chrome.storage.local.get('machineId');
  if (data.machineId) return data.machineId;
  const newId = 'MID-' + Math.random().toString(36).substr(2, 9).toUpperCase();
  await chrome.storage.local.set({ machineId: newId });
  return newId;
}

async function validateLicense() {
  // 1. Recover key from storage if missing in memory
  if (!state.license || !state.license.key) {
    const stored = await chrome.storage.local.get('licenseKey');
    if (stored.licenseKey) {
      state.license = state.license || {};
      state.license.key = stored.licenseKey;
      await saveState();
    }
  }

  if (!state.license?.key) {
    return { success: false, message: 'No license key found.' };
  }

  try {
    const machineId = await getMachineId();
    // Quick validation against server
    const response = await fetch('https://flow-backend-bsax256si-oxixxa-gmailcoms-projects.vercel.app/api/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        licenseKey: state.license.key,
        machineId: machineId
      })
    });
    const data = await response.json();
    return data;
  } catch (e) {
    // If network fails but we had a valid key before... 
    // For strict security we might block, but for UX we might allow if recently checked.
    // Here we will fail to be safe.
    await log('License check connection failed: ' + e.message, 'error');
    return { success: false, message: 'Connection Error' };
  }
}


// --- Filename Helper ---
function createFilename(text, index) {
  let name = (text || 'video')
    .substring(0, 30) // User requested 30 chars
    .replace(/[<>:"/\\|?*\n\r]/g, '')
    .replace(/\s+/g, '_')
    .replace(/_+/g, '_')
    .trim() || 'video';
  return `${name}_${index + 1}.mp4`;
}

// --- Alarms ---
chrome.alarms.onAlarm.addListener(async (alarm) => {
  await loadState();

  if (state.status !== 'RUNNING' && alarm.name !== ALARM_RETRY_AFTER_FAILURE) {
    await chrome.alarms.clearAll();
    return;
  }

  if (alarm.name === ALARM_MAIN_TIMER) {
    // Timer Finished! Do final failure check before moving on.
    await chrome.alarms.clear(ALARM_CHECK_VIDEO);

    // Check if failure was just detected (race condition prevention)
    if (state.isHandlingFailure) {
      await log(`⏸️ Failure is being handled by check alarm, skipping timer action`);
      return; // Let the failure handler manage the transition
    }

    // RACE CONDITION FIX: Check if a video was JUST detected (needs time to become ready)
    const tab = await getFlowTab();
    if (tab && !state.downloadedForCurrentPrompt) {
      try {
        const statusCheck = await chrome.tabs.sendMessage(tab.id, { type: 'CMD_CHECK_VIDEO_READY' });

        // If there's ANY active video and we haven't downloaded yet, give it time
        // This catches videos that appear at the EXACT moment timer expires (present for 0.0s)
        if (statusCheck?.videoId) {
          const GRACE_PERIOD = 8000; // 8 seconds (enough for 3s stability + buffer)

          if (!statusCheck.videoReady) {
            await log(`⏸️ Video detected but not ready yet, extending timer by 8s...`);
            state.timerEndTime = Date.now() + GRACE_PERIOD;
            await saveState();
            chrome.alarms.create(ALARM_MAIN_TIMER, { when: state.timerEndTime });
            return; // Don't move to next prompt yet
          }
        }

        // Check for failure
        if (statusCheck?.generationFailed && !state.downloadedForCurrentPrompt) {
          // Only mark as failed if we haven't already handled it
          state.failedPrompts.push(state.prompts[state.currentIndex]);
          await log(`⏭️ Skipping failed prompt ${state.currentIndex + 1}`, 'warn');
        }
      } catch (e) {
        // Content script might not respond, that's okay
      }
    }

    if (!state.downloadedForCurrentPrompt) {
      await log(`⚠️ Timer ended - no download for prompt ${state.currentIndex + 1}`, 'warn');
    }

    state.currentIndex++;
    state.downloadedForCurrentPrompt = false;
    state.retryCount = 0;
    state.timerEndTime = null;
    state.isHandlingFailure = false;
    await saveState();

    await log(`Moving to prompt ${state.currentIndex + 1}`);
    await processPrompt();

  } else if (alarm.name === ALARM_CHECK_VIDEO) {
    // Check Status Logic
    await checkForVideoOrFailure();

  } else if (alarm.name === ALARM_RETRY_AFTER_FAILURE) {
    // Retry Logic
    await log('🔄 Retry timer fired - refreshing page...');
    const tab = await getFlowTab();
    if (tab) {
      try {
        await chrome.tabs.reload(tab.id);
        await log('🔄 Page refreshed, waiting for load...');
        await delay(5000);
      } catch (e) {
        await log(`⚠️ Page refresh failed: ${e.message}`, 'warn');
      }
    }
    state.isHandlingFailure = false;
    state.status = 'RUNNING';
    await saveState();
    await log(`🔄 Retrying prompt ${state.currentIndex + 1}...`);
    await processPrompt();
  }
});

// ===================
// MAIN FLOW
// ===================

async function processPrompt() {
  if (state.status !== 'RUNNING') return;

  await chrome.alarms.clearAll();

  if (state.currentIndex >= state.prompts.length) {
    await log('🎉 All prompts completed!', 'success');
    state.status = 'IDLE';
    state.phase = 'READY';
    await saveState();
    return;
  }

  const prompt = state.prompts[state.currentIndex];
  const total = state.prompts.length;
  state.currentPromptText = prompt;
  state.downloadedForCurrentPrompt = false;
  state.phase = 'PROCESSING';
  await saveState();

  await log(`📝 Prompt ${state.currentIndex + 1}/${total}`);

  // --- LICENSE CHECK START ---
  await log('🔐 Verifying license...');
  const validation = await validateLicense();
  if (!validation.success) {
    await log(`⛔ License Check Failed: ${validation.message}`, 'error');
    state.status = 'PAUSED';
    await saveState();
    return;
  }
  // --- LICENSE CHECK END ---

  const tab = await getFlowTab();
  if (!tab) {
    await log('❌ Flow tab not found!', 'error');
    state.status = 'PAUSED';
    await saveState();
    return;
  }

  try {
    // 1. INJECT
    const injectResult = await chrome.tabs.sendMessage(tab.id, {
      type: 'CMD_INJECT',
      text: prompt
    });

    if (!injectResult?.success) throw new Error('Paste failed (Is Content Script loaded?)');
    await log('✅ Pasted');

    await delay(1000);

    // 2. PRESS ENTER
    await chrome.tabs.sendMessage(tab.id, {
      type: 'CMD_PRESS_ENTER',
      promptText: prompt,
      promptIndex: state.currentIndex
    });
    await log('⏎ Enter pressed');

    // 3. START TIMER
    // Strict fallbacks for timer
    let seconds = 120;
    if (state.config && typeof state.config.promptIntervalSeconds === 'number') {
      seconds = state.config.promptIntervalSeconds;
    }
    if (seconds < 30) seconds = 120; // Safety floor

    state.timerEndTime = Date.now() + (seconds * 1000);
    state.phase = 'WAITING';
    await saveState();

    await log(`⏱️ Timer: ${seconds}s`);
    chrome.alarms.create(ALARM_MAIN_TIMER, { when: state.timerEndTime });

    // Start checking for video after 20s
    setTimeout(async () => {
      await loadState();
      if (state.status === 'RUNNING' && !state.downloadedForCurrentPrompt) {
        chrome.alarms.create(ALARM_CHECK_VIDEO, { periodInMinutes: 0.1 }); // Check every 6s
      }
    }, 20000);

  } catch (e) {
    await log('❌ ' + e.message, 'error');
    state.status = 'PAUSED';
    await saveState();
  }
}

async function checkForVideoOrFailure() {
  await loadState();
  if (state.downloadedForCurrentPrompt) {
    await chrome.alarms.clear(ALARM_CHECK_VIDEO);
    return;
  }

  const tab = await getFlowTab();
  if (!tab) return;

  try {
    const result = await chrome.tabs.sendMessage(tab.id, { type: 'CMD_CHECK_VIDEO_READY' });

    // 1. FAILURE
    if (result?.generationFailed) {
      if (state.isHandlingFailure) return; // Debounce

      // Set flag immediately to prevent duplicate handling
      state.isHandlingFailure = true;
      await chrome.alarms.clearAll();
      await log(`❌ Generation failed for prompt ${state.currentIndex + 1}`, 'error');

      if (state.config.retryEnabled && state.retryCount < MAX_RETRIES) {
        state.retryCount++;
        state.phase = 'RETRY_WAITING';
        await saveState();

        const waitSecs = Math.max(60, state.config.promptIntervalSeconds);
        await log(`🔄 Retry ${state.retryCount}/${MAX_RETRIES} in ${waitSecs}s...`);

        chrome.alarms.create(ALARM_RETRY_AFTER_FAILURE, { delayInMinutes: waitSecs / 60 });
      } else {
        // Skip failed prompt - Refresh page and continue with next prompt
        await log(`⏭️ Skipping failed prompt ${state.currentIndex + 1}, refreshing page...`, 'warn');
        state.failedPrompts.push(state.prompts[state.currentIndex]);
        state.currentIndex++;
        state.retryCount = 0;
        state.downloadedForCurrentPrompt = false;

        // Save state before refresh so we continue from correct index
        await saveState();

        // Refresh the page to clear failed state
        try {
          await chrome.tabs.reload(tab.id);
          await log(`🔄 Page refreshed, waiting for reload...`);
          await delay(5000); // Wait for page to reload
        } catch (e) {
          await log(`⚠️ Page refresh failed: ${e.message}`, 'warn');
        }

        // Calculate remaining time on current interval
        const now = Date.now();
        const remainingTime = state.timerEndTime ? Math.max(0, state.timerEndTime - now) : 0;

        // CRITICAL: Reset flag BEFORE creating timer so timer doesn't skip
        state.isHandlingFailure = false;

        if (remainingTime > 1000) {
          // Wait for the remaining interval time before next prompt
          await log(`⏱️ Next prompt ${state.currentIndex + 1} will paste in ${Math.round(remainingTime / 1000)}s`);
          state.timerEndTime = now + remainingTime;
          await saveState();
          chrome.alarms.create(ALARM_MAIN_TIMER, { when: state.timerEndTime });
        } else {
          // No valid remaining time, process next prompt immediately
          await saveState();
          await processPrompt();
        }
      }
      return;
    }

    // 2. SUCCESS
    if (result?.videoReady && result?.videoUrl) {
      // Use result data strictly if available
      const pText = result.promptText || 'Unknown_Prompt';
      // If result.promptIndex is valid (>=0), use it. otherwise use current.
      // NOTE: We trust the prompt index from info queue more than current index if responding to a late download.
      const hasValidIndex = (typeof result.promptIndex === 'number' && result.promptIndex >= 0);
      const pIndex = hasValidIndex ? result.promptIndex : state.currentIndex;

      let filename = createFilename(pText, pIndex);
      const isLate = pIndex < state.currentIndex;

      if (state.config.autoDownload) {
        try {
          // If we matched a prompt, but text was missing, we used Unknown_Prompt. Better to use stored prompts if index matches.
          if (pText === 'Unknown_Prompt' && hasValidIndex && state.prompts[pIndex]) {
            // Regenerate filename with correct text
            filename = createFilename(state.prompts[pIndex], pIndex);
            // Ensure pText is updated for log? filename has it now.
          }

          await chrome.downloads.download({ url: result.videoUrl, filename, saveAs: false });
          await log(isLate
            ? `⚠️ Late Download Caught: ${filename} (Prompt ${pIndex + 1})`
            : `✅ Downloaded: ${filename}`, isLate ? 'warn' : 'success');
        } catch (e) {
          await log(`⚠️ Download failed: ${e.message}`, 'warn');
        }
      } else {
        await log(`🎬 Video ready: ${filename}`);
      }

      await chrome.tabs.sendMessage(tab.id, {
        type: 'CMD_CONFIRM_DOWNLOAD',
        promptIndex: pIndex,
        videoId: result.videoId,
        videoUrl: result.videoUrl
      });

      if (!isLate) {
        state.downloadedForCurrentPrompt = true;
        await saveState();
        await chrome.alarms.clear(ALARM_CHECK_VIDEO);
      }
    }

  } catch (e) {
    // Content script might be busy or reloading
  }
}


// --- Session Control ---
async function start(config) {
  await loadState();
  if (!state.prompts.length) { await log('❌ No prompts loaded', 'error'); return; }

  // Defensive Config Parsing
  let interval = parseInt(config?.promptIntervalSeconds);
  if (isNaN(interval) || interval < 10) interval = 120; // Default if invalid

  state.config = {
    promptIntervalSeconds: interval,
    autoDownload: config?.autoDownload !== false,
    retryEnabled: config?.retryEnabled !== false
  };

  if (state.currentIndex >= state.prompts.length) state.currentIndex = 0;
  state.status = 'RUNNING';
  state.downloadedForCurrentPrompt = false;
  state.retryCount = 0;
  state.isHandlingFailure = false;
  state.failedPrompts = [];
  await saveState();

  await log(`🚀 Started: ${state.prompts.length} prompts. Timer: ${interval}s`);
  await processPrompt();
}

async function stop() {
  await chrome.alarms.clearAll();
  state.status = 'IDLE';
  state.phase = 'READY';
  state.timerEndTime = null;
  state.isHandlingFailure = false;
  await saveState();
  await log('⏹️ Stopped');
}

async function resume() {
  await loadState();
  if (state.prompts.length === 0) return;
  state.status = 'RUNNING';
  await saveState();
  await log('▶️ Resumed');
  await processPrompt();
}

async function reset() {
  await chrome.alarms.clearAll();
  state = {
    status: 'IDLE', phase: 'READY', prompts: [], currentIndex: 0, logs: [],
    config: { ...DEFAULT_CONFIG }, timerEndTime: null, currentPromptText: '',
    downloadedForCurrentPrompt: false, retryCount: 0, isHandlingFailure: false,
    failedPrompts: [], license: state.license // Keep license!
  };
  await saveState();
  await log('🔄 Reset');
}

async function skip() {
  await chrome.alarms.clearAll();
  await log(`⏭️ Skipped prompt ${state.currentIndex + 1}`, 'warn');
  state.currentIndex++;
  state.downloadedForCurrentPrompt = false;
  state.retryCount = 0;
  if (state.currentIndex >= state.prompts.length) {
    await stop();
  } else {
    await saveState();
    await processPrompt();
  }
}

// --- Message Handler ---
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    switch (msg.type) {
      case 'CMD_START': await start(msg.config); sendResponse({ success: true }); break;
      case 'CMD_STOP': await stop(); sendResponse({ success: true }); break;
      case 'CMD_RESUME': await resume(); sendResponse({ success: true }); break;
      case 'CMD_RESET': await reset(); sendResponse({ success: true }); break;
      case 'CMD_SKIP': await skip(); sendResponse({ success: true }); break;
      case 'GET_STATUS': await loadState(); sendResponse(state); break;
      case 'CMD_LOAD_PROMPTS':
        state.prompts = msg.prompts || [];
        state.currentIndex = 0;
        await saveState();
        await log(`✅ Loaded ${state.prompts.length} prompts`, 'success');
        sendResponse({ success: true, count: state.prompts.length });
        break;
      case 'SIG_LOG': await log(msg.message, msg.level || 'info'); break;
      default: sendResponse({ error: 'Unknown' });
    }
  })();
  return true;
});

// --- Helpers ---
function delay(ms) { return new Promise(r => setTimeout(r, ms)); }
async function getFlowTab() {
  const tabs = await chrome.tabs.query({ url: 'https://labs.google/fx/tools/flow*' });
  // Often there's only one, but prefer active
  return tabs.find(t => t.active) || tabs[0];
}
