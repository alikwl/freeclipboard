// Background service worker for Auto Prompt Paster
console.log('Auto Prompt Paster background service worker loaded');

// State object
let state = {
  prompts: [],
  currentIndex: 0,
  isRunning: false,
  nextPasteTime: null,
  currentPhase: 'idle', // 'idle' | 'pasting' | 'generating' | 'downloading' | 'waiting'
  downloadProgress: {
    current: 0,
    total: 0,
    filename: null
  },
  downloadStats: {
    totalDownloaded: 0,
    totalFailed: 0
  },
  config: {
    postGenerationDelay: 5000,      // 5 seconds
    downloadDelay: 2000,             // 2 seconds
    generationTimeout: 600000,       // 10 minutes
    retryAttempts: 3                 // Max retry attempts per download
  }
};

// Save state to chrome.storage.local
async function saveState() {
  try {
    await chrome.storage.local.set({
      prompts: state.prompts,
      currentIndex: state.currentIndex,
      isRunning: state.isRunning,
      nextPasteTime: state.nextPasteTime,
      currentPhase: state.currentPhase,
      downloadProgress: state.downloadProgress,
      downloadStats: state.downloadStats,
      config: state.config
    });
    console.log('State saved successfully');
  } catch (error) {
    console.error('Error saving state:', error);
  }
}

// Load state from chrome.storage.local
async function loadState() {
  try {
    const result = await chrome.storage.local.get([
      'prompts',
      'currentIndex',
      'isRunning',
      'nextPasteTime',
      'currentPhase',
      'downloadProgress',
      'downloadStats',
      'config'
    ]);
    
    if (result.prompts) {
      state.prompts = result.prompts;
    }
    if (result.currentIndex !== undefined) {
      state.currentIndex = result.currentIndex;
    }
    if (result.isRunning !== undefined) {
      state.isRunning = result.isRunning;
    }
    if (result.nextPasteTime !== undefined) {
      state.nextPasteTime = result.nextPasteTime;
    }
    if (result.currentPhase !== undefined) {
      state.currentPhase = result.currentPhase;
    }
    if (result.downloadProgress !== undefined) {
      state.downloadProgress = result.downloadProgress;
    }
    if (result.downloadStats !== undefined) {
      state.downloadStats = result.downloadStats;
    }
    if (result.config !== undefined) {
      state.config = { ...state.config, ...result.config };
    }
    
    console.log('State loaded successfully:', state);
  } catch (error) {
    console.error('Error loading state:', error);
  }
}

// Load prompts and store in extension storage
async function loadPrompts(prompts) {
  try {
    state.prompts = prompts;
    state.currentIndex = 0;
    state.isRunning = false;
    state.nextPasteTime = null;
    
    await saveState();
    console.log(`Loaded ${prompts.length} prompts`);
    return { success: true, count: prompts.length };
  } catch (error) {
    console.error('Error loading prompts:', error);
    return { success: false, error: error.message };
  }
}

// Start session - paste first prompt immediately and create alarm for 5-minute intervals
async function startSession() {
  try {
    // Check if prompts are loaded
    if (!state.prompts || state.prompts.length === 0) {
      console.error('No prompts loaded');
      await showNotification('Error', 'Please load a prompt file first before starting.');
      return { success: false, error: 'No prompts loaded' };
    }
    
    // Set running state and transition to idle phase initially
    state.isRunning = true;
    state.currentIndex = 0;
    state.currentPhase = 'idle';
    await saveState();
    
    // Paste first prompt immediately
    const pasteResult = await pasteNextPrompt();
    
    // If first paste failed, don't start the session
    if (!pasteResult.success) {
      state.isRunning = false;
      await saveState();
      return { success: false, error: pasteResult.error || 'Failed to paste first prompt' };
    }
    
    // Create alarm for 4 minute intervals (240 seconds = 4.0 minutes)
    await chrome.alarms.create('promptPasterAlarm', {
      periodInMinutes: 4.0
    });
    
    console.log('Session started successfully');
    await showNotification('Session Started', `Auto-pasting ${state.prompts.length} prompts at 4 minute intervals.`);
    return { success: true };
  } catch (error) {
    console.error('Error starting session:', error);
    state.isRunning = false;
    await saveState();
    await showNotification('Error', 'Failed to start session. Please try again.');
    return { success: false, error: error.message };
  }
}

// Stop session - clear alarms and reset running state
async function stopSession() {
  try {
    // Clear the alarm
    await chrome.alarms.clear('promptPasterAlarm');
    
    // Reset running state and transition to idle phase
    const wasRunning = state.isRunning;
    state.isRunning = false;
    state.nextPasteTime = null;
    state.currentPhase = 'idle';
    await saveState();
    
    console.log('Session stopped successfully');
    
    // Only show notification if session was actually running
    if (wasRunning) {
      await showNotification('Session Stopped', `Stopped at prompt ${state.currentIndex} of ${state.prompts.length}.`);
    }
    
    return { success: true };
  } catch (error) {
    console.error('Error stopping session:', error);
    await showNotification('Error', 'Failed to stop session properly.');
    return { success: false, error: error.message };
  }
}

// Paste next prompt - send message to content script
async function pasteNextPrompt() {
  try {
    // Check if all prompts are completed
    if (state.currentIndex >= state.prompts.length) {
      console.log('All prompts completed');
      
      // Transition to idle phase
      state.currentPhase = 'idle';
      await saveState();
      
      // Show completion notification with download stats
      await showNotification(
        'All Prompts Completed', 
        `Successfully pasted all ${state.prompts.length} prompts! Downloaded ${state.downloadStats.totalDownloaded} videos (${state.downloadStats.totalFailed} failed).`
      );
      
      // Stop the session
      await stopSession();
      return { success: true, completed: true };
    }
    
    // Transition to pasting phase
    state.currentPhase = 'pasting';
    await saveState();
    
    // Get current prompt
    const prompt = state.prompts[state.currentIndex];
    
    // Get active tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab) {
      console.error('No active tab found');
      await showNotification('Error', 'No active tab found. Please open the Flow website.');
      return { success: false, error: 'No active tab found' };
    }
    
    // Check if tab URL is valid (not chrome:// or other restricted pages)
    if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://') || tab.url.startsWith('edge://') || tab.url.startsWith('about:'))) {
      console.error('Cannot paste on restricted page');
      await showNotification('Error', 'Cannot paste on this page. Please navigate to the Flow website.');
      return { success: false, error: 'Cannot paste on restricted page' };
    }
    
    // Send paste command to content script
    try {
      const response = await chrome.tabs.sendMessage(tab.id, {
        type: 'PASTE_PROMPT',
        text: prompt
      });
      
      if (response && response.success) {
        // Increment index for next prompt
        state.currentIndex++;
        
        // Update next paste time (4 minutes from now = 240 seconds)
        state.nextPasteTime = Date.now() + (240 * 1000);
        await saveState();
        
        console.log(`Pasted prompt ${state.currentIndex}/${state.prompts.length}`);
        
        // Wait for configured post-generation delay (default 5 seconds)
        console.log(`Waiting ${state.config.postGenerationDelay}ms after paste...`);
        state.currentPhase = 'generating';
        await saveState();
        await new Promise(resolve => setTimeout(resolve, state.config.postGenerationDelay));
        
        // Detect videos on the page
        console.log('Detecting recent videos...');
        try {
          const videoResponse = await chrome.tabs.sendMessage(tab.id, {
            type: 'DETECT_VIDEOS',
            count: 4
          });
          
          if (videoResponse && videoResponse.success && videoResponse.videos && videoResponse.videos.length > 0) {
            console.log(`Detected ${videoResponse.videos.length} videos, starting downloads...`);
            
            // Download all detected videos
            const downloadResult = await downloadAllVideos(videoResponse.videos);
            
            console.log(`Download complete: ${downloadResult.downloaded} succeeded, ${downloadResult.failed} failed`);
            
            // Show notification with results
            if (downloadResult.downloaded > 0 || downloadResult.failed > 0) {
              await showNotification(
                'Videos Downloaded',
                `Downloaded ${downloadResult.downloaded} video(s)${downloadResult.failed > 0 ? `, ${downloadResult.failed} failed` : ''}`
              );
            }
          } else {
            console.log('No videos detected or video detection failed');
            if (videoResponse && videoResponse.error) {
              console.error('Video detection error:', videoResponse.error);
            }
          }
        } catch (videoError) {
          console.error('Error during video detection:', videoError);
          // Continue with automation even if video detection fails
        }
        
        // Transition back to waiting phase
        state.currentPhase = 'waiting';
        await saveState();
        
        return { success: true };
      } else {
        const errorMsg = response?.error || 'Failed to paste prompt';
        console.error('Paste failed:', errorMsg);
        await showNotification('Paste Failed', errorMsg);
        return { success: false, error: errorMsg };
      }
    } catch (error) {
      console.error('Error sending message to content script:', error);
      
      // Provide more specific error message
      let errorMessage = 'Could not communicate with page. Make sure you are on the Flow website.';
      if (error.message && error.message.includes('Receiving end does not exist')) {
        errorMessage = 'Content script not loaded. Please refresh the page and try again.';
      }
      
      await showNotification('Communication Error', errorMessage);
      return { success: false, error: errorMessage };
    }
  } catch (error) {
    console.error('Error in pasteNextPrompt:', error);
    await showNotification('Error', 'An unexpected error occurred while pasting.');
    return { success: false, error: error.message };
  }
}

// ============================================================================
// DOWNLOAD MANAGER MODULE
// ============================================================================

/**
 * Generate filename with timestamp prefix
 * Format: YYYYMMDD_HHMMSS_originalname or video_YYYYMMDD_HHMMSS_index.mp4
 * @param {string|null} originalFilename - Original filename if available
 * @param {number} index - Video index (0-3)
 * @returns {string} Generated filename
 */
function generateFilename(originalFilename, index) {
  const now = new Date();
  const timestamp = now.getFullYear() +
    String(now.getMonth() + 1).padStart(2, '0') +
    String(now.getDate()).padStart(2, '0') +
    '_' +
    String(now.getHours()).padStart(2, '0') +
    String(now.getMinutes()).padStart(2, '0') +
    String(now.getSeconds()).padStart(2, '0');
  
  if (originalFilename) {
    return `${timestamp}_${originalFilename}`;
  } else {
    return `video_${timestamp}_${index}.mp4`;
  }
}

/**
 * Download a video from a blob URL
 * @param {string} blobUrl - Blob URL to download
 * @param {string} filename - Filename to save as
 * @returns {Promise<{success: boolean, downloadId: number|null, filename: string, error: string|null}>}
 */
async function downloadBlobVideo(blobUrl, filename) {
  try {
    console.log(`Fetching blob URL: ${blobUrl}`);
    const response = await fetch(blobUrl);
    
    if (!response.ok) {
      throw new Error(`Failed to fetch blob: ${response.status} ${response.statusText}`);
    }
    
    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    
    console.log(`Initiating download for blob video: ${filename}`);
    const downloadId = await chrome.downloads.download({
      url: objectUrl,
      filename: filename,
      saveAs: false
    });
    
    // Clean up object URL after a short delay
    setTimeout(() => {
      URL.revokeObjectURL(objectUrl);
      console.log(`Cleaned up object URL for: ${filename}`);
    }, 1000);
    
    return {
      success: true,
      downloadId: downloadId,
      filename: filename,
      error: null
    };
  } catch (error) {
    console.error(`Error downloading blob video: ${error.message}`);
    return {
      success: false,
      downloadId: null,
      filename: filename,
      error: error.message
    };
  }
}

/**
 * Download a single video with retry logic
 * @param {Object} videoInfo - Video information object
 * @param {string} videoInfo.url - Video URL (direct or blob)
 * @param {string|null} videoInfo.filename - Original filename if available
 * @param {number} videoInfo.index - Video index (0-3)
 * @param {string} videoInfo.type - Video type ('direct' | 'blob' | 'download-link')
 * @param {number} retryCount - Current retry attempt (0-based)
 * @returns {Promise<{success: boolean, downloadId: number|null, filename: string, error: string|null}>}
 */
async function downloadVideo(videoInfo, retryCount = 0) {
  const maxRetries = state.config.retryAttempts;
  const filename = generateFilename(videoInfo.filename, videoInfo.index);
  
  console.log(`Attempting to download video (attempt ${retryCount + 1}/${maxRetries + 1}):`, {
    url: videoInfo.url,
    filename: filename,
    type: videoInfo.type
  });
  
  try {
    let result;
    
    // Handle blob URLs differently
    if (videoInfo.type === 'blob' || videoInfo.url.startsWith('blob:')) {
      result = await downloadBlobVideo(videoInfo.url, filename);
    } else {
      // Direct URL download using chrome.downloads API
      console.log(`Initiating direct download: ${filename}`);
      const downloadId = await chrome.downloads.download({
        url: videoInfo.url,
        filename: filename,
        saveAs: false
      });
      
      result = {
        success: true,
        downloadId: downloadId,
        filename: filename,
        error: null
      };
    }
    
    // If download succeeded, return result
    if (result.success) {
      console.log(`Download successful: ${filename} (ID: ${result.downloadId})`);
      return result;
    }
    
    // If download failed and we have retries left, retry with exponential backoff
    if (retryCount < maxRetries) {
      const backoffDelay = Math.min(1000 * Math.pow(2, retryCount), 10000);
      console.log(`Download failed, retrying in ${backoffDelay}ms...`);
      
      await new Promise(resolve => setTimeout(resolve, backoffDelay));
      return await downloadVideo(videoInfo, retryCount + 1);
    }
    
    // All retries exhausted
    console.error(`Download failed after ${maxRetries + 1} attempts: ${result.error}`);
    return result;
    
  } catch (error) {
    console.error(`Error in downloadVideo (attempt ${retryCount + 1}):`, error);
    
    // If we have retries left, retry with exponential backoff
    if (retryCount < maxRetries) {
      const backoffDelay = Math.min(1000 * Math.pow(2, retryCount), 10000);
      console.log(`Download error, retrying in ${backoffDelay}ms...`);
      
      await new Promise(resolve => setTimeout(resolve, backoffDelay));
      return await downloadVideo(videoInfo, retryCount + 1);
    }
    
    // All retries exhausted
    return {
      success: false,
      downloadId: null,
      filename: filename,
      error: error.message
    };
  }
}

/**
 * Download all videos sequentially with progress tracking
 * @param {Array<Object>} videos - Array of video information objects
 * @returns {Promise<{success: boolean, downloaded: number, failed: number, errors: Array<string>}>}
 */
async function downloadAllVideos(videos) {
  console.log(`Starting download of ${videos.length} videos`);
  
  let downloaded = 0;
  let failed = 0;
  const errors = [];
  
  // Update state to downloading phase
  state.currentPhase = 'downloading';
  state.downloadProgress.total = videos.length;
  state.downloadProgress.current = 0;
  state.downloadProgress.filename = null;
  await saveState();
  
  for (let i = 0; i < videos.length; i++) {
    const video = videos[i];
    
    // Update progress
    state.downloadProgress.current = i + 1;
    state.downloadProgress.filename = video.filename || `video_${i}`;
    await saveState();
    
    console.log(`Downloading video ${i + 1}/${videos.length}: ${video.url}`);
    
    // Send download progress notification to content script
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.id) {
        await chrome.tabs.sendMessage(tab.id, {
          type: 'DOWNLOAD_PROGRESS',
          current: state.downloadProgress.current,
          total: state.downloadProgress.total,
          filename: state.downloadProgress.filename
        });
      }
    } catch (error) {
      console.log('Could not send download progress to content script:', error.message);
      // Non-critical error, continue with download
    }
    
    // Download the video
    const result = await downloadVideo(video, 0);
    
    if (result.success) {
      downloaded++;
      state.downloadStats.totalDownloaded++;
      console.log(`Successfully downloaded: ${result.filename}`);
    } else {
      failed++;
      state.downloadStats.totalFailed++;
      errors.push(`Video ${i + 1}: ${result.error}`);
      console.error(`Failed to download video ${i + 1}: ${result.error}`);
    }
    
    await saveState();
    
    // Add delay between downloads (except after the last one)
    if (i < videos.length - 1) {
      console.log(`Waiting ${state.config.downloadDelay}ms before next download...`);
      await new Promise(resolve => setTimeout(resolve, state.config.downloadDelay));
    }
  }
  
  // Reset download progress and transition to waiting phase
  state.downloadProgress.current = 0;
  state.downloadProgress.total = 0;
  state.downloadProgress.filename = null;
  state.currentPhase = 'waiting';
  await saveState();
  
  console.log(`Download complete: ${downloaded} succeeded, ${failed} failed`);
  
  return {
    success: failed === 0,
    downloaded: downloaded,
    failed: failed,
    errors: errors
  };
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

// Helper function to show notifications
async function showNotification(title, message) {
  try {
    await chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/.gitkeep',
      title: title,
      message: message,
      priority: 2
    });
  } catch (error) {
    console.error('Error showing notification:', error);
  }
}

// Alarm listener - triggers pasteNextPrompt every 5 minutes
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'promptPasterAlarm') {
    console.log('Alarm triggered, pasting next prompt');
    
    // Only paste if session is still running
    if (state.isRunning) {
      await pasteNextPrompt();
    }
  }
});

// Get current status including time until next paste
async function getStatus() {
  try {
    let timeUntilNextPaste = null;
    
    // Calculate time until next paste if session is running
    if (state.isRunning && state.nextPasteTime) {
      const now = Date.now();
      timeUntilNextPaste = Math.max(0, state.nextPasteTime - now);
    }
    
    // Get alarm info to verify next paste time
    if (state.isRunning) {
      const alarm = await chrome.alarms.get('promptPasterAlarm');
      if (alarm && alarm.scheduledTime) {
        const now = Date.now();
        timeUntilNextPaste = Math.max(0, alarm.scheduledTime - now);
      }
    }
    
    return {
      isRunning: state.isRunning,
      currentIndex: state.currentIndex,
      totalPrompts: state.prompts.length,
      nextPasteTime: state.nextPasteTime,
      timeUntilNextPaste: timeUntilNextPaste,
      currentPhase: state.currentPhase,
      downloadProgress: state.downloadProgress,
      downloadStats: state.downloadStats
    };
  } catch (error) {
    console.error('Error getting status:', error);
    return {
      isRunning: state.isRunning,
      currentIndex: state.currentIndex,
      totalPrompts: state.prompts.length,
      nextPasteTime: state.nextPasteTime,
      timeUntilNextPaste: null,
      currentPhase: state.currentPhase,
      downloadProgress: state.downloadProgress,
      downloadStats: state.downloadStats
    };
  }
}

// Initialize state on service worker startup
loadState();

// Message listener to handle commands from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Received message:', message);
  
  if (message.type === 'LOAD_PROMPTS') {
    loadPrompts(message.prompts).then(sendResponse);
    return true; // Keep channel open for async response
  }
  
  if (message.type === 'START_SESSION') {
    startSession().then(sendResponse);
    return true; // Keep channel open for async response
  }
  
  if (message.type === 'STOP_SESSION') {
    stopSession().then(sendResponse);
    return true; // Keep channel open for async response
  }
  
  if (message.type === 'GET_STATUS') {
    getStatus().then(sendResponse);
    return true; // Keep channel open for async response
  }
});
