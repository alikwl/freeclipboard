// Flow Automator Pro - Merged Logic v2.5

// API Configuration
const API_URL = 'https://flow-backend-bsax256si-oxixxa-gmailcoms-projects.vercel.app/api/verify';

// === UI Elements (Global to be accessible) ===
const UI = {
  // Views
  loginView: document.getElementById('login-view'),
  appView: document.getElementById('app-view'),

  // Login Elements
  licenseInput: document.getElementById('licenseKey'),
  activateBtn: document.getElementById('activateBtn'),
  loginStatus: document.getElementById('status'),
  mainHeaderBtn: document.getElementById('btnHealthCheck'),
  licenseExpiry: document.getElementById('licenseExpiry'),
  licenseUser: document.getElementById('licenseUser'), // New

  // Dashboard - Status
  statusIndicator: document.getElementById('statusIndicator'),
  statusText: document.getElementById('statusText'),
  phaseText: document.getElementById('phaseText'),
  progressText: document.getElementById('progressText'),
  progressBar: document.getElementById('progressBar'),
  timerSection: document.getElementById('timerSection'),
  timerValue: document.getElementById('timerValue'),

  // Dashboard - File
  fileUploadArea: document.getElementById('fileUploadArea'),
  fileInput: document.getElementById('fileInput'),
  fileInfo: document.getElementById('fileInfo'),
  fileInfoText: document.getElementById('fileInfoText'),

  // Dashboard - Settings
  promptInterval: document.getElementById('promptInterval'),
  autoDl: document.getElementById('autoDl'),
  retryFailed: document.getElementById('retryFailed'),

  // Dashboard - Buttons
  btnStart: document.getElementById('btnStart'),
  btnStop: document.getElementById('btnStop'),
  btnResume: document.getElementById('btnResume'),
  btnSkip: document.getElementById('btnSkip'),
  btnReset: document.getElementById('btnReset'),
  btnHealthCheck: document.getElementById('btnHealthCheck'),
  btnExportLogs: document.getElementById('btnExportLogs'),
  btnDownloadFailed: document.getElementById('btnDownloadFailed'),
  btnClearLogs: document.getElementById('btnClearLogs'),

  // Dashboard - Logs
  logs: document.getElementById('logs'),

  // Dashboard - Health Check
  healthResults: document.getElementById('healthResults'),
  healthContent: document.getElementById('healthContent'),
  btnCloseHealth: document.getElementById('btnCloseHealth')
};

// === State ===
let currentState = {};
let dashboardInterval = null;

// === Initialization ===
document.addEventListener('DOMContentLoaded', initApp);

async function initApp() {
  console.log('🚀 App Initializing...');

  // 1. License Check
  const stored = await chrome.storage.local.get(['licenseKey', 'expiryDate', 'machineId', 'userName']);
  let machineId = stored.machineId;

  console.log("Stored Name:", stored.userName); // DEBUG: User requested check

  // Ensure Machine ID exists
  if (!machineId) {
    machineId = 'user-' + Math.random().toString(36).substring(2, 11) + '-' + Date.now().toString(36);
    await chrome.storage.local.set({ machineId });
  }

  // Check if valid license exists
  let isValid = false;
  let isExpired = false;

  if (stored.licenseKey && stored.expiryDate) {
    const expiry = new Date(stored.expiryDate);
    const today = new Date();

    // Display Expiry
    if (UI.licenseExpiry) {
      UI.licenseExpiry.textContent = `Expires: ${expiry.toISOString().split('T')[0]}`;
      UI.licenseExpiry.classList.remove('hidden'); // Fixed: Show badge
    }

    // Display User Name
    if (UI.licenseUser) {
      const name = stored.userName || "Valued Customer";
      UI.licenseUser.textContent = `Licensed to: ${name}`;
      UI.licenseUser.classList.remove('hidden');
    }

    if (today.getTime() < expiry.getTime()) {
      isValid = true;
    } else {
      isExpired = true;
    }
  }

  if (isValid) {
    showDashboard();
  } else {
    // Fill previous key if exists
    if (stored.licenseKey) UI.licenseInput.value = stored.licenseKey;

    if (isExpired) {
      showLogin();
      showLoginStatus('License Expired. Contact +923325500752 for a new key', 'error');
    } else {
      showLogin();
    }
    // If Name is default, try to refresh silently in background
    if (stored.userName === "Valued Customer" || !stored.userName) {
      console.log("Triggering silent name refresh...");
      silentVerify(stored.licenseKey, machineId);
    }
  }

  // 2. Bind Login Events
  UI.activateBtn.addEventListener('click', () => handleActivation(machineId));
  UI.licenseInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleActivation(machineId);
  });
}

async function silentVerify(key, machineId) {
  if (!key) return;
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ licenseKey: key, machineId: machineId })
    });
    const data = await response.json();
    if (data.success && data.name) {
      console.log("Silent refresh success. New name:", data.name);
      await chrome.storage.local.set({ userName: data.name });
      if (UI.licenseUser) {
        UI.licenseUser.textContent = `Licensed to: ${data.name}`;
        UI.licenseUser.classList.remove('hidden');
      }
    }
  } catch (e) {
    console.log("Silent verify failed:", e);
  }
}

function showLogin() {
  UI.loginView.classList.remove('hidden');
  UI.appView.classList.add('hidden');
  UI.mainHeaderBtn.classList.add('hidden');
}

function showDashboard() {
  UI.loginView.classList.add('hidden');
  UI.appView.classList.remove('hidden');
  UI.mainHeaderBtn.classList.remove('hidden');
  initDashboardLogic();
}

async function handleActivation(machineId) {
  const licenseKey = UI.licenseInput.value.trim();

  if (!licenseKey) {
    showLoginStatus('❌ Please enter a license key', 'error');
    return;
  }

  UI.activateBtn.disabled = true;
  UI.activateBtn.textContent = 'Verifying...';

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        licenseKey: licenseKey,
        machineId: machineId
      })
    });

    const data = await response.json();

    if (data.success) {
      // Save license & Name
      await chrome.storage.local.set({
        licenseKey: licenseKey,
        expiryDate: data.expiry,
        userName: data.name // Save Name
      });

      // Update Expiry Display
      if (UI.licenseExpiry && data.expiry) {
        const expiry = new Date(data.expiry);
        UI.licenseExpiry.textContent = `Expires: ${expiry.toISOString().split('T')[0]}`;
        UI.licenseExpiry.classList.remove('hidden'); // Fixed: Show badge
      }

      // Update Name Display
      if (UI.licenseUser) {
        const name = data.name || "Valued Customer";
        UI.licenseUser.textContent = `Licensed to: ${name}`;
        UI.licenseUser.classList.remove('hidden');
      }

      showLoginStatus(`Welcome, ${data.name || 'User'}! License Active.`, 'success');
      setTimeout(showDashboard, 1000);
    } else {
      const errorMsg = data.message || 'Invalid Key';
      if (errorMsg.toLowerCase().includes('expired')) {
        showLoginStatus('License Expired. Contact +923325500752 for a new key', 'error');
      } else if (errorMsg.includes('another device')) {
        showLoginStatus(`🔒 Locked: ${errorMsg}`, 'locked');
      } else {
        showLoginStatus(`❌ ${errorMsg}`, 'error');
      }
    }
  } catch (error) {
    console.error('Activation error:', error);
    showLoginStatus('❌ Connection failed', 'error');
  }

  UI.activateBtn.disabled = false;
  UI.activateBtn.textContent = 'Activate License';
}

function showLoginStatus(msg, type) {
  UI.loginStatus.textContent = msg;
  UI.loginStatus.className = 'status ' + type;
}

// ==========================================
//DASHBOARD LOGIC (From Old Ext)
// ==========================================

async function initDashboardLogic() {
  console.log('🚀 Dashboard Logic Started');

  // Bind event listeners
  bindDashboardEvents();

  // Initial state sync
  await syncState();

  // Poll for updates
  if (dashboardInterval) clearInterval(dashboardInterval);
  dashboardInterval = setInterval(syncState, 1000);

  // Listen for log pushes
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'LOG_UPDATE') {
      appendLog(msg.entry);
    }
  });
}

function bindDashboardEvents() {
  // File upload
  UI.fileUploadArea.addEventListener('click', () => UI.fileInput.click());
  UI.fileInput.addEventListener('change', handleFileLoad);

  // Drag and drop
  UI.fileUploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    UI.fileUploadArea.style.borderColor = '#667eea';
  });
  UI.fileUploadArea.addEventListener('dragleave', () => {
    UI.fileUploadArea.style.borderColor = '';
  });
  UI.fileUploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    UI.fileUploadArea.style.borderColor = '';
    if (e.dataTransfer.files[0]) {
      UI.fileInput.files = e.dataTransfer.files;
      handleFileLoad({ target: { files: e.dataTransfer.files } });
    }
  });

  // Control buttons
  UI.btnStart.addEventListener('click', handleStart);
  UI.btnStop.addEventListener('click', handleStop);
  UI.btnResume.addEventListener('click', handleResume);
  UI.btnSkip.addEventListener('click', handleSkip);
  UI.btnReset.addEventListener('click', handleReset);

  // Utility buttons
  UI.btnHealthCheck.addEventListener('click', handleHealthCheck);
  UI.btnExportLogs.addEventListener('click', handleExportLogs);
  UI.btnDownloadFailed.addEventListener('click', handleDownloadFailed);
  UI.btnClearLogs.addEventListener('click', handleClearLogs);
  UI.btnCloseHealth.addEventListener('click', () => {
    UI.healthResults.classList.add('hidden');
  });
}

// ... COPY OF STATE MANAGEMENT & HANDLERS ...

async function syncState() {
  try {
    const state = await chrome.runtime.sendMessage({ type: 'GET_STATUS' });
    if (state) {
      currentState = state;
      render(state);
    }
  } catch (e) {
    // console.log('Sync error (bg might be sleeping)', e);
  }
}

function render(state) {
  // Status indicator
  UI.statusIndicator.className = 'status-indicator ' + state.status.toLowerCase();
  UI.statusText.textContent = getStatusText(state.status);
  UI.phaseText.textContent = state.phase || 'IDLE';

  // Progress
  const total = state.prompts?.length || 0;
  const current = state.currentIndex || 0;
  let displayCurrent = current;
  if (state.status === 'IDLE' && current >= total && total > 0) {
    displayCurrent = total;
  }
  const progress = total > 0 ? Math.round((displayCurrent / total) * 100) : 0;
  UI.progressText.textContent = `${displayCurrent} / ${total}`;
  UI.progressBar.style.width = `${progress}%`;

  // Timer
  if (state.status === 'RUNNING' && state.timerEndTime) {
    UI.timerSection.classList.remove('hidden');
    updateTimer(state.timerEndTime);
  } else {
    UI.timerSection.classList.add('hidden');
  }

  // Button states
  UI.btnStart.disabled = state.status === 'RUNNING' || total === 0;
  UI.btnStop.disabled = state.status !== 'RUNNING' && state.status !== 'PAUSED';

  const canResume = state.status === 'PAUSED' || (state.status === 'IDLE' && current > 0 && current < total);
  UI.btnResume.classList.toggle('hidden', !canResume);
  UI.btnSkip.classList.toggle('hidden', state.status !== 'RUNNING');

  // Logs (First load)
  if (UI.logs.children.length === 0 && state.logs?.length > 0) {
    UI.logs.innerHTML = '';
    state.logs.slice(-50).reverse().forEach(appendLog);
  }

  // Failed downloads
  const failedCount = state.failedPrompts?.length || 0;
  UI.btnDownloadFailed.classList.toggle('hidden', failedCount === 0);
}

function updateTimer(targetTime) {
  const diff = Math.max(0, Math.ceil((targetTime - Date.now()) / 1000));
  const minutes = Math.floor(diff / 60);
  const seconds = diff % 60;
  UI.timerValue.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

function getStatusText(status) {
  switch (status) {
    case 'RUNNING': return 'Running';
    case 'PAUSED': return 'Paused';
    case 'IDLE': return 'Ready';
    default: return status;
  }
}

// === Action Handlers ===

async function handleFileLoad(e) {
  const file = e.target.files[0];
  if (!file) return;

  try {
    const text = await file.text();
    const prompts = text.split(/\n\s*\n/).map(p => p.trim()).filter(p => p.length > 0);

    if (prompts.length > 0) {
      await chrome.runtime.sendMessage({ type: 'CMD_LOAD_PROMPTS', prompts });
      UI.fileInfo.classList.remove('hidden');
      UI.fileInfoText.textContent = `${prompts.length} prompts loaded`;
      appendLog({ timestamp: new Date().toISOString(), message: `Loaded ${prompts.length} prompts from "${file.name}"`, type: 'success' });
      await syncState();
    } else {
      showError('No valid prompts found');
    }
  } catch (e) {
    showError('Failed to read file: ' + e.message);
  }
}

async function handleStart() {
  UI.btnStart.disabled = true;

  let interval = parseInt(UI.promptInterval.value);
  if (isNaN(interval) || interval < 10) {
    interval = 120;
    UI.promptInterval.value = "120"; // Reset UI to valid default
    showError('Invalid interval. Resetting to 120s.');
  }

  const config = {
    promptIntervalSeconds: interval,
    autoDownload: UI.autoDl.checked,
    retryEnabled: UI.retryFailed.checked
  };
  try {
    await chrome.runtime.sendMessage({ type: 'CMD_START', config });
    await syncState();
  } catch (e) {
    showError('Start failed: ' + e.message);
    UI.btnStart.disabled = false;
  }
}

async function handleStop() {
  await chrome.runtime.sendMessage({ type: 'CMD_STOP' });
  await syncState();
}

async function handleResume() {
  await chrome.runtime.sendMessage({ type: 'CMD_RESUME' });
  await syncState();
}

async function handleSkip() {
  await chrome.runtime.sendMessage({ type: 'CMD_SKIP' });
  await syncState();
}

async function handleReset() {
  if (confirm('Reset all data?')) {
    await chrome.runtime.sendMessage({ type: 'CMD_RESET' });
    UI.logs.innerHTML = '';
    UI.fileInfo.classList.add('hidden');
    await syncState();
  }
}

function appendLog(entry) {
  const div = document.createElement('div');
  div.className = 'log-entry';
  const time = new Date(entry.timestamp).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
  div.innerHTML = `<span class="log-time">[${time}]</span><span class="log-${entry.type || 'info'}">${entry.message}</span>`;
  UI.logs.insertBefore(div, UI.logs.firstChild);
  while (UI.logs.children.length > 100) UI.logs.removeChild(UI.logs.lastChild);
}

function showError(msg) {
  appendLog({ timestamp: new Date().toISOString(), message: msg, type: 'error' });
}

// Health check stuff...
async function handleHealthCheck() {
  // ... Simplified health check call ...
  UI.healthResults.classList.remove('hidden');
  UI.healthContent.innerHTML = 'Running...';
  // Logic similar to original file
  // Get active tab
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];

  if (!tab || !tab.url?.includes('labs.google')) {
    UI.healthContent.textContent = 'Not on Flow website';
    return;
  }

  // Send health check to content script
  try {
    const result = await chrome.tabs.sendMessage(tab.id, { type: 'HEALTH_CHECK' });
    UI.healthContent.textContent = result ? 'Connected!' : 'Script error';
  } catch (e) {
    UI.healthContent.textContent = 'Connection Error';
  }
}

// Helper
function handleExportLogs() { }
function handleDownloadFailed() { }
function handleClearLogs() { UI.logs.innerHTML = ''; }
