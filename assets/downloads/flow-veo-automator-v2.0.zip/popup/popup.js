// DOM Elements
const fileInput = document.getElementById('fileInput');
const fileStatus = document.getElementById('fileStatus');
const startStopBtn = document.getElementById('startStopBtn');
const sessionStatus = document.getElementById('sessionStatus');
const phaseInfo = document.getElementById('phaseInfo');
const promptInfo = document.getElementById('promptInfo');
const timerInfo = document.getElementById('timerInfo');
const downloadProgress = document.getElementById('downloadProgress');
const downloadStats = document.getElementById('downloadStats');
const errorDisplay = document.getElementById('errorDisplay');

// State
let loadedPrompts = [];
let isRunning = false;

// Initialize popup
document.addEventListener('DOMContentLoaded', () => {
  fileInput.addEventListener('change', handleFileSelection);
  startStopBtn.addEventListener('click', handleStartStop);
  
  // Request initial status from background
  requestStatus();
  
  // Poll for status updates every second when popup is open
  setInterval(requestStatus, 1000);
});

// Handle file selection and parsing
async function handleFileSelection(event) {
  const file = event.target.files[0];
  
  if (!file) {
    return;
  }
  
  // Clear any previous errors
  clearError();
  
  try {
    const content = await readFileContent(file);
    
    // Validate file is not empty
    if (!content.trim()) {
      showError('No prompts found in file. Please ensure the file contains text.');
      clearFileSelection();
      return;
    }
    
    // Parse prompts from file content
    const prompts = parsePrompts(content);
    
    if (prompts.length === 0) {
      showError('No prompts found in file. Prompts should be separated by blank lines.');
      clearFileSelection();
      return;
    }
    
    // Store prompts
    loadedPrompts = prompts;
    
    // Send prompts to background
    const response = await sendMessage({ type: 'LOAD_PROMPTS', prompts: prompts });
    
    if (!response || !response.success) {
      showError('Failed to load prompts. Please try again.');
      clearFileSelection();
      return;
    }
    
    // Update UI
    fileStatus.textContent = `Loaded ${prompts.length} prompt${prompts.length === 1 ? '' : 's'}`;
    fileStatus.className = 'status-text success';
    startStopBtn.disabled = false;
    clearError();
    
  } catch (error) {
    console.error('File loading error:', error);
    
    // Provide specific error messages based on error type
    if (error.name === 'EncodingError' || error.message.includes('encoding')) {
      showError('Unable to read file. Please use UTF-8 encoded text file.');
    } else if (error.message.includes('read')) {
      showError('Failed to read file. Please check file permissions and try again.');
    } else {
      showError('Failed to load file. Please try again.');
    }
    
    clearFileSelection();
  }
}

// Read file content as text
function readFileContent(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      resolve(e.target.result);
    };
    
    reader.onerror = () => {
      reject(new Error('Failed to read file'));
    };
    
    // Read as UTF-8 text
    reader.readAsText(file, 'UTF-8');
  });
}

// Parse prompts from file content
// Splits by blank line gaps (one or more consecutive newlines)
function parsePrompts(content) {
  // Split by one or more consecutive newlines (blank line gaps)
  // This regex matches one or more newlines with optional whitespace between them
  const prompts = content
    .split(/\n\s*\n+/)
    .map(prompt => prompt.trim())
    .filter(prompt => prompt.length > 0);
  
  return prompts;
}

// Handle Start/Stop button click
async function handleStartStop() {
  clearError();
  
  if (isRunning) {
    // Stop session
    try {
      const response = await sendMessage({ type: 'STOP_SESSION' });
      
      if (!response || !response.success) {
        showError('Failed to stop session. Please try again.');
      }
    } catch (error) {
      console.error('Error stopping session:', error);
      showError('Failed to stop session. Please try again.');
    }
  } else {
    // Start session
    if (loadedPrompts.length === 0) {
      showError('Please load a prompt file first before starting.');
      return;
    }
    
    try {
      const response = await sendMessage({ type: 'START_SESSION' });
      
      if (!response || !response.success) {
        if (response && response.error) {
          showError(`Failed to start session: ${response.error}`);
        } else {
          showError('Failed to start session. Please try again.');
        }
      }
    } catch (error) {
      console.error('Error starting session:', error);
      showError('Failed to start session. Please ensure you are on the Flow website.');
    }
  }
  
  // Request updated status
  requestStatus();
}

// Request status from background
async function requestStatus() {
  try {
    const response = await sendMessage({ type: 'GET_STATUS' });
    updateUI(response);
  } catch (error) {
    // Background might not be ready yet, ignore
  }
}

// Update UI based on status
function updateUI(status) {
  if (!status) {
    return;
  }
  
  isRunning = status.isRunning;
  
  // Update button
  if (isRunning) {
    startStopBtn.textContent = 'Stop';
    startStopBtn.className = 'btn btn-stop';
  } else {
    startStopBtn.textContent = 'Start';
    startStopBtn.className = 'btn';
  }
  
  // Update session status
  if (isRunning) {
    sessionStatus.textContent = 'Running';
    sessionStatus.className = 'status-text running';
  } else if (status.currentIndex > 0 && status.currentIndex >= status.totalPrompts) {
    sessionStatus.textContent = 'Completed';
    sessionStatus.className = 'status-text completed';
  } else {
    sessionStatus.textContent = 'Idle';
    sessionStatus.className = 'status-text';
  }
  
  // Update current phase display
  if (isRunning && status.currentPhase) {
    const phaseText = getPhaseDisplayText(status.currentPhase);
    phaseInfo.textContent = `Phase: ${phaseText}`;
    phaseInfo.style.display = 'block';
  } else {
    phaseInfo.textContent = '';
    phaseInfo.style.display = 'none';
  }
  
  // Update prompt info
  if (status.totalPrompts > 0) {
    promptInfo.textContent = `Prompt ${status.currentIndex + 1} of ${status.totalPrompts}`;
  } else {
    promptInfo.textContent = '';
  }
  
  // Update timer info
  if (isRunning && status.nextPasteTime) {
    const timeUntilNext = Math.max(0, Math.ceil((status.nextPasteTime - Date.now()) / 1000));
    const minutes = Math.floor(timeUntilNext / 60);
    const seconds = timeUntilNext % 60;
    timerInfo.textContent = `Next paste in: ${minutes}:${seconds.toString().padStart(2, '0')}`;
  } else {
    timerInfo.textContent = '';
  }
  
  // Update download progress display
  const downloadSection = document.querySelector('.download-section');
  if (status.downloadProgress && status.downloadProgress.total > 0) {
    downloadSection.classList.add('active');
    
    const current = status.downloadProgress.current;
    const total = status.downloadProgress.total;
    const filename = status.downloadProgress.filename;
    
    if (filename) {
      downloadProgress.textContent = `Downloading: ${filename} (${current} of ${total})`;
    } else {
      downloadProgress.textContent = `Download progress: ${current} of ${total} videos`;
    }
  } else if (status.currentPhase === 'downloading') {
    downloadSection.classList.add('active');
    downloadProgress.textContent = 'Preparing downloads...';
  } else {
    downloadSection.classList.remove('active');
    downloadProgress.textContent = '';
  }
  
  // Update download statistics display
  if (status.downloadStats && (status.downloadStats.totalDownloaded > 0 || status.downloadStats.totalFailed > 0)) {
    downloadSection.classList.add('active');
    
    const downloaded = status.downloadStats.totalDownloaded;
    const failed = status.downloadStats.totalFailed;
    
    let statsText = `Total: ${downloaded} downloaded`;
    if (failed > 0) {
      statsText += `, ${failed} failed`;
    }
    
    downloadStats.textContent = statsText;
  } else {
    downloadStats.textContent = '';
  }
}

// Helper function to get display text for current phase
function getPhaseDisplayText(phase) {
  const phaseMap = {
    'idle': 'Idle',
    'pasting': 'Pasting prompt',
    'generating': 'Waiting for generation',
    'downloading': 'Downloading videos',
    'waiting': 'Waiting for next prompt'
  };
  
  return phaseMap[phase] || phase;
}

// Send message to background service worker
function sendMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(response);
      }
    });
  });
}

// Show error message
function showError(message) {
  errorDisplay.textContent = message;
  errorDisplay.style.display = 'block';
}

// Clear error message
function clearError() {
  errorDisplay.textContent = '';
  errorDisplay.style.display = 'none';
}

// Clear file selection
function clearFileSelection() {
  fileInput.value = '';
  fileStatus.textContent = '';
  loadedPrompts = [];
  startStopBtn.disabled = true;
}
