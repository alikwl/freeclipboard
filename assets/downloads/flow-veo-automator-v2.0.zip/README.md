# Auto Prompt Paster Browser Extension

A browser extension that automatically pastes prompts from a text file at 5-minute intervals.

## Installation

1. Open Chrome/Edge and navigate to `chrome://extensions/`
2. Enable "Developer mode" in the top right
3. Click "Load unpacked"
4. Select this directory

## Usage

1. Click the extension icon in your browser toolbar
2. Choose a text file containing your prompts
3. Click "Start" to begin automatic pasting
4. The extension will paste prompts every 5 minutes

## Prompt File Format

Prompts should be separated by blank lines:

```
First prompt text here
This is still part of the first prompt

Second prompt text here

Third prompt text here
```

## Project Structure

```
├── manifest.json           # Extension configuration
├── popup/
│   ├── popup.html         # Popup UI
│   ├── popup.css          # Popup styles
│   └── popup.js           # Popup logic
├── background/
│   └── background.js      # Background service worker
├── content/
│   └── content.js         # Content script for DOM interaction
└── icons/                 # Extension icons (to be added)
```
