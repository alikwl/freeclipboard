(function () {
    function t(e) {
        e.preventDefault(), e.stopPropagation(), e.stopImmediatePropagation()
    }
    try {
        Object.defineProperty(Document.prototype, "visibilityState", {
            configurable: !0,
            get() {
                return "visible"
            }
        }), Object.defineProperty(Document.prototype, "webkitVisibilityState", {
            configurable: !0,
            get() {
                return "visible"
            }
        }), Object.defineProperty(Document.prototype, "hidden", {
            configurable: !0,
            get() {
                return !1
            }
        }), Object.defineProperty(Document.prototype, "webkitHidden", {
            configurable: !0,
            get() {
                return !1
            }
        })
    } catch { }
    document.addEventListener("visibilitychange", t, !0), document.addEventListener("webkitvisibilitychange", t, !0), window.addEventListener("pagehide", t, !0), window.addEventListener("blur", t, !0), window.addEventListener("focus", t, !0), window.addEventListener("mouseout", t, !0), window.addEventListener("mouseleave", t, !0), window.addEventListener("lostpointercapture", t, !0), Document.prototype.hasFocus = new Proxy(Document.prototype.hasFocus, {
        apply(e, n, r) {
            return !0
        }
    });
    let i = 0;
    window.requestAnimationFrame = function (e) {
        const n = Date.now(),
            r = Math.max(0, 16 - (n - i)),
            a = setTimeout(() => {
                e(performance.now())
            }, r);
        return i = n + r, a
    };
    const o = window.cancelAnimationFrame;
    window.cancelAnimationFrame = function (e) {
        return clearTimeout(e), o(e)
    }
})();