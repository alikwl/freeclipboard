// Force "Pro" state by default
let u = !0, // isLoggedIn = true
    i = "active", // subscriptionStatus = active
    n = "admin-user", // Mock user ID
    d = null;

// Removed the initial storage check that might reset these to false

// Stub helper functions to prevent ReferenceErrors
async function g() { return Promise.resolve(); }
async function f(t) { return Promise.resolve({ success: true, quotaData: {} }); }


function w() {
    const t = {
        isLoggedIn: u,
        subscriptionStatus: i,
        userId: n,
        lastUpdated: Date.now()
    };
    chrome.storage.local.set({
        authState: t
    }, () => { })
}
chrome.runtime.onInstalled.addListener(t => {
    if (chrome.storage.local.set({
        autoUpscale: !1,
        autoDownload: !0,
        delayBetweenPrompts: 5,
        createCSV: !0,
        authRequired: !0,
        quotaStatus: {
            isCheckingQuota: !1,
            canContinue: !0,
            lastChecked: Date.now()
        }
    }), t.reason === "install") {
        // Redirect removed
    }
});
chrome.sidePanel && chrome.sidePanel.setPanelBehavior({
    openPanelOnActionClick: !0
}).catch(t => { });

function b(t) {
    return t && t.includes("labs.google")
}

function m(t) {
    chrome.tabs.query({}, r => {
        r.forEach(e => {
            b(e.url) && chrome.tabs.sendMessage(e.id, {
                action: "sidepanelStateChanged",
                isOpen: t
            }).catch(() => { })
        })
    })
}
chrome.runtime.onConnect.addListener(t => {
    t.name === "sidepanel" && (m(!0), t.onDisconnect.addListener(() => {
        m(!1)
    }))
});
chrome.action.onClicked.addListener(t => {
    chrome.sidePanel && chrome.sidePanel.open({
        tabId: t.id
    }).catch(r => { }), t.url.includes("labs.google") || chrome.tabs.update(t.id, {
        url: "https://labs.google"
    })
});

function I(t, r, e, o = "") {
    try {
        const c = r.endsWith(".mp4") ? r : `${r}.mp4`,
            a = o ? `AutoLabs_flow/${o}/${c}` : `AutoLabs_flow/${c}`;
        chrome.downloads.download({
            url: t,
            filename: a,
            saveAs: !1,
            conflictAction: "uniquify"
        }, s => {
            chrome.runtime.lastError ? e({
                success: !1,
                error: chrome.runtime.lastError.message
            }) : (e({
                success: !0,
                downloadId: s,
                filename: c,
                path: a
            }), p(s, c))
        })
    } catch (c) {
        e({
            success: !1,
            error: c.message
        })
    }
}

function p(t, r) {
    const e = () => {
        chrome.downloads.search({
            id: t
        }, o => {
            if (o && o.length > 0) {
                const c = o[0];
                c.state === "complete" || c.state === "interrupted" || c.state === "in_progress" && setTimeout(e, 1e3)
            }
        })
    };
    setTimeout(e, 1e3)
}

function P(t, r, e) {
    try {
        const o = r.endsWith(".csv") ? r : `${r}.csv`,
            c = "AutoLabs_flow";
        chrome.downloads.download({
            url: t,
            filename: `${c}/${o}`,
            saveAs: !1,
            conflictAction: "uniquify"
        }, a => {
            chrome.runtime.lastError ? e({
                success: !1,
                error: chrome.runtime.lastError.message
            }) : (e({
                success: !0,
                downloadId: a,
                filename: o
            }), C(a, o))
        })
    } catch (o) {
        e({
            success: !1,
            error: o.message
        })
    }
}

function C(t, r) {
    const e = () => {
        chrome.downloads.search({
            id: t
        }, o => {
            if (o && o.length > 0) {
                const c = o[0];
                c.state === "complete" || c.state === "interrupted" || c.state === "in_progress" && setTimeout(e, 1e3)
            }
        })
    };
    setTimeout(e, 1e3)
}
let h = 0;
chrome.runtime.onMessage.addListener((t, r, e) => {
    var o, c;
    if (t.action === "updateProgress") {
        const a = h,
            s = t.processed - a;
        return s > 0 && n && (h = t.processed, f({
            action: "updateQuota",
            userId: n,
            newlyProcessed: s
        }).then(l => {
            l.success && chrome.runtime.sendMessage({
                action: "quotaUpdated",
                quotaData: l.quotaData
            }).catch(() => { })
        }).catch(l => { })), e({
            received: !0
        }), !0
    }
    if (t.action === "openSidePanel") {
        const a = (o = r.tab) == null ? void 0 : o.id;
        return !a || !chrome.sidePanel ? (e({
            success: !1,
            error: "No tab ID or sidePanel API unavailable"
        }), !0) : (chrome.sidePanel.open({
            tabId: a
        }).then(() => {
            e({
                success: !0
            })
        }).catch(s => {
            e({
                success: !1,
                error: s.message
            })
        }), !0)
    }
    if (t.action === "injectAntiThrottling") {
        const a = (c = r.tab) == null ? void 0 : c.id;
        return a ? (Promise.all([chrome.scripting.executeScript({
            target: {
                tabId: a
            },
            files: ["alwaysActive.js"],
            world: "MAIN"
        }).catch(() => null), chrome.scripting.executeScript({
            target: {
                tabId: a
            },
            files: ["alwaysActiveIsolated.js"],
            world: "ISOLATED"
        }).catch(() => null)]).then(() => {
            e({
                success: !0
            })
        }).catch(s => {
            e({
                success: !1,
                error: s.message
            })
        }), !0) : (e({
            success: !1,
            error: "No tab ID available"
        }), !0)
    }
    if (t.action === "downloadVideo") return I(t.url, t.filename, e, t.folderName), !0;
    if (t.action === "downloadCSV") return P(t.url, t.filename, e), !0;
    if (t.action === "signInWithGoogle") {
        // Mock success immediately
        e({ success: !0, token: "mock-token-bypass" });
        return !0;
    }
    if (t.action === "getAuthState") {
        const a = {
            isLoggedIn: u,
            subscriptionStatus: i,
            userId: n,
            timestamp: Date.now()
        };
        return e(a), !0
    } else if (t.action === "authStateChanged") {
        const a = u;
        return u = t.isLoggedIn, t.userId ? (n = t.userId, f({
            action: "setUserId",
            userId: n
        }).catch(s => { })) : t.isLoggedIn || (n = null, h = 0), t.subscriptionStatus !== void 0 && (i = t.subscriptionStatus), w(), S(), !a && u && (h = 0, chrome.storage.local.set({
            quotaStatus: {
                isCheckingQuota: !1,
                canContinue: !0,
                lastChecked: Date.now(),
                isPaid: i === "active"
            }
        }), g().catch(s => { })), e({
            success: !0
        }), !0
    } else {
        if (t.action === "authStateRefreshed") return e({
            received: !0
        }), !0;
        if (t.action === "getQuotaStatus") {
            // Always return unlimited
            e({
                canContinue: !0,
                isPaid: !0,
                status: "active",
                quotaUsed: 0,
                quotaLimit: 999999
            });
            return !0;
        }
        if (t.action === "updateQuotaStatus") {
            const a = {
                ...t.quotaStatus,
                lastChecked: Date.now(),
                isPaid: i === "active" || t.quotaStatus.isPaid
            };
            return chrome.storage.local.set({
                quotaStatus: a
            }, () => {
                e({
                    success: !0
                })
            }), !0
        }
    }
    return r.tab ? chrome.runtime.sendMessage(t).catch(a => { }) : (t.action === "startProcessing" || t.action === "stopProcessing") && chrome.tabs.query({
        active: !0,
        currentWindow: !0
    }, function (a) {
        a[0] && a[0].url.includes("labs.google") ? chrome.tabs.sendMessage(a[0].id, t).catch(s => { }) : t.action === "startProcessing" && chrome.tabs.update(a[0].id, {
            url: "https://labs.google"
        })
    }), e({
        received: !0
    }), !0
});

function S() {
    const t = {
        action: "authStateChanged",
        isLoggedIn: u,
        subscriptionStatus: i,
        userId: n,
        timestamp: Date.now()
    };
    chrome.tabs.query({}, r => {
        r.forEach(e => {
            e.url && e.url.includes("labs.google") && chrome.tabs.sendMessage(e.id, t).catch(o => { })
        })
    })
}
chrome.tabs.onActivated.addListener(t => {
    setTimeout(() => {
        chrome.tabs.get(t.tabId, r => {
            r && r.url && r.url.includes("labs.google") && chrome.tabs.sendMessage(t.tabId, {
                action: "authStateChanged",
                isLoggedIn: u,
                subscriptionStatus: i,
                userId: n,
                timestamp: Date.now()
            }).catch(e => { })
        })
    }, 500)
});
chrome.windows.onFocusChanged.addListener(t => {
    t !== chrome.windows.WINDOW_ID_NONE && setTimeout(() => {
        chrome.tabs.query({
            active: !0,
            windowId: t
        }, r => {
            r[0] && r[0].url && r[0].url.includes("labs.google") && chrome.tabs.sendMessage(r[0].id, {
                action: "authStateChanged",
                isLoggedIn: u,
                subscriptionStatus: i,
                userId: n,
                timestamp: Date.now()
            }).catch(e => { })
        })
    }, 500)
});
setInterval(() => {
    chrome.storage.local.get(["authState"], t => {
        if (t.authState) {
            const r = t.authState;
            Date.now() - r.lastUpdated > 10 * 60 * 1e3
        }
    })
}, 5 * 60 * 1e3);