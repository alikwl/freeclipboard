import {
    r as w,
    a as l,
    d as b,
    F as m,
    E as c,
    g as P
} from "./firebase.js";
async function U(a, i, s = c) {
    if (!a || i <= 0) return null;
    try {
        return await w(l, async e => {
            var D;
            const u = b(l, "users", a),
                r = await e.get(u);
            if (!r.exists()) return null;
            const t = (D = r.data().subscriptions) == null ? void 0 : D[s];
            if (!t) return null;
            if (t.status !== "trial") return {
                ...t,
                isPaid: !0
            };
            const p = t.trialEnd ? new Date > new Date(t.trialEnd.toDate()) : !1;
            if (p && t.status !== "expired") return e.update(u, {
                [`subscriptions.${s}.status`]: "expired"
            }), {
                status: "expired",
                plan: "trial",
                quota: t.quota || m,
                used: t.used || 0,
                remaining: 0,
                trialEnd: t.trialEnd ? t.trialEnd.toDate() : null
            };
            const h = t.used || 0,
                E = t.quota || m,
                o = h + i,
                d = Math.max(0, E - o),
                g = p || d <= 0 ? "expired" : "trial";
            return e.update(u, {
                [`subscriptions.${s}.used`]: o,
                [`subscriptions.${s}.remaining`]: d,
                [`subscriptions.${s}.status`]: g
            }), {
                status: g,
                plan: "trial",
                quota: E,
                used: o,
                remaining: d,
                trialEnd: t.trialEnd ? t.trialEnd.toDate() : null,
                isPaid: !1
            }
        })
    } catch {
        return null
    }
}
async function y(a, i = c) {
    var s;
    if (!a) return !1;
    try {
        const n = b(l, "users", a),
            e = await P(n);
        if (!e.exists()) return !1;
        const r = (s = e.data().subscriptions) == null ? void 0 : s[i];
        return r ? r.status === "active" || r.status === "active_canceling" : !1
    } catch {
        return !1
    }
}
chrome.runtime.onMessage.addListener((a, i, s) => {
    if (a.action === "updateQuota") {
        const {
            userId: n,
            newlyProcessed: e
        } = a;
        return y(n, c).then(u => {
            if (u) {
                s({
                    success: !0,
                    isPaid: !0,
                    quotaData: {
                        canContinue: !0,
                        isPaid: !0,
                        status: "active"
                    }
                });
                return
            }
            return U(n, e, c).then(r => {
                if (s({
                    success: !0,
                    quotaData: r,
                    isPaid: !1
                }), r) {
                    const f = {
                        canContinue: r.status !== "expired" && r.remaining > 0,
                        isPaid: !1,
                        remaining: r.remaining,
                        status: r.status,
                        lastUpdated: Date.now()
                    };
                    chrome.storage.local.set({
                        quotaStatus: f
                    })
                }
            })
        }).catch(u => {
            s({
                success: !1,
                error: u.message
            })
        }), !0
    }
    if (a.action === "setUserId") return a.userId, s({
        success: !0
    }), !0
});