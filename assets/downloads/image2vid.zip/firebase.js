
// Mock Firebase Implementation for Best Extension
// Optimized to bypass licensing and fix blank page

console.log('[FIREBASE-MOCK] Initializing robust bypass...');

// --- Constants & Config ---
const EXTENSION_ID = "flow-automator-pro"; // 'ht' export

// --- Mock Data ---
const mockUser = {
  uid: "bypass-user-id",
  email: "admin@bypass.com",
  displayName: "Admin User",
  emailVerified: true,
  isAnonymous: false,
  photoURL: "https://lh3.googleusercontent.com/a/default-user=s96-c",
  providerData: [{ providerId: "google.com" }],
  getIdToken: async () => "mock-token",
  getIdTokenResult: async () => ({
    token: "mock-token",
    claims: { admin: true, premium: true }
  }),
  reload: async () => { },
  toJSON: () => ({ ...mockUser })
};

const mockSubscription = {
  status: "active",
  plan: "pro",
  remaining: 999999,
  quota: 999999,
  trialEnd: new Date(2099, 11, 31).getTime()
};

// --- Mock Instances ---
const mockAuth = {
  currentUser: mockUser,
  signOut: async () => { console.log('[MOCK] SignOut intercepted'); return Promise.resolve(); },
  onAuthStateChanged: (cb) => {
    console.log('[MOCK] onAuthStateChanged called immediately');
    cb(mockUser);
    return () => { };
  },
  updateProfile: async () => Promise.resolve(),
  languageCode: 'en'
};

const mockFirestore = {
  type: 'firestore',
  app: {},
  toJSON: () => ({})
};

// --- Mock Functions ---

// d (doc)
const doc = (db, col, id, ...path) => {
  // console.log('[MOCK] doc:', col, id);
  return { path: `${col}/${id}` };
};

// g (getDoc)
const getDoc = async (ref) => {
  console.log('[MOCK] getDoc:', ref);
  return {
    exists: () => true,
    data: () => ({
      subscriptions: {
        [EXTENSION_ID]: mockSubscription
      },
      ...mockUser
    }),
    id: 'mock-doc-id'
  };
};

// k (collection)
const collection = (db, path) => {
  // console.log('[MOCK] collection:', path);
  return { path };
};

// q (query)
const query = (colRef, ...constraints) => {
  return { type: 'query', colRef, constraints };
};

// l (orderBy)
const orderBy = (field, dir) => ({ type: 'orderBy', field, dir });

// m (getDocs)
const getDocs = async (query) => {
  console.log('[MOCK] getDocs called');
  // Return empty list or list of mock items
  // If querying "ourproducts", return some mocks?
  return {
    docs: [],
    forEach: (cb) => [],
    empty: true,
    size: 0
  };
};

// n (onAuthStateChanged) - IMPORTED AS FUNCTION
const onAuthStateChanged = (auth, cb) => {
  if (cb) cb(mockUser);
  return () => { };
};

// i (Qi) - The mysterious user sync function
const Qi = async (user, extId) => {
  console.log('[MOCK] Qi (sync?) called with:', user?.email, extId);
  return Promise.resolve();
};

// --- Dummy Functions for Unknowns ---
const dummyAsync = async (...args) => { /* console.log('[MOCK] Dummy Async called', args); */ return {}; };
const dummySync = (...args) => { /* console.log('[MOCK] Dummy Sync called', args); */ return {}; };

// --- EXPORTS MAPPING ---
// Based on main.js imports:
// d -> Ca (doc)
// a -> hn (Firestore Instance)
// o -> bu (dummy)
// E -> ht (Extension ID string)
// g -> Ui (getDoc)
// u -> Hi (dummy)
// F -> Mr (dummy)
// s -> ju (dummy)
// c -> Nu (dummy)
// b -> xt (Auth Instance)
// e -> Cu (dummy)
// f -> Sl (dummy)
// h -> Pl (dummy)
// i -> Qi (Mystery Sync)
// j -> Lu (dummy)
// k -> Su (collection)
// q -> Pu (query)
// l -> Eu (orderBy)
// m -> Mu (getDocs)
// n -> _u (onAuthStateChanged)

export const d = doc;
export const a = mockFirestore; // Firestore Instance
export const o = dummyAsync;
export const E = EXTENSION_ID;
export const g = getDoc;
export const u = dummyAsync;
export const F = dummyAsync;
export const s = dummyAsync;
export const c = dummyAsync;
export const b = mockAuth; // Auth Instance
export const e = dummyAsync;
export const f = dummyAsync;
export const h = dummyAsync;
export const i = Qi;
export const j = dummyAsync;
export const k = collection;
export const q = query;
export const l = orderBy;
export const m = getDocs;
export const n = onAuthStateChanged;

// Additional defaults just in case
export default {
  initializeApp: () => { },
  getAuth: () => mockAuth,
  getFirestore: () => mockFirestore
};
