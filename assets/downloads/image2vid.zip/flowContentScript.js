// BTC Flow Automator PRO - Bismillah Tech Co
// License verification before processing

// License verification with server
async function verifyLicenseBeforeProcessing() {
  console.log('[BTC] Verifying license before automation...');
  const stored = await new Promise(resolve => {
    chrome.storage.local.get(['licenseKey', 'machineId', 'expiryDate'], resolve);
  });

  if (!stored.licenseKey || !stored.machineId) {
    return { valid: false, message: 'No license found. Please activate first.' };
  }

  try {
    const response = await fetch('https://flow-backend-wine.vercel.app/api/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        licenseKey: stored.licenseKey,
        machineId: stored.machineId
      })
    });
    const data = await response.json();

    if (data.success) {
      console.log('[BTC] License verified successfully');
      chrome.storage.local.set({ expiryDate: data.expiry });
      return { valid: true, expiry: data.expiry, name: data.name };
    } else {
      console.log('[BTC] License verification failed:', data.message);
      // Clear invalid license
      chrome.storage.local.remove(['licenseKey', 'expiryDate', 'machineId', 'userName']);
      return { valid: false, message: data.message };
    }
  } catch (error) {
    console.error('[BTC] License verification error:', error);
    // Allow offline use if expiry hasn't passed
    if (stored.expiryDate && new Date() < new Date(stored.expiryDate)) {
      return { valid: true, offline: true };
    }
    return { valid: false, message: 'Connection error. Please check internet.' };
  }
}

chrome.runtime.sendMessage({ action: "getAuthState" }, e => { e && (e.isLoggedIn, e.subscriptionStatus) }); let w = !1, u = 0, m = [], p = { autoDownload: !0, delayBetweenPrompts: 8e3, createCSV: !0, flowVideoCount: "1", flowModel: "default", flowAspectRatio: "landscape" }, H = 3, R = 0, E = [], k = !1, S = !1; const L = "flowAutomationState"; let V = null, D = new Set, Y = 5e3, T = new Set, c = [], M = 0, videoScanCount = 0, maxVideoScans = 60, preSubmissionVideos = new Set; const F = { RESULT_CONTAINER_XPATH: "//div[@data-index and @data-item-index]", PROMPT_IN_CONTAINER_XPATH: ".//button[normalize-space(.) != '' and following-sibling::div//text()[contains(., 'Veo')]]", VIDEOS_IN_CONTAINER_XPATH: ".//video[starts-with(@src, 'http')]", PROMPT_POLICY_ERROR_POPUP_XPATH: "//li[@data-sonner-toast and .//i[normalize-space(text())='error'] and not(.//*[contains(., '5')])]", QUEUE_FULL_POPUP_XPATH: "//li[@data-sonner-toast and .//i[normalize-space(text())='error'] and .//*[contains(., '5')]]", IMAGE_POLICY_ERROR_POPUP_XPATH: "//li[@data-sonner-toast and .//i[normalize-space(text())='error'] and not(.//*[contains(., '5')])]" }; async function O() { const e = { status: w ? "running" : "paused", isProcessing: w, prompts: m.map(t => t), currentIndex: u, totalPrompts: m.length, processedCount: u, currentPrompt: m[u] || "", settings: p, startTime: Date.now(), lastUpdate: Date.now(), promptToFlowMap: E, csvGenerated: S, taskList: c, currentTaskIndex: M }; return new Promise(t => { chrome.storage.local.set({ [L]: e }, () => { t(e) }) }) } async function z() { return new Promise(e => { chrome.storage.local.get(L, t => { const o = t[L]; e(o || null) }) }) } async function Q() { return new Promise(e => { chrome.storage.local.remove(L, () => { e() }) }) } (async function () { const t = await z(); t && t.status === "paused" && (m = t.prompts || [], u = t.currentIndex || 0, p = t.settings || p, E = t.promptToFlowMap || [], S = t.csvGenerated || !1, c = t.taskList || [], M = t.currentTaskIndex || 0, w = !1, console.log(`📋 Restored ${c.length} tasks from storage`), chrome.runtime.sendMessage({ action: "stateRestored", state: t }).catch(() => { }), c.length > 0 && c.forEach(o => P(o))) })(); function X() { return new Promise(e => { let t = 0; const o = 3, r = 1e3; function n() { chrome.runtime.sendMessage({ action: "getAuthState" }, a => { if (chrome.runtime.lastError) { if (t < o) { t++, setTimeout(n, r); return } e({ isLoggedIn: !1, subscriptionStatus: null, error: "Could not verify authentication state" }); return } a ? (a.isLoggedIn, a.subscriptionStatus, e(a)) : t < o ? (t++, setTimeout(n, r)) : e({ isLoggedIn: !1, subscriptionStatus: null, error: "No response from background script" }) }) } n() }) } chrome.runtime.onMessage.addListener(function (e, t, o) {
  const r = { received: !0 }; if (e.action === "startProcessing") return (async () => {
    // BTC License verification before processing
    const licenseCheck = await verifyLicenseBeforeProcessing();
    if (!licenseCheck.valid) {
      const errorMsg = licenseCheck.message || "License verification failed. Please check your license.";
      chrome.runtime.sendMessage({ action: "error", error: errorMsg });
      o({ ...r, error: errorMsg });
      return;
    }
    console.log('[BTC] License valid, proceeding with automation...');

    const n = await X();
    if (!n.isLoggedIn) { const a = n.error || "Authentication required. Please sign in first."; chrome.runtime.sendMessage({ action: "error", error: a }), o({ ...r, error: a }); return } if (w) o({ ...r, error: "Already processing" }); else { if (p = { ...p, ...e.settings, flowVideoCount: e.settings.flowVideoCount || p.flowVideoCount, flowModel: e.settings.flowModel || p.flowModel, flowAspectRatio: e.settings.flowAspectRatio || p.flowAspectRatio }, w = !0, u = 0, E = [], S = !1, e.useUnifiedQueue && e.queueTasks) console.log("🎯 Using UNIFIED QUEUE system"), c = e.queueTasks.map(a => { var i; return { queueTaskId: a.id, index: a.index, prompt: a.prompt, image: a.image, type: a.type === "text" ? "text-to-video" : "image-to-video", status: "pending", expectedVideos: parseInt((i = a.settings) == null ? void 0 : i.videoCount, 10) || 1, foundVideos: 0, videoUrls: [], settings: a.settings } }), m = c.map(a => a.prompt), console.log(`✅ Created ${c.length} tasks from unified queue (${c.filter(a => a.type === "text-to-video").length} text, ${c.filter(a => a.type === "image-to-video").length} image)`); else { console.log("⚠️ Using LEGACY task system"), m = e.prompts; const a = e.taskSettings || [], i = e.processingMode || "text", d = e.imagePairs || []; i === "image" && d.length > 0 ? (c = d.map((s, g) => { var y; return { index: g + 1, prompt: s.prompt, image: s.image, type: "image-to-video", status: "pending", expectedVideos: parseInt((y = s.settings) == null ? void 0 : y.videoCount, 10) || 1, foundVideos: 0, videoUrls: [], settings: s.settings } }), console.log(`✅ Created ${c.length} image-to-video tasks (legacy)`)) : (c = m.map((s, g) => { const y = a[g] || { videoCount: p.flowVideoCount, model: p.flowModel, aspectRatio: p.flowAspectRatio }; return { index: g + 1, prompt: s, type: "text-to-video", status: "pending", expectedVideos: parseInt(y.videoCount, 10) || 1, foundVideos: 0, videoUrls: [], settings: y } }), console.log(`✅ Created ${c.length} text-to-video tasks (legacy)`)) } M = 0, O(), N(), o({ ...r, started: !0 }) }
  })().catch(n => { chrome.runtime.sendMessage({ action: "error", error: "License verification failed. Please try again." }), o({ ...r, error: "License verification failed" }) }), !0; if (e.action === "resumeProcessing") return z().then(n => { n && n.status === "paused" ? (m = n.prompts || [], u = n.currentIndex || 0, p = n.settings || p, E = n.promptToFlowMap || [], S = n.csvGenerated || !1, c = n.taskList || [], M = n.currentTaskIndex || 0, w = !0, console.log(`▶️ Resuming Flow from prompt ${u + 1}/${m.length}`), console.log(`📋 Restored ${c.length} tasks`), O(), c.forEach(a => P(a)), N(), o({ ...r, resumed: !0 })) : o({ ...r, error: "No paused state to resume" }) }), !0; if (e.action === "stopProcessing") w = !1, O(), chrome.runtime.sendMessage({ action: "updateStatus", status: "Flow will pause after current prompt completes..." }), o(r); else if (e.action === "terminateProcessing") w = !1, m = [], u = 0, E = [], S = !1, D.clear(), c = [], M = 0, Q(), $(), C(), I(), o({ ...r, terminated: !0 }); else { if (e.action === "getStoredState") return z().then(n => { o({ ...r, state: n }) }), !0; if (e.action === "authStateChanged") e.isLoggedIn, e.subscriptionStatus, e.userId, o({ success: !0 }); else if (e.action === "clickNewProjectButton") { try { const n = h("//button[.//i[normalize-space()='add_2']]"); n ? (console.log("✅ New project button found. Clicking..."), n.click(), o({ success: !0 })) : (console.warn("⚠️ New project button not found"), o({ success: !1, error: "Button not found" })) } catch (n) { console.error("❌ Error clicking new project button:", n), o({ success: !1, error: n.message }) } return !0 } else o(r) }
}); document.addEventListener("visibilitychange", () => { document.hidden || setTimeout(() => { X().then(e => { chrome.runtime.sendMessage({ action: "authStateRefreshed", authState: e }).catch(() => { }) }) }, 500) }); window.addEventListener("focus", () => { setTimeout(() => { X().then(e => { chrome.runtime.sendMessage({ action: "authStateRefreshed", authState: e }).catch(() => { }) }) }, 500) }); function J(e) {
  if (document.getElementById("labs-flow-overlay")) { l(e); return } const t = document.createElement("div"); t.id = "labs-flow-overlay", t.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, rgba(10, 10, 10, 0.95), rgba(26, 26, 26, 0.9));
    backdrop-filter: blur(12px);
    z-index: 10000;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-family: 'Google Sans', 'Roboto', -apple-system, BlinkMacSystemFont, sans-serif;
  `; const o = document.createElement("div"); o.id = "labs-flow-message", o.style.cssText = `
    background: linear-gradient(145deg, rgba(20, 20, 20, 0.98), rgba(30, 30, 30, 0.95));
    backdrop-filter: blur(20px);
    padding: 32px;
    border-radius: 24px;
    max-width: 480px;
    min-width: 360px;
    text-align: center;
    box-shadow:
      0 24px 48px rgba(0, 0, 0, 0.5),
      0 0 40px rgba(255, 215, 0, 0.1),
      inset 0 1px 0 rgba(255, 255, 255, 0.05);
    border: 2px solid rgba(255, 215, 0, 0.3);
    transform: scale(0.95);
    animation: materialFadeIn 0.4s cubic-bezier(0.25, 0.8, 0.25, 1) forwards;
  `; const r = document.createElement("div"); r.style.cssText = `
    width: 80px;
    height: 80px;
    margin: 0 auto 24px auto;
    background: linear-gradient(135deg, #FFD700, #FFA500);
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 8px 24px rgba(255, 215, 0, 0.4);
    position: relative;
    overflow: hidden;
  `; const n = document.createElement("div"); n.innerHTML = `
    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#000" stroke-width="2">
      <path stroke-linecap="round" stroke-linejoin="round" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
    </svg>
  `, r.appendChild(n); const a = document.createElement("div"); a.style.cssText = `
    position: absolute;
    inset: 0;
    background: linear-gradient(45deg, transparent 30%, rgba(255, 255, 255, 0.3) 50%, transparent 70%);
    animation: iconShimmer 2s infinite;
  `, r.appendChild(a); const i = document.createElement("h2"); i.textContent = "BTC Flow Automator PRO", i.style.cssText = `
    font-size: 24px;
    font-weight: 700;
    margin: 0 0 8px 0;
    background: linear-gradient(135deg, #FFD700, #FFA500);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    letter-spacing: -0.5px;
  `; const d = document.createElement("p"); d.id = "labs-flow-message-text", d.textContent = e || "Processing...", d.style.cssText = `
    font-size: 16px;
    margin: 0 0 20px 0;
    color: #ccc;
    line-height: 1.5;
    font-weight: 400;
  `; const s = document.createElement("div"); s.id = "labs-flow-progress", s.style.cssText = `
    background: linear-gradient(90deg, rgba(255, 215, 0, 0.1), rgba(255, 215, 0, 0.05));
    border-radius: 12px;
    padding: 16px;
    margin: 20px 0;
    border: 1px solid rgba(255, 215, 0, 0.2);
  `; const g = document.createElement("p"); g.textContent = `Flow Prompt: ${u + 1}/${m.length}`, g.style.cssText = `
    font-size: 14px;
    margin: 0 0 12px 0;
    color: #adddff;
    font-weight: 500;
  `; const y = document.createElement("div"); y.style.cssText = `
    width: 100%;
    height: 6px;
    background: rgba(173, 221, 255, 0.15);
    border-radius: 3px;
    overflow: hidden;
    position: relative;
  `; const x = document.createElement("div"); x.style.cssText = `
    height: 100%;
    background: linear-gradient(90deg, #adddff, #60a5fa);
    border-radius: 3px;
    width: 0%;
    animation: progressPulse 2s ease-in-out infinite;
    transition: width 0.3s ease;
  `, y.appendChild(x), s.appendChild(g), s.appendChild(y); const b = document.createElement("div"); b.style.cssText = `
    display: flex;
    gap: 12px;
    margin-top: 24px;
    justify-content: center;
  `; const v = document.createElement("button"); v.textContent = "Cancel Processing", v.style.cssText = `
    background: linear-gradient(135deg, #dc2626, #ef4444);
    border: none;
    color: white;
    padding: 12px 24px;
    font-size: 14px;
    font-weight: 500;
    border-radius: 12px;
    cursor: pointer;
    transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);
    box-shadow: 0 4px 12px rgba(220, 38, 38, 0.25);
    font-family: inherit;
  `, v.addEventListener("mouseenter", () => { v.style.transform = "translateY(-2px)", v.style.boxShadow = "0 6px 20px rgba(220, 38, 38, 0.35)" }), v.addEventListener("mouseleave", () => { v.style.transform = "translateY(0)", v.style.boxShadow = "0 4px 12px rgba(220, 38, 38, 0.25)" }), v.addEventListener("click", () => { w = !1, I(), chrome.runtime.sendMessage({ action: "updateStatus", status: "Flow processing canceled by user" }) }), b.appendChild(v); const _ = document.createElement("style"); _.textContent = `
    @keyframes materialFadeIn {
      0% {
        opacity: 0;
        transform: scale(0.9) translateY(20px);
      }
      100% {
        opacity: 1;
        transform: scale(1) translateY(0);
      }
    }
    
    @keyframes iconShimmer {
      0% { transform: translateX(-100%); }
      100% { transform: translateX(200%); }
    }
    
    @keyframes progressPulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.7; }
    }
  `, document.head.appendChild(_), o.appendChild(r), o.appendChild(i), o.appendChild(d), o.appendChild(s), o.appendChild(b), t.appendChild(o), document.body.appendChild(t); const K = (u + 1) / m.length * 100; setTimeout(() => { x.style.width = `${Math.min(K, 100)}%` }, 100)
} function l(e, t) {
  const o = document.getElementById("labs-flow-message-text"), r = document.getElementById("labs-flow-progress"), lic = document.getElementById("labs-flow-license");

  // Create Log Container if missing
  let logs = document.getElementById("labs-flow-logs");
  if (!logs && o?.parentNode) {
    logs = document.createElement("div");
    logs.id = "labs-flow-logs";
    logs.style.cssText = "margin-top: 10px; max-height: 100px; overflow-y: auto; font-size: 10px; color: rgba(255,255,255,0.7); background: rgba(0,0,0,0.2); padding: 5px; border-radius: 4px; display: flex; flex-direction: column-reverse;";
    o.parentNode.appendChild(logs);
  }

  // Inject license display if missing
  if (!lic) {
    const footer = o?.parentNode?.parentNode?.lastChild; // Button container
    if (footer) {
      const d = document.createElement("div");
      d.id = "labs-flow-license";
      d.style.cssText = "font-size: 10px; color: rgba(255,255,255,0.6); margin-top: 5px; text-align: center;";
      d.textContent = "License: Active • Expires: Never (Lifetime)";
      o?.parentNode?.appendChild(d);
    }
  }

  if (o && e) {
    o.textContent = e;
    // Append to logs
    if (logs) {
      const entry = document.createElement("div");
      entry.textContent = `[${new Date().toLocaleTimeString()}] ${e}`;
      logs.prepend(entry);
      if (logs.children.length > 50) logs.lastChild.remove();
    }
  }

  r && t !== void 0 && (r.textContent = `Flow Prompt: ${t + 1}/${m.length}`)
} function I() { const e = document.getElementById("labs-flow-overlay"); e && document.body.removeChild(e) } function N() {
  k = !1; const e = c.length > 0 ? c.length : m.length; if (!w || u >= e) { w = !1, B(), I(), u >= e && E.length > 0 && p.createCSV && !S && (S = !0, he(), chrome.runtime.sendMessage({ action: "updateStatus", status: "All flow prompts completed successfully!" }), Q()); return } const t = m[u] || "", o = t.length > 30 ? t.substring(0, 30) + "..." : t; J(`Processing Flow: "${o}"`), r()
} async function r() {
  var x; const n = c[u]; if (!n) { console.error("❌ No task found at current index"), A(); return }
  // Always try to reset state between prompts
  if (u > 0) {
    console.log("🔄 Resetting state for next prompt...");
    await clickNewProject();
  }
  const a = n.prompt, i = n.type === "image-to-video"; T.clear(), B(); const d = i ? "image" : "text", s = i ? "image-to-video" : "text-to-video", g = `Processing ${s} task ${n.index}: "${a && a.substring(0, 30)}${a && a.length > 30 ? "..." : ""}"`; if (l(g), chrome.runtime.sendMessage({ action: "updateStatus", status: g }), console.log(`🔄 Step 0: Switching to ${s} mode for Task ${n.index}...`), l(`Step 0/5: Switching to ${s} mode...`), await te(d) ? console.log(`✅ Mode switched to ${i ? "image-to-video" : "text-to-video"}`) : console.warn("⚠️ Failed to switch mode, but continuing..."), await f(1e3), n.settings && (console.log(`⚙️ Step 1: Applying Flow settings for Task ${n.index}...`), l(`Step 1/5: Applying settings for Task ${n.index}...`), await ce(n.settings) ? console.log(`✅ Settings applied: ${n.settings.videoCount} video(s), ${n.settings.model}, ${n.settings.aspectRatio}`) : console.warn("⚠️ Failed to apply settings, but continuing..."), await f(1e3)), i && n.image) { console.log(`📤 Step 2: Uploading image for Task ${n.index}...`), l(`Step 2/5: Uploading image for Task ${n.index}...`); const b = ((x = n.settings) == null ? void 0 : x.aspectRatio) || "landscape"; if (!await ee(n.image, b)) { console.error("❌ Failed to upload image"), l("⚠️ Failed to upload image. Retrying..."), A(); return } console.log(`✅ Image uploaded for Task ${n.index}`), await f(2e3) } if (console.log(`📝 Step 3: Injecting prompt for Task ${n.index}...`), l("Step 3/5: Adding prompt..."), Z(a)) if (await f(1e3), n.status = "current", console.log(`📋 Task ${n.index} status: current`), P(n), snapshotExistingVideos(), console.log(`🚀 Step 4: Submitting Task ${n.index}...`), l("Step 4/5: Submitting..."), await le()) { console.log(`✅ Submitted prompt: "${a}"`), console.log("🔍 Step 5: Monitoring for completion..."), l("Step 5/5: Monitoring video generation..."); const b = await ue(); if (b === "QUEUE_FULL") { console.warn("⚠️ Queue full detected! Waiting 30 seconds before retry..."), l("Queue is full. Waiting 30 seconds before retry..."), chrome.runtime.sendMessage({ action: "updateStatus", status: "Queue full. Waiting before retry..." }), await f(3e4), r(); return } if (b === "POLICY_PROMPT") { console.error("❌ Prompt violates policy! Skipping..."), l("⚠️ Policy violation detected. Skipping this prompt..."), n.status = "error", P(n), chrome.runtime.sendMessage({ action: "updateStatus", status: `Policy violation on prompt: "${a == null ? void 0 : a.substring(0, 30)}..."` }), k = !0, await f(3e3), j(); return } console.log("✅ No errors detected, starting video scanning..."), we(), pe(), console.log("⏳ Scanning for videos..."), l("Generating flow... scanning for videos"), R = 0 } else A(); else A()
}
function B() { const e = Math.min(u, m.length); w && l(null, e), chrome.runtime.sendMessage({ action: "updateProgress", currentPrompt: e < m.length ? m[e] : "", processed: e, total: m.length }) } function Z(e) { try { const t = document.querySelector("textarea#PINHOLE_TEXT_AREA_ELEMENT_ID"); return t ? (Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set.call(t, e), t.dispatchEvent(new Event("input", { bubbles: !0 })), !0) : !1 } catch { return !1 } } async function ee(e, t = "landscape") { try { return console.log("🖼️ Starting image upload to Flow with real UI workflow..."), console.log("Step 1: Opening image upload dropdown..."), await oe() ? (await f(500), console.log("Step 2: Injecting image file..."), await ne(e) ? (await f(2e3), console.log("Step 3: Setting aspect ratio in popup..."), await re(t) ? (await f(500), console.log("Step 4: Saving image..."), await ae() ? (console.log("Step 5: Waiting for upload to complete..."), await ie() ? (console.log("✅ Image upload workflow completed successfully!"), !0) : (console.error("❌ Upload did not complete"), !1)) : (console.error("❌ Failed to save image"), !1)) : (console.error("❌ Failed to set aspect ratio"), !1)) : (console.error("❌ Failed to inject image file"), !1)) : (console.error("❌ Failed to open image upload dropdown"), !1) } catch (o) { return console.error("❌ Error in image upload workflow:", o), !1 } } async function te(e) { try { const o = { text: "text_analysis", image: "photo_spark" }[e]; if (!o) return console.error(`❌ Invalid mode: ${e}. Use 'text' or 'image'`), !1; const r = e === "text" ? "text-to-video" : "image-to-video", n = h("//button[.//i[normalize-space()='arrow_drop_down']]"); if (!n) return console.warn("⚠️ Mode dropdown button not found"), !1; n.click(), console.log("✅ Clicked mode dropdown button"), await f(500); const a = h(`//div[@role='option' and .//i[normalize-space()='${o}']]`); return a ? (a.click(), console.log(`✅ Selected ${r} mode`), !0) : (console.warn(`⚠️ ${r} option not found`), !1) } catch (t) { return console.error(`❌ Error switching to ${e} mode:`, t), !1 } } async function oe() { try { const e = h("(//textarea[@id='PINHOLE_TEXT_AREA_ELEMENT_ID']/following::button[.//i='add'])[1]"); return e ? (e.click(), console.log("✅ Clicked add button to open upload dropdown"), !0) : (console.warn("⚠️ Add button not found"), !1) } catch (e) { return console.error("❌ Error opening upload dropdown:", e), !1 } } async function ne(e) { try { const t = h("//input[@type='file']"); if (!t) return console.warn("⚠️ File input not found"), !1; console.log("✅ File input found"); const o = await se(e); if (!o) return console.error("❌ Failed to convert base64 to file"), !1; console.log(`✅ Image file created: ${o.name}, size: ${o.size} bytes`); const r = new DataTransfer; r.items.add(o), t.files = r.files, console.log("✅ File assigned to input"); const n = new Event("change", { bubbles: !0 }); return t.dispatchEvent(n), console.log("✅ Change event dispatched"), !0 } catch (t) { return console.error("❌ Error injecting image file:", t), !1 } } async function re(e = "landscape") { try { const t = h("//button[.//i[normalize-space()='crop_9_16' or normalize-space()='crop_16_9']]"); if (!t) return console.warn("⚠️ Aspect ratio button not found"), !1; t.click(), console.log("✅ Clicked aspect ratio button"), await f(500); let o; return e === "portrait" ? o = h("//*[@data-state='open']//div[@role='option' and .//i='crop_9_16']") : o = h("//*[@data-state='open']//div[@role='option' and .//i='crop_16_9']"), o ? (o.click(), console.log(`✅ Selected aspect ratio: ${e}`), !0) : (console.warn("⚠️ Aspect ratio option not found"), !1) } catch (t) { return console.error("❌ Error setting aspect ratio:", t), !1 } } async function ae() { try { const e = h("//button[.//i[normalize-space()='crop']]"); return e ? (e.click(), console.log("✅ Clicked crop/save button"), !0) : (console.warn("⚠️ Crop/save button not found"), !1) } catch (e) { return console.error("❌ Error saving image:", e), !1 } } async function ie() { console.log("⏳ Waiting for upload to complete..."); for (let o = 0; o < 60; o++) { if (await f(500), !h("//i[normalize-space()='progress_activity']")) return console.log("✅ Upload completed (progress indicator disappeared)"), !0; o % 10 === 0 && o > 0 && console.log(`⏳ Still uploading... (${o * 500 / 1e3}s elapsed)`) } return console.warn("⚠️ Upload timeout after 30 seconds"), !1 } async function se(e) { try { const t = e.match(/^data:([^;]+);base64,(.+)$/); if (!t || t.length !== 3) return console.error("❌ Invalid base64 data format"), null; const o = t[1], r = t[2], n = atob(r), a = new ArrayBuffer(n.length), i = new Uint8Array(a); for (let x = 0; x < n.length; x++)i[x] = n.charCodeAt(x); const d = new Blob([a], { type: o }), s = o.split("/")[1] || "jpg", g = `flow_image_${Date.now()}.${s}`; return new File([d], g, { type: o }) } catch (t) { return console.error("❌ Error converting base64 to file:", t), null } } async function le() { try { console.log("🔍 Waiting 2s before looking for submit button..."); await f(2000); console.log("🔍 Looking for submit button with Create span..."); let t = h("//button[.//span[normalize-space(text())='Create']]"); if (!t) { console.log("🔍 Trying arrow_forward icon selector..."); t = h("//button[.//i[normalize-space()='arrow_forward']]"); } if (!t) { console.log("🔍 Trying to find any button with arrow_forward..."); t = Array.from(document.querySelectorAll("button")).find(o => { const icon = o.querySelector("i"); return icon && icon.textContent.trim() === "arrow_forward"; }); } if (t) { console.log("✅ Submit button found! Waiting 500ms then clicking..."); await f(500); t.click(); console.log("✅ Submit button clicked!"); return true; } else { console.log("⚠️ Submit button not found, trying Enter key..."); const textarea = document.querySelector("textarea#PINHOLE_TEXT_AREA_ELEMENT_ID"); if (textarea) { textarea.focus(); const enterEvent = new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true }); textarea.dispatchEvent(enterEvent); console.log("✅ Enter key dispatched!"); return true; } console.error("❌ Could not submit - no button or textarea found!"); return false; } } catch (e) { console.error("❌ Error clicking submit:", e); return false; } } async function ce(e = null) {
  try {
    const t = (e == null ? void 0 : e.videoCount) || p.flowVideoCount, o = (e == null ? void 0 : e.model) || p.flowModel, r = (e == null ? void 0 : e.aspectRatio) || p.flowAspectRatio; console.log("⚙️ Applying Flow settings:", { videoCount: t, model: o, aspectRatio: r }); const n = h("//button[.//div[contains(., 'Veo')] and .//i[normalize-space(text())='volume_up' or normalize-space(text())='volume_off']]"); if (!n) return console.warn("⚠️ Settings button not found"), !1; n.click(), await f(1e3); const a = { 1: "//div[@role='option' and .//span[text()='1']]", 2: "//div[@role='option' and .//span[text()='2']]", 3: "//div[@role='option' and .//span[text()='3']]", 4: "//div[@role='option' and .//span[text()='4']]" }, i = h("//button[@role='combobox' and .//span[not(.//i) and (normalize-space(.)='1' or normalize-space(.)='2' or normalize-space(.)='3' or normalize-space(.)='4')]]"); if (!i) return console.warn("⚠️ Video count button not found"), !1; i.click(), await f(500); const d = h(a[t]); if (!d) return console.warn("⚠️ Video count option not found"), !1; d.click(), await f(500), console.log(`✅ Selected ${t} video(s)`); const s = { veo2_fast: "//div[@role='option' and contains(., 'Veo 2 - Fast')]", veo3_quality: "//div[@role='option' and contains(., 'Veo 3.1 - Quality')]", veo2_quality: "//div[@role='option' and contains(., 'Veo 2 - Quality')]", default: "//div[@role='option' and contains(., 'Veo 3.1 - Fast')]", veo3_fast_low: "//div[@role='option' and contains(., 'Veo 3.1 - Fast [Lower Priority]')]" }, g = o === "default" || !s[o] ? "default" : o, y = h("//button[@role='combobox' and .//span[not(.//i)] and contains(normalize-space(),'Veo')]"); if (!y) return console.warn("⚠️ Model button not found"), !1; y.click(), await f(500); const x = h(s[g]); if (!x) return console.warn("⚠️ Model option not found"), !1; x.click(), await f(500), console.log(`✅ Selected model: ${o}`);// ... (previous code)
    // Helper to get helper text for aspect ratio
    const b = h("//button[@role='combobox' and .//i[normalize-space(text())='crop_portrait' or normalize-space(text())='crop_landscape' or normalize-space(text())='crop_9_16' or normalize-space(text())='crop_16_9']]");
    if (!b) return console.warn("⚠️ Aspect ratio dropdown not found"), !1;
    b.click(), await f(1000); // Increased delay
    const _ = h(r === "portrait" ? "//div[@role='option' and .//i[normalize-space(text())='crop_portrait' or normalize-space(text())='crop_9_16']]" : "//div[@role='option' and .//i[normalize-space(text())='crop_landscape' or normalize-space(text())='crop_16_9']]");
    return _ ? (_.click(), await f(1000), console.log(`✅ Selected aspect ratio: ${r}`), document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", keyCode: 27, bubbles: !0, cancelable: !0, composed: !0 })), await f(1000), console.log("✅ Settings panel closed"), !0) : (console.error(`❌ Aspect ratio option '${r}' not found! Strict mode enforced.`), !1)
  } catch (t) { return console.error("❌ Error applying Flow settings:", t), !1 }

}

async function clickNewProject() {
  try {
    const n = h("//button[.//i[normalize-space()='add_2']]");
    return n ? (console.log("✅ 'New Project' button found. Clicking to reset state..."), n.click(), await f(2000), !0) : (console.warn("⚠️ 'New Project' button not found"), !1)
  } catch (n) {
    return console.error("❌ Error clicking 'New Project':", n), !1
  }
}

function f(e) { return new Promise(t => setTimeout(t, e)) } function h(e) { try { return document.evaluate(e, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue } catch (t) { return console.error("❌ XPath evaluation error:", t), null } } function P(e) { e.queueTaskId && chrome.runtime.sendMessage({ action: "queueTaskUpdate", taskId: e.queueTaskId, updates: { status: e.status } }).catch(() => { }) } function de() { try { return !!h(F.QUEUE_FULL_POPUP_XPATH) } catch (e) { return console.warn("⚠️ Error checking for queue full:", e), !1 } } function W() { try { return !!h(F.PROMPT_POLICY_ERROR_POPUP_XPATH) } catch (e) { return console.warn("⚠️ Error checking for policy error:", e), !1 } } async function ue() { await f(2e3); for (let e = 0; e < 10; e++) { if (de()) return console.warn("⚠️ Queue is full! Need to wait..."), "QUEUE_FULL"; if (W()) return console.warn("⚠️ Prompt violates policy!"), "POLICY_PROMPT"; await f(1e3) } return null } let U = null; function pe() { C(), console.log("🔍 Starting error monitoring..."), U = setInterval(async () => { var e; if (!w) { C(); return } if (W()) { console.error("❌ Policy error detected during generation!"), C(), $(); const t = c[u]; t && (t.status = "error", P(t)), l("⚠️ Policy violation detected. Skipping this prompt..."), chrome.runtime.sendMessage({ action: "updateStatus", status: `Policy violation on prompt: "${(e = m[u]) == null ? void 0 : e.substring(0, 30)}..."` }), setTimeout(() => { w && (k = !0, j()) }, 3e3) } }, 2e3) } function C() { U && (clearInterval(U), U = null, console.log("🛑 Error monitoring stopped")) }

// Snapshot all current videos on page before submitting new prompt
function snapshotExistingVideos() {
  preSubmissionVideos.clear();
  try {
    const videos = document.querySelectorAll('video[src^="http"]');
    videos.forEach(v => {
      const src = v.getAttribute('src');
      if (src) {
        const baseUrl = src.split('?')[0];
        preSubmissionVideos.add(baseUrl);
        D.add(baseUrl); // Also add to downloaded set to prevent re-download
      }
    });
    console.log(`📸 Snapshotted ${preSubmissionVideos.size} existing videos before submission`);
  } catch (e) {
    console.warn('⚠️ Error snapshotting videos:', e);
  }
}

function fe() { const e = []; try { const t = document.evaluate(F.RESULT_CONTAINER_XPATH, document, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null); let o = t.iterateNext(); for (; o;) { try { const r = document.evaluate(F.PROMPT_IN_CONTAINER_XPATH, o, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; if (r && r.textContent) { const n = r.textContent.trim(), a = [], i = document.evaluate(F.VIDEOS_IN_CONTAINER_XPATH, o, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null); let d = i.iterateNext(); for (; d;) { const s = d.getAttribute("src"); if (s && s.startsWith("http")) { const g = s.split("?")[0]; if (!D.has(g) && !preSubmissionVideos.has(g)) a.push(s) } d = i.iterateNext() } a.length > 0 && e.push({ prompt: n, videos: a }) } } catch (r) { console.warn("⚠️ Error processing container:", r) } o = t.iterateNext() } } catch (t) { console.error("❌ Error scanning for videos:", t) } return e } async function ge() {
  videoScanCount++;
  console.log(`🔍 Video scan #${videoScanCount}/${maxVideoScans}...`);
  if (videoScanCount >= maxVideoScans) {
    console.warn(`⚠️ Video generation timeout after ${maxVideoScans * Y / 1e3} seconds!`);
    l(`⚠️ Timeout waiting for video. Moving to next prompt...`);
    const currentTask = c[u];
    if (currentTask) { currentTask.status = "error"; P(currentTask); }
    k = !0; $(); C();
    setTimeout(() => { w && j(); }, 2e3);
    return;
  }
  var e; if (w) try {
    const t = fe(); if (t.length === 0) return; for (const o of t) {
      const r = c.find(n => n.prompt.trim() === o.prompt.trim() && (n.status === "pending" || n.status === "current")); if (r) {
        console.log(`✅ Found ${o.videos.length} video(s) for Task ${r.index}: "${o.prompt.substring(0, 30)}..."`); for (const n of o.videos) {
          const a = n.split("?")[0]; if (r.videoUrls.includes(a) || D.has(a)) continue; r.videoUrls.push(a), r.foundVideos++, D.add(a); const i = r.foundVideos;
          const sanitizedPrompt = o.prompt.replace(/[^a-zA-Z0-9]/g, "_").substring(0, 30);
          const d = `${sanitizedPrompt}_${r.index}_${i}`;
          const s = { promptIndex: u, prompt: o.prompt, fifeUrl: n, flowName: d }; if (T.add(s), p.autoDownload) { const g = ((e = r.settings) == null ? void 0 : e.folderName) || ""; xe(n, d, g) } l(`✅ Video ${i}/${r.expectedVideos} for Task ${r.index}`), chrome.runtime.sendMessage({ action: "updateStatus", status: `Video ${i}/${r.expectedVideos} captured for Task ${r.index}` }), P(r), console.log(`📹 Task ${r.index}: ${r.foundVideos}/${r.expectedVideos} videos captured`)
        } r.foundVideos >= r.expectedVideos && r.status === "current" && (r.status = "processed", console.log(`✅ Task ${r.index} COMPLETE (${r.foundVideos}/${r.expectedVideos} videos)`), P(r), me())
      }
    }
  } catch (t) { console.error("❌ Error in periodic video scanner:", t) }
} function me() { var e; k || (console.log(`✅ Videos complete for prompt ${u + 1}`), T.size > 0 && (T.forEach(t => { E.push(t) }), l(`✅ Generated ${T.size} flow(s) for current prompt`), chrome.runtime.sendMessage({ action: "updateStatus", status: `Captured ${T.size} flow(s) for prompt: "${(e = m[u]) == null ? void 0 : e.substring(0, 30)}..."` })), k = !0, $(), C(), console.log(`⏳ Will wait ${p.delayBetweenPrompts / 1e3}s before next prompt...`), setTimeout(() => { w && (k = !0, j()) }, 2e3)) } function we() { $(), videoScanCount = 0, w && (console.log(`🔍 Starting video scanner (every ${Y / 1e3} seconds, max ${maxVideoScans * Y / 1e3}s timeout, autoDownload: ${p.autoDownload})`), V = setInterval(ge, Y)) } function $() { V && (clearInterval(V), V = null, console.log("🛑 Video scanner stopped")) } function A() { if (R < H) { R++; const e = `Retry ${R}/${H}: Waiting for Flow Labs interface...`; l(e), chrome.runtime.sendMessage({ action: "updateStatus", status: e }), setTimeout(N, 5e3) } else { I(); const e = c[u]; e && (e.status = "error", P(e)), chrome.runtime.sendMessage({ action: "error", error: "Unable to find Flow Labs interface elements after multiple attempts. Make sure you are on the correct page." }), w = !1 } } function j() {
  if (k) {
    if ($(), u++, B(), O(), !w) { $(), C(), I(), chrome.runtime.sendMessage({ action: "updateStatus", status: "Flow processing paused. Click Resume to continue." }); return }
    // Countdown Timer logic
    let secondsLeft = Math.floor(p.delayBetweenPrompts / 1e3);
    l(`Waiting ${secondsLeft}s before next prompt...`);
    const interval = setInterval(() => {
      secondsLeft--;
      if (secondsLeft > 0) l(`Waiting ${secondsLeft}s...`);
    }, 1e3);

    setTimeout(() => {
      clearInterval(interval);
      N()
    }, p.delayBetweenPrompts)
  }
} function G() { const e = new Date; return e.getFullYear() + ("0" + (e.getMonth() + 1)).slice(-2) + ("0" + e.getDate()).slice(-2) + "_" + ("0" + e.getHours()).slice(-2) + ("0" + e.getMinutes()).slice(-2) } function he() {
  if (l("Creating CSV file..."), E.length === 0) { l("Warning: No flow data to create CSV"); return } try {
    let e = `Prompt Index,Prompt,Flow Name,Fife URL
`; E.forEach(n => {
      const a = n.promptIndex !== void 0 && n.promptIndex !== null ? n.promptIndex + 1 : "unknown", i = n.prompt || "", d = i.replace ? i.replace(/"/g, '""') : "", s = n.flowName || "unknown", g = n.fifeUrl || "unknown"; e += `${a},"${d}",${s}.mp4,"${g}"
`}); const t = `labs_flow_${G()}.csv`, o = new Blob([e], { type: "text/csv;charset=utf-8;" }), r = URL.createObjectURL(o); chrome.runtime.sendMessage({ action: "downloadCSV", url: r, filename: t, content: e }, n => { n && n.success ? (l(`✅ CSV with ${E.length} entries saved to AutoLabs_flow folder!`), chrome.runtime.sendMessage({ action: "updateStatus", status: `CSV with ${E.length} entries created and saved!` })) : ye(r, t), setTimeout(() => URL.revokeObjectURL(r), 5e3) })
  } catch (e) { l(`Error creating CSV: ${e.message}`), chrome.runtime.sendMessage({ action: "error", error: `Error creating CSV: ${e.message}` }) }
} function ye(e, t) { const o = document.createElement("a"); o.href = e, o.download = t, document.body.appendChild(o), o.click(), document.body.removeChild(o), l(`CSV downloaded: ${t}`) } function xe(e, t, o = "") { be(e, t, o) } function be(e, t, o = "") { try { chrome.runtime.sendMessage({ action: "downloadVideo", url: e, filename: `${t}.mp4`, folderName: o }, r => { if (r && r.success) { const n = o ? ` to ${o}/` : ""; l(`✅ Flow downloaded: ${t}.mp4${n}`) } else q(e, t) }) } catch { q(e, t) } } function q(e, t) { try { const o = document.createElement("a"); o.href = e, o.download = `${t}.mp4`, o.target = "_blank", o.style.display = "none", o.setAttribute("download", `${t}.mp4`), o.setAttribute("type", "video/mp4"), document.body.appendChild(o), o.click(), document.body.removeChild(o), l(`⚠️ Flow link opened: ${t} (check downloads)`) } catch { ve(e, t) } } function ve(e, t) { l(`Flow ready: ${t}. Click to download manually.`), chrome.runtime.sendMessage({ action: "flowReady", flowName: t, downloadUrl: e, message: `Flow "${t}" is ready. Download link provided.` }) }
