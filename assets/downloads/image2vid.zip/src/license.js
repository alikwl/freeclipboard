// License Verification System
// Backend: https://flow-backend-wine.vercel.app/api/verify
// BTC Flow Automator PRO - Bismillah Tech Co

const API_URL = 'https://flow-backend-wine.vercel.app/api/verify';

// Generate unique machine ID - more secure version
async function getMachineId() {
    // Gather multiple device fingerprints
    const nav = window.navigator;
    const screen = window.screen;

    const components = [
        nav.userAgent,
        nav.language,
        nav.languages ? nav.languages.join(',') : '',
        screen.width + 'x' + screen.height,
        screen.colorDepth,
        screen.pixelDepth,
        new Date().getTimezoneOffset(),
        nav.hardwareConcurrency || 0,
        nav.platform,
        nav.deviceMemory || 0,
        nav.maxTouchPoints || 0,
        // Canvas fingerprint
        getCanvasFingerprint(),
        // WebGL info
        getWebGLInfo()
    ];

    const data = components.join('###');

    // Generate SHA-256 like hash using SubtleCrypto if available
    try {
        const encoder = new TextEncoder();
        const dataBuffer = encoder.encode(data);
        const hashBuffer = await crypto.subtle.digest('SHA-256', dataBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        return 'BTC-' + hashHex.substring(0, 16).toUpperCase();
    } catch (e) {
        // Fallback to simple hash
        let hash = 0;
        for (let i = 0; i < data.length; i++) {
            const char = data.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return 'BTC-' + Math.abs(hash).toString(16).toUpperCase().padStart(16, '0');
    }
}

// Canvas fingerprint for additional uniqueness
function getCanvasFingerprint() {
    try {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        ctx.textBaseline = 'top';
        ctx.font = '14px Arial';
        ctx.fillStyle = '#f60';
        ctx.fillRect(125, 1, 62, 20);
        ctx.fillStyle = '#069';
        ctx.fillText('BTC-FP', 2, 15);
        return canvas.toDataURL().slice(-50);
    } catch (e) {
        return 'no-canvas';
    }
}

// WebGL renderer info
function getWebGLInfo() {
    try {
        const canvas = document.createElement('canvas');
        const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
        if (gl) {
            const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
            if (debugInfo) {
                return gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
            }
        }
        return 'no-webgl';
    } catch (e) {
        return 'no-webgl';
    }
}

// Re-verify license with server (called before automation starts)
async function reVerifyLicense() {
    const stored = await chrome.storage.local.get(['licenseKey', 'machineId']);

    if (!stored.licenseKey || !stored.machineId) {
        return { valid: false, message: 'No license found. Please activate first.' };
    }

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                licenseKey: stored.licenseKey,
                machineId: stored.machineId
            })
        });

        const data = await response.json();

        if (data.success) {
            // Update stored expiry
            await chrome.storage.local.set({ expiryDate: data.expiry });
            return { valid: true, expiry: data.expiry, name: data.name };
        } else {
            // License is invalid/expired/banned - clear storage and show license screen
            await chrome.storage.local.remove(['licenseKey', 'expiryDate', 'machineId', 'userName']);

            // Show license overlay again
            const overlay = document.getElementById('license-overlay');
            if (overlay) overlay.classList.remove('hidden');

            return { valid: false, message: data.message };
        }
    } catch (error) {
        console.error('[LICENSE] Re-verification error:', error);
        // On network error, allow offline use if expiry hasn't passed
        const stored2 = await chrome.storage.local.get(['expiryDate']);
        if (stored2.expiryDate && new Date() < new Date(stored2.expiryDate)) {
            return { valid: true, expiry: stored2.expiryDate, offline: true };
        }
        return { valid: false, message: 'Connection error. Please check internet.' };
    }
}

// Get license info for display
async function getLicenseInfo() {
    const stored = await chrome.storage.local.get(['licenseKey', 'expiryDate', 'userName']);
    return {
        licenseKey: stored.licenseKey || null,
        expiryDate: stored.expiryDate || null,
        userName: stored.userName || null
    };
}

// Export for use in other scripts
window.BTCLicense = {
    reVerifyLicense,
    getLicenseInfo,
    getMachineId
};

async function initLicense() {
    const overlay = document.getElementById('license-overlay');
    const input = document.getElementById('license-input');
    const btn = document.getElementById('btn-verify');
    const status = document.getElementById('license-status');

    console.log('[LICENSE] Initializing BTC Flow Automator PRO...');

    // Check for existing valid license
    const stored = await chrome.storage.local.get(['licenseKey', 'expiryDate', 'machineId', 'userName']);

    if (stored.licenseKey && stored.expiryDate && stored.machineId) {
        const expiry = new Date(stored.expiryDate);
        const now = new Date();

        if (now < expiry) {
            console.log('[LICENSE] Valid license found. Verifying with server...');

            // Re-verify with server every time
            const verification = await reVerifyLicense();

            if (verification.valid) {
                console.log('[LICENSE] Server verified. Unlocking UI...');
                overlay.classList.add('hidden');
                addLicenseInfoPopup(stored);
                return;
            } else {
                console.log('[LICENSE] Server rejected:', verification.message);
                setStatus(verification.message, 'error');
            }
        } else {
            console.log('[LICENSE] License expired locally.');
            setStatus('Your license has expired. Please renew.', 'error');
        }
    }

    // Show license overlay
    overlay.classList.remove('hidden');

    // Pre-fill if stored
    if (stored.licenseKey) {
        input.value = stored.licenseKey;
    }

    // Verify button click handler
    btn.addEventListener('click', async () => {
        const licenseKey = input.value.trim();

        if (!licenseKey) {
            setStatus('Please enter a license key.', 'error');
            return;
        }

        btn.disabled = true;
        btn.textContent = 'Verifying...';
        setStatus('Connecting to server...', 'info');

        try {
            const machineId = await getMachineId();
            console.log('[LICENSE] Machine ID:', machineId);

            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    licenseKey: licenseKey,
                    machineId: machineId
                })
            });

            const data = await response.json();
            console.log('[LICENSE] Server response:', data);

            if (data.success) {
                // Save license data
                const licenseData = {
                    licenseKey: licenseKey,
                    expiryDate: data.expiry,
                    machineId: machineId,
                    userName: data.name || 'Licensed User'
                };
                await chrome.storage.local.set(licenseData);

                if (data.isFirstActivation) {
                    setStatus('✓ License Activated & Locked to this device!', 'success');
                } else {
                    setStatus('✓ License Verified! Welcome back ' + (data.name || ''), 'success');
                }

                setTimeout(() => {
                    overlay.classList.add('hidden');
                    addLicenseInfoPopup(licenseData);
                }, 1500);
            } else {
                setStatus('✗ ' + (data.message || 'Invalid license key'), 'error');
                btn.disabled = false;
                btn.textContent = 'Activate License';
            }
        } catch (error) {
            console.error('[LICENSE] Error:', error);
            setStatus('✗ Connection error. Check internet.', 'error');
            btn.disabled = false;
            btn.textContent = 'Activate License';
        }
    });

    // Enter key to submit
    input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            btn.click();
        }
    });

    function setStatus(msg, type) {
        status.textContent = msg;
        status.className = 'status-msg status-' + type;
    }
}

// Add license info popup that shows when user icon is clicked
function addLicenseInfoPopup(licenseData) {
    // Remove existing popup if any
    const existing = document.getElementById('license-info-popup');
    if (existing) existing.remove();

    const popup = document.createElement('div');
    popup.id = 'license-info-popup';
    popup.innerHTML = `
        <h4>🔐 License Information</h4>
        <div class="info-row">
            <span class="info-label">Status:</span>
            <span class="info-value active">✓ Active</span>
        </div>
        <div class="info-row">
            <span class="info-label">User:</span>
            <span class="info-value">${licenseData.userName || 'Licensed User'}</span>
        </div>
        <div class="info-row">
            <span class="info-label">Expires:</span>
            <span class="info-value">${licenseData.expiryDate || 'Unknown'}</span>
        </div>
        <div class="info-row">
            <span class="info-label">Key:</span>
            <span class="info-value">${maskKey(licenseData.licenseKey)}</span>
        </div>
        <div class="info-row">
            <span class="info-label">Device:</span>
            <span class="info-value">🔒 Locked</span>
        </div>
        <div class="branding">
            <strong>Bismillah Tech Co</strong><br>
            Developed by Haider Ali<br>
            <a href="https://wa.me/923325500752" target="_blank">WhatsApp +92 332 5500752</a>
        </div>
    `;
    document.body.appendChild(popup);

    // Find user icon and add click handler
    setTimeout(() => {
        const userIcons = document.querySelectorAll('[class*="rounded-full"]');
        userIcons.forEach(icon => {
            if (icon.closest('button') || icon.tagName === 'BUTTON') {
                icon.addEventListener('click', (e) => {
                    e.stopPropagation();
                    popup.classList.toggle('visible');
                });
            }
        });
    }, 1000);

    // Close on outside click
    document.addEventListener('click', (e) => {
        if (!popup.contains(e.target)) {
            popup.classList.remove('visible');
        }
    });
}

function maskKey(key) {
    if (!key) return '****';
    if (key.length <= 4) return key;
    return key.substring(0, 2) + '****' + key.substring(key.length - 2);
}

// Run on load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initLicense);
} else {
    initLicense();
}
