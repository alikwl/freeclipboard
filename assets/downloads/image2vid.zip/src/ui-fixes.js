
// UI Fixes - Minimal Version
(function () {
    function init() {
        // Run fixes when DOM changes
        const observer = new MutationObserver(() => fixUI());
        observer.observe(document.body, { childList: true, subtree: true });

        // Run immediately and after short delay
        fixUI();
        setTimeout(fixUI, 500);
        setTimeout(fixUI, 1500);
    }

    let is169Active = true;

    function fixUI() {
        // Fix tab text visibility - show full text on all screens
        document.querySelectorAll('.hidden.xs\\:inline, [class*="hidden"][class*="xs\\:inline"]').forEach(el => {
            el.style.display = 'inline';
        });

        // Hide the short mobile-only text
        document.querySelectorAll('.xs\\:hidden, [class*="xs\\:hidden"]').forEach(el => {
            el.style.display = 'none';
        });

        // Handle ratio buttons
        const buttons = document.querySelectorAll('button');
        let btn169 = null, btn916 = null, btnPrompts = null;

        buttons.forEach(btn => {
            const text = btn.innerText || "";
            if (text.includes("All 16:9")) btn169 = btn;
            if (text.includes("All 9:16")) btn916 = btn;
            if (text.includes("Prompts")) btnPrompts = btn;
        });

        if (btn169 && btn916) {
            if (!btn169.dataset.fixed) {
                btn169.addEventListener('click', () => { is169Active = true; updateButtons(btn169, btn916); });
                btn916.addEventListener('click', () => { is169Active = false; updateButtons(btn169, btn916); });
                btn169.dataset.fixed = "1";
                btn916.dataset.fixed = "1";
            }
            updateButtons(btn169, btn916);
        }

        // Hide icons from these buttons
        [btn169, btn916, btnPrompts].forEach(btn => {
            if (btn) {
                const svg = btn.querySelector('svg');
                if (svg) svg.style.display = 'none';
            }
        });
    }

    function updateButtons(btn169, btn916) {
        if (is169Active) {
            btn169.classList.add('btn-ui-active');
            btn169.classList.remove('btn-ui-inactive');
            btn916.classList.add('btn-ui-inactive');
            btn916.classList.remove('btn-ui-active');
        } else {
            btn916.classList.add('btn-ui-active');
            btn916.classList.remove('btn-ui-inactive');
            btn169.classList.add('btn-ui-inactive');
            btn169.classList.remove('btn-ui-active');
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
