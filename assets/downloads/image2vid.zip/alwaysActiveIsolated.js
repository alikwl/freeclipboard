(function () {
    function t(e) {
        e.preventDefault(), e.stopPropagation(), e.stopImmediatePropagation()
    }
    try {
        Object.defineProperty(document, "visibilityState", {
            get() {
                return "visible"
            }
        }), Object.defineProperty(document, "webkitVisibilityState", {
            get() {
                return "visible"
            }
        }), Object.defineProperty(document, "hidden", {
            get() {
                return !1
            }
        }), Object.defineProperty(document, "webkitHidden", {
            get() {
                return !1
            }
        })
    } catch { }
    document.addEventListener("visibilitychange", t, !0), document.addEventListener("webkitvisibilitychange", t, !0), window.addEventListener("pagehide", t, !0), window.addEventListener("blur", t, !0), window.addEventListener("focus", t, !0), window.addEventListener("mouseout", t, !0), window.addEventListener("mouseleave", t, !0), window.addEventListener("lostpointercapture", t, !0), Document.prototype.hasFocus = new Proxy(Document.prototype.hasFocus, {
        apply(e, n, i) {
            return !0
        }
    });
    let r = 0;
    window.requestAnimationFrame = function (e) {
        const n = Date.now(),
            i = Math.max(0, 16 - (n - r)),
            a = setTimeout(() => {
                e(performance.now())
            }, i);
        return r = n + i, a
    };
    const o = window.cancelAnimationFrame;
    window.cancelAnimationFrame = function (e) {
        return clearTimeout(e), o(e)
    }
})();